"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Send, Mic, Sparkles, ChevronDown } from "lucide-react"
import { ChatMessage } from "@/components/chat-message"
import { TypingIndicator } from "@/components/typing-indicator"
import { ChatHeader } from "@/components/chat-header"
import { useAuth } from "@/hooks/use-auth"
import { env } from "../app/config/env"
import { t } from "../i18n"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
  startTime?: string
  endTime?: string
  references?: Reference[]
  confidence?: number
  model?: {
    id: string
    responseId?: string
    usage?: {
      promptTokens: number
      completionTokens: number
      totalTokens: number
    }
    finishReason?: string
  }
  processingTime?: number
}

interface Reference {
  id: string
  title: string
  summary: string
  fullContent: string
  source: string
  documentType: string
  score: number
  rerankScore?: number
  language?: string
}

interface ChatInterfaceProps {
  conversationId: string | null
  onHistoryUpdated?: () => void
  onConversationIdChange?: (id: string) => void
}

export function ChatInterface({ conversationId, onHistoryUpdated, onConversationIdChange }: ChatInterfaceProps) {
  const { userId, userEmail, isLoading: authLoading } = useAuth();
  
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isLoadingConversation, setIsLoadingConversation] = useState(false)
  const [processingState, setProcessingState] = useState<string>("")
  const [showScrollToBottom, setShowScrollToBottom] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const messagesContainerRef = useRef<HTMLDivElement>(null)
  const lastMessageCountRef = useRef(0)

  // Auto-scroll to bottom for new messages
  useEffect(() => {
    if (messages.length > lastMessageCountRef.current) {
      lastMessageCountRef.current = messages.length
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
      }, 100)
    }
  }, [messages])

  // Handle scroll to show/hide scroll-to-bottom button
  useEffect(() => {
    const container = messagesContainerRef.current
    if (!container) return

    const handleScroll = () => {
      const isNearBottom = container.scrollTop + container.clientHeight >= container.scrollHeight - 100
      setShowScrollToBottom(!isNearBottom && messages.length > 0)
    }

    container.addEventListener('scroll', handleScroll)
    return () => container.removeEventListener('scroll', handleScroll)
  }, [messages.length])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  // Load conversation when conversationId changes
  useEffect(() => {
    // Always clear messages first when switching conversations or starting a new one
    setMessages([])
    if (conversationId) {
      loadConversation(conversationId)
    }
  }, [conversationId])

  // Auto-scroll when conversation is loaded from history
  useEffect(() => {
    if (messages.length > 0) {
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
      }, 200)
    }
  }, [messages.length])

  const loadConversation = async (id: string) => {
    setIsLoadingConversation(true)
    try {
      const response = await fetch(`/api/conversations/${id}`)
      if (response.ok) {
        const data = await response.json()
        // Support both shapes: { conversation: {...} } or direct {...}
        const conversation = data.conversation ?? data
        
        // Convert conversation messages to the expected format
        const formattedMessages: Message[] = (conversation.messages || []).map((msg: any) => ({
          id: msg.id,
          role: msg.role,
          content: msg.content,
          timestamp: new Date(msg.timestamp),
          references: msg.references || [],
          model: msg.model,
          processingTime: msg.processingTime,
        }))
        
        setMessages(formattedMessages)
        
        // Auto-scroll to bottom after conversation is loaded
        setTimeout(() => {
          messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
        }, 300) // Slightly longer delay to ensure all content is rendered
      } else {
        // If not found or other error, keep new conversation empty
        setMessages([])
      }
    } catch (error) {
      console.error('Error loading conversation:', error)
      // Ensure UI shows empty state on error loading a new conversation
      setMessages([])
    } finally {
      setIsLoadingConversation(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input.trim(),
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    const currentInput = input.trim()
    setInput("")
    setIsLoading(true)
    setProcessingState(t('stateAnalyzingQuestion'))

    try {
      setProcessingState(t('stateGetDocuments'))
      
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: currentInput,
          conversationId: conversationId,
          userId: userId || 'anonymous',
          userEmail: userEmail || undefined,
          options: {
            topK: 20,
            rerankTopK: 5,
            includeReferences: true,
            useReranking: true,
          }
        }),
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      setProcessingState(t('stateProcessingModel'))
      
      const data = await response.json()

      // If conversation was created, inform parent to set it
      if (!conversationId && data.conversationId && onConversationIdChange) {
        onConversationIdChange(data.conversationId)
      }
      
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: data.answer,
        timestamp: new Date(),
        startTime: data.metadata.startTime,
        endTime: data.metadata.endTime,
        model: data.metadata.model,
        processingTime: data.metadata.processingTime / 1000, // Convert to seconds
        references: data.references || [],
      }

      setMessages((prev) => [...prev, aiMessage])
      setProcessingState("")

      // Ask sidebar to refresh history (message count/last message)
      onHistoryUpdated && onHistoryUpdated()
    } catch (error) {
      console.error('Error sending message:', error)
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: `Desculpe, ocorreu um erro ao processar sua pergunta: ${(error as Error).message}. Por favor, tente novamente.`,
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, errorMessage])
      setProcessingState("")
      // Even on error, refresh history in case conversation was created
      onHistoryUpdated && onHistoryUpdated()
    } finally {
      setIsLoading(false)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSubmit(e as any)
    }
  }

  return (
    <div className="flex-1 flex flex-col min-h-0">
      <div className="flex-shrink-0">
        <ChatHeader />
      </div>
      
      {/* Messages Area */}
      <div className="flex-1 relative min-h-0">
        <div 
          ref={messagesContainerRef}
          className="absolute inset-0 overflow-y-auto"
        >
        <div className="p-3 sm:p-6 space-y-4 sm:space-y-6">
          {messages.length === 0 && (
            <div className="flex items-center justify-center min-h-[60vh]">
              <div className="text-center max-w-lg">
                <div className="relative mb-6">
                  <div className="w-20 h-20 mx-auto bg-gradient-to-br from-[#0093d0] via-[#0077b3] to-[#004d7a] rounded-2xl flex items-center justify-center shadow-lg">
                    <Sparkles className="w-10 h-10 text-white animate-pulse" />
                  </div>
                  <div className="absolute -top-1 -right-1 w-6 h-6 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
                    <Sparkles className="w-3 h-3 text-white" />
                  </div>
                </div>
                                 <h3 className="text-2xl font-bold bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent mb-3">
                   {env.NEXT_PUBLIC_APP_NAME}
                 </h3>
                <p className="text-gray-600 leading-relaxed">
                  {t('massage_welcome')}
                </p>
                <div className="mt-6 flex justify-center space-x-2">
                  <div className="w-2 h-2 bg-gradient-to-r from-[#0093d0] to-[#0077b3] rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gradient-to-r from-[#0077b3] to-[#0066a3] rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-gradient-to-r from-[#0066a3] to-[#004d7a] rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
              </div>
            </div>
          )}

          {messages.map((message) => (
            <ChatMessage 
              key={message.id} 
              message={message} 
              conversationId={conversationId || undefined}
              userId={userId || undefined}
            />
          ))}

          {isLoading && <TypingIndicator processingState={processingState} />}

                     {isLoadingConversation && (
             <div className="flex items-center justify-center py-8">
               <div className="flex items-center gap-3 text-gray-500">
                 <div className="w-5 h-5 border-2 border-gray-300 border-t-[#003366] rounded-full animate-spin"></div>
                 <span className="text-sm">{t('loading')}</span>
               </div>
             </div>
           )}

          <div ref={messagesEndRef} />
        </div>
        </div>

        {/* Scroll to bottom button */}
                 {showScrollToBottom && (
           <Button
             onClick={scrollToBottom}
             className="absolute bottom-4 right-4 w-12 h-12 rounded-full bg-[#003366] hover:bg-[#002244] text-white shadow-lg hover:shadow-xl transition-all duration-200 z-10"
             size="sm"
           >
             <ChevronDown className="w-5 h-5" />
           </Button>
         )}
      </div>

      {/* Input Area */}
      <div className="flex-shrink-0 border-t border-gray-200/60 p-3 sm:p-6 bg-gradient-to-r from-white to-blue-50/30 backdrop-blur-sm">
        <form onSubmit={handleSubmit} className="flex gap-2 sm:gap-3">
          <div className="flex-1 relative">
            <Input
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder={t('send_a_question_or_drop_file')}
              className="pr-16 sm:pr-24 min-h-[44px] sm:min-h-[52px] text-sm sm:text-base border-2 border-gray-200 focus:border-blue-400 rounded-xl sm:rounded-2xl shadow-sm bg-white/80 backdrop-blur-sm transition-all duration-200 placeholder:text-gray-500"
              disabled={isLoading}
            />
            <div className="absolute right-2 sm:right-3 top-1/2 -translate-y-1/2 flex items-center gap-1 sm:gap-2">
              {/* <Button
                type="button"
                variant="ghost"
                size="sm"
                className="h-8 w-8 p-0 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all duration-200"
                disabled={isLoading}
              >
                <Mic className="w-4 h-4" />
              </Button> */}
              <span className="text-xs text-gray-400 font-medium hidden sm:inline">{input.length}/2000</span>
            </div>
          </div>
          <Button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="min-h-[44px] sm:min-h-[52px] px-4 sm:px-8 bg-gradient-to-r from-[#0093d0] to-[#0066a3] hover:from-[#0066a3] hover:to-[#001a2c] text-white rounded-xl sm:rounded-2xl shadow-md hover:shadow-lg transition-all duration-200 font-medium"
          >
            {isLoading ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                <span className="hidden sm:inline">{t('sending')}</span>
              </div>
            ) : (
              <>
                <Send className="w-4 h-4 sm:mr-2" />
                <span className="hidden sm:inline">{t('send')}</span>
              </>
            )}
          </Button>
        </form>
      </div>
    </div>
  )
}
