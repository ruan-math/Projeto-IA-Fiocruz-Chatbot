"use client"

import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Sparkles } from "lucide-react"

interface TypingIndicatorProps {
  processingState: string
}

export function TypingIndicator({ processingState }: TypingIndicatorProps) {
  return (
    <div className="flex gap-4 mb-2">
      <Avatar className="w-10 h-10 flex-shrink-0 shadow-md bg-gradient-to-br from-[#0093d0] to-[#004d7a]">
        <AvatarFallback className="text-white">
          <Sparkles className="w-5 h-5 animate-pulse" />
        </AvatarFallback>
      </Avatar>

      <div className="flex-1">
        <div className="inline-block p-5 rounded-2xl rounded-bl-md bg-white border border-gray-200/60 backdrop-blur-sm shadow-sm">
          <div className="flex items-center gap-4">
            <div className="flex gap-1">
              <div className="w-3 h-3 bg-gradient-to-r from-[#0093d0] to-[#0077b3] rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
              <div className="w-3 h-3 bg-gradient-to-r from-[#0077b3] to-[#0066a3] rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
              <div className="w-3 h-3 bg-gradient-to-r from-[#0066a3] to-[#004d7a] rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
            </div>
            {processingState ? (
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-blue-600 animate-pulse" />
                <span className="text-sm text-gray-700 animate-pulse font-medium">{processingState}</span>
              </div>
            ) : (
              <span className="text-sm text-gray-600 font-medium">Processando sua pergunta...</span>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
