'use client'

import { useEffect } from 'react'
import { useBoolean, useWindowSize } from 'codekit'
import { AnimatePresence, motion } from 'framer-motion'
import { Dialog, DialogContent, DialogTrigger, DialogTitle } from '@/components/ui/dialog'
import { ScrollArea } from '@/components/ui/scroll-area'
import { VisuallyHidden } from '@radix-ui/react-visually-hidden'

import { env } from '../app/config/env'
import { t } from '@/i18n'

interface ModalInfoChatProps {
  children: React.ReactNode | React.JSX.Element
}

function FormatText(text: string) {
  const boldConverted = text
    .replace(/<s><s>(.*?)<\/s><\/s>/g, '<strong>$1</strong>')
    .replace(/<<([^>]+)>>/g, '<strong>$1</strong>')
  const withLineBreaks = boldConverted.replace(/\n/g, '<br>')

  const linkMatch = withLineBreaks.match(/<link>(.*?)<\/link>/)
  const link = linkMatch ? linkMatch[1] : null

  const titleMatch = withLineBreaks.match(/<titleLink>(.*?)<\/titleLink>/)
  const title = titleMatch ? titleMatch[1] : null

  let result = withLineBreaks

  if (link && title) {
    result = result
      .replace(/<link>(.*?)<\/link>/, '')
      .replace(
        /<titleLink>(.*?)<\/titleLink>/,
        `<a href="${link}" target="_blank" rel="noopener noreferrer" class="text-primary underline hover:opacity-80">${title}</a>`
      )
  }

  return result
}

function ModalInfoChat({ children }: ModalInfoChatProps) {
  const size = useWindowSize()
  const isActive = useBoolean()

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const hasVisited = localStorage.getItem('hasVisitedModalInfoChat')
      if (!hasVisited) {
        isActive.setTrue()
        localStorage.setItem('hasVisitedModalInfoChat', 'true')
      }
    }
  }, [isActive])

  return (
    <Dialog open={isActive.value} onOpenChange={isActive.setValue}>
      {env.NEXT_PUBLIC_APP_COMPLIANCE === 'true' && (
        <DialogTrigger asChild>
          <div onClick={isActive.setTrue}>{children}</div>
        </DialogTrigger>
      )}

      <DialogContent className="max-w-[90vw] sm:max-w-[500px]">
        <VisuallyHidden>
          <DialogTitle>Informações do Aplicativo</DialogTitle>
        </VisuallyHidden>

        <div className="text-center pb-2">
          <h1 className="text-xl font-bold text-gray-900 dark:text-gray-100">
            {env.NEXT_PUBLIC_APP_NAME}
          </h1>
        </div>

        <AnimatePresence initial={false}>
          <motion.div
            className="overflow-hidden"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
          > 
            <ScrollArea className="max-h-[300px]">
              <div
                className="modal-info text-sm text-gray-700 dark:text-gray-300"
                dangerouslySetInnerHTML={{ __html: FormatText(t('disclaimer')) }}
              />
            </ScrollArea>
          </motion.div>
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  )
}

export default ModalInfoChat
