"use client"

import { Sparkles } from "lucide-react"
import { useState } from "react"
import { env } from "../app/config/env"
import ModalInfoChat from "./disclaimer-model"
import { Info } from "lucide-react"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { useAvatar } from "@/hooks/use-avatar"
import { useAuth } from "@/hooks/use-auth"

interface ChatHeaderProps {}

export function ChatHeader({}: ChatHeaderProps) {
  const [isPopupVisible, setIsPopupVisible] = useState(false)
  const { profileImage, initials, username, fullName, shortName } = useAvatar()
  const { userId } = useAuth()

  const togglePopup = () => {
    setIsPopupVisible(!isPopupVisible)
  }

  const handleLogout = async () => {
    try {
      // Usar logout do MSAL diretamente
      const { msalInstance } = await import("../app/config/msalConfig")
      await msalInstance.logoutRedirect()
    } catch (error) {
      console.error("Erro no logout:", error)
    }
  }

  return (
    <header className="border-b border-gray-200 bg-white px-3 sm:px-6 py-3 sm:py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 sm:gap-4 min-w-0 flex-1">
          <div className="flex items-center gap-2 sm:gap-3 min-w-0">
            <img
              src="/logo.png"
              alt="Fiocruz"
              className="h-6 sm:h-8 flex-shrink-0"
            />
            
            <div className="hidden sm:block h-6 w-px bg-gray-300 flex-shrink-0" />

            <div className="flex items-center gap-1.5 sm:gap-2 min-w-0">
              <div className="w-6 h-6 sm:w-8 sm:h-8 bg-gradient-to-br from-[#0093d0] to-[#004d7a] rounded-full flex items-center justify-center flex-shrink-0">
                <Sparkles className="w-3 h-3 sm:w-4 sm:h-4 text-white" />
              </div>
              <div className="min-w-0">
                <h1 className="text-sm sm:text-lg font-semibold text-gray-900 truncate">
                  {env.NEXT_PUBLIC_APP_NAME}
                </h1>
                <p className="text-xs text-gray-500 hidden lg:block truncate">
                  {env.NEXT_PUBLIC_APP_DESCRIPTION}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
          <ModalInfoChat>
            <button className="w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center border border-gray-300 shadow-sm cursor-pointer hover:bg-gray-100 transition">
              <Info className="w-4 h-4 sm:w-5 sm:h-5 text-gray-700" />
            </button>
          </ModalInfoChat>

          <div className="relative">
            <button
              onClick={togglePopup}
              className="w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center border border-gray-300 shadow-sm cursor-pointer hover:bg-gray-100 transition overflow-hidden"
              aria-label="User menu"
            >
              <Avatar className="size-8 sm:size-10">
                {profileImage && (
                  <AvatarImage src={profileImage} alt="User avatar" />
                )}
                <AvatarFallback className="bg-gradient-to-br from-[#0093d0] to-[#004d7a] text-white text-xs sm:text-sm font-medium">
                  {initials}
                </AvatarFallback>
              </Avatar>
            </button>

            {isPopupVisible && (
              <div className="absolute right-0 mt-2 sm:mt-3 w-56 sm:w-64 rounded-xl bg-white shadow-xl border border-gray-200 z-50 p-3 sm:p-4 animate-in fade-in-0 zoom-in-95">
                <div className="flex items-center gap-2 sm:gap-3 mb-3">
                  <Avatar className="size-10 sm:size-12">
                    {profileImage && (
                      <AvatarImage src={profileImage} alt="User avatar" />
                    )}
                    <AvatarFallback className="bg-gradient-to-br from-[#0093d0] to-[#004d7a] text-white font-medium text-sm">
                      {initials}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col text-sm text-gray-700 min-w-0">
                    <span className="font-medium truncate max-w-[120px] sm:max-w-[140px]" title={fullName}>{(fullName && fullName !== 'User') ? fullName : (shortName || username || 'User')}</span>
                    <span className="text-xs text-gray-500">Signed in</span>
                  </div>
                </div>
                <div className="border-t border-gray-200 my-2 sm:my-3" />
                <button
                  onClick={handleLogout}
                  className="w-full text-left flex items-center gap-2 text-red-500 text-sm hover:text-red-600 transition cursor-pointer"
                >
                  ↩ Logout account
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  )
}
