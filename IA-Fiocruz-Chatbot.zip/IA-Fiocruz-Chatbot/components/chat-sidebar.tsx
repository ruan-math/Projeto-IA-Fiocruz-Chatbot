"use client"

import { useState, useEffect, useMemo, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet"
import { Plus, Search, MessageSquare, Trash2, Edit3, MoreHorizontal, Menu, ChevronLeft, ChevronRight, X } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { cn } from "@/lib/utils"
import { t } from "../i18n"
import { useToast } from "@/hooks/use-toast"

interface Conversation {
  id: string
  title: string
  timestamp: Date
  messageCount: number
  lastMessage?: string
}

interface ChatSidebarProps {
  currentConversationId: string | null
  onConversationSelect: (id: string | null) => void
  isCollapsed?: boolean
  onToggleCollapse?: (collapsed: boolean) => void
  onReloadRef?: (reloadFn: () => Promise<void>) => void
  userId?: string | null
}

export function ChatSidebar({ 
  currentConversationId, 
  onConversationSelect, 
  isCollapsed = false, 
  onToggleCollapse,
  onReloadRef,
  userId,
}: ChatSidebarProps) {
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [deletingConversationId, setDeletingConversationId] = useState<string | null>(null)
  const { toast } = useToast()

  // Load conversations from API
  useEffect(() => {
    loadConversations()
    onReloadRef && onReloadRef(loadConversations)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId])

  const loadConversations = async () => {
    setIsLoading(true)
    try {
      const url = userId 
        ? `/api/conversations?userId=${encodeURIComponent(userId)}`
        : '/api/conversations'
      
      const response = await fetch(url)
      if (response.ok) {
        const data = await response.json()
        // Conversations are already sorted by most recent activity from the API
        const formattedConversations = data.conversations.map((conv: any) => ({
          id: conv.id,
          title: conv.title || (conv.lastMessage ? conv.lastMessage.substring(0, 50) + '...' : 'Nova Conversa'),
          timestamp: new Date(conv.updatedAt),
          messageCount: conv.messageCount,
          lastMessage: conv.lastMessage,
        }))
        setConversations(formattedConversations)
      }
    } catch (error) {
      console.error('Error loading conversations:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const [searchQuery, setSearchQuery] = useState("")
  const [isOpen, setIsOpen] = useState(false)

  // Memoize filtered conversations to prevent unnecessary re-renders
  const filteredConversations = useMemo(() => {
    if (!searchQuery.trim()) {
      return conversations
    }
    return conversations.filter((conv) =>
      conv.title.toLowerCase().includes(searchQuery.toLowerCase()),
    )
  }, [conversations, searchQuery])

  // Memoize the search input change handler
  const handleSearchChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value)
  }, [])

  // Memoize the clear search handler
  const handleClearSearch = useCallback(() => {
    setSearchQuery("")
  }, [])

  // Memoize the timestamp formatter to prevent recreation on every render
  const formatTimestamp = useCallback((date: Date) => {
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffMins = Math.floor(diffMs / (1000 * 60))
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60))
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24))

    if (diffMins < 60) {
      return `${diffMins}m ago`
    } else if (diffHours < 24) {
      return `${diffHours}h ago`
    } else {
      return `${diffDays}d ago`
    }
  }, [])

  // Memoize the create new conversation handler
  const createNewConversation = useCallback(() => {
    // Do not create a fake ID; let the backend create the conversation on first message
    onConversationSelect(null)
    setIsOpen(false)
  }, [onConversationSelect])

  // Memoize the delete conversation handler
  const deleteConversation = useCallback(async (id: string) => {
    if (deletingConversationId) return // Prevent multiple simultaneous deletions
    
    setDeletingConversationId(id)
    try {
      // First, make the API call to delete from database
      const response = await fetch(`/api/conversations?id=${encodeURIComponent(id)}`, {
        method: 'DELETE',
      })

      if (!response.ok) {
        throw new Error(`Failed to delete conversation: ${response.statusText}`)
      }

      // Only update UI after successful deletion from database
      setConversations((prev) => prev.filter((conv) => conv.id !== id))
      
      // If the deleted conversation was currently selected, switch to another one
      if (currentConversationId === id) {
        const remainingConversations = conversations.filter((conv) => conv.id !== id)
        onConversationSelect(remainingConversations[0]?.id ?? null)
      }

      // Show success notification
      toast({
        title: "Conversa deletada",
        description: "A conversa foi removida com sucesso.",
      })
    } catch (error) {
      console.error('Error deleting conversation:', error)
      toast({
        title: "Erro ao deletar conversa",
        description: "Não foi possível deletar a conversa. Tente novamente.",
        variant: "destructive",
      })
    } finally {
      setDeletingConversationId(null)
    }
  }, [currentConversationId, onConversationSelect, conversations, deletingConversationId, toast])

  // Memoize the sidebar content to prevent unnecessary re-renders
  const SidebarContent = useMemo(() => (
    <div className="flex flex-col h-full bg-white w-full overflow-hidden">
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between mb-4">
          {!isCollapsed && <h2 className="font-semibold text-gray-900">{t('chat_history')}</h2>}
          {onToggleCollapse && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => onToggleCollapse(!isCollapsed)}
              className="p-1 h-8 w-8 hidden md:flex"
            >
              {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
            </Button>
          )}
        </div>

        {!isCollapsed && (
          <>
            <Button onClick={createNewConversation} className="w-full bg-[#003366] hover:bg-[#002244] text-white">
              <Plus className="w-4 h-4 mr-2" />
              {t('new_chat')}
            </Button>

            <div className="relative mt-3">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                key="search-input"
                placeholder={t('search_in_chats')}
                value={searchQuery}
                onChange={handleSearchChange}
                className="pl-10 pr-10"
              />
              {searchQuery && (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={handleClearSearch}
                  className="absolute right-1 top-1/2 transform -translate-y-1/2 h-6 w-6 p-0 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full transition-all duration-200"
                >
                  <X className="w-3 h-3" />
                </Button>
              )}
            </div>
          </>
        )}
      </div>

      {!isCollapsed && (
        <div className="flex-1 overflow-y-auto p-2">
        <div className="space-y-1">
          {filteredConversations.map((conversation) => (
            <div key={conversation.id} className="group relative">
              <button
                onClick={() => {
                  onConversationSelect(conversation.id)
                  setIsOpen(false)
                }}
                className={cn(
                  "w-full text-left p-3 rounded-lg transition-colors hover:bg-gray-100",
                  currentConversationId === conversation.id && "bg-blue-50 border border-blue-200",
                )}
              >
                <div className="flex items-start gap-3 min-w-0">
                  <MessageSquare className="w-4 h-4 mt-0.5 flex-shrink-0 text-gray-400" />
                  <div className="flex-1 min-w-0 overflow-hidden">
                    <div className="font-medium text-sm truncate text-gray-900">{conversation.title}</div>
                    <div className="flex items-center justify-between text-xs text-gray-500 mt-1">
                      <span className="truncate mr-2 flex-1">{formatTimestamp(conversation.timestamp)}</span>
                      <span className="bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full flex-shrink-0">
                        {conversation.messageCount}
                      </span>
                    </div>
                  </div>
                </div>
              </button>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="absolute right-2 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity h-6 w-6 p-0"
                  >
                    <MoreHorizontal className="w-3 h-3" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  {/* <DropdownMenuItem>
                    <Edit3 className="w-4 h-4 mr-2" />
                    {t('rename')}
                  </DropdownMenuItem> */}
                  <DropdownMenuItem 
                    onClick={() => deleteConversation(conversation.id)} 
                    className="text-red-600"
                    disabled={deletingConversationId === conversation.id}
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    {deletingConversationId === conversation.id ? 'Deletando...' : t('delete_chat')}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          ))}
        </div>

          {filteredConversations.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">{t('no_chat_found')}</p>
            </div>
          )}
        </div>
      )}
    </div>
  ), [isCollapsed, onToggleCollapse, createNewConversation, searchQuery, handleSearchChange, handleClearSearch, filteredConversations, currentConversationId, onConversationSelect, formatTimestamp, deleteConversation, isLoading, deletingConversationId])

  return (
    <>
      {/* Desktop Sidebar */}
      <div className={cn(
        "hidden md:flex border-r border-gray-200 flex-shrink-0 overflow-hidden transition-all duration-300",
        isCollapsed ? "w-12" : "w-64"
      )}>
        {SidebarContent}
      </div>

      {/* Mobile Sidebar */}
      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetTrigger asChild>
          <Button variant="ghost" size="sm" className="md:hidden fixed top-3 left-3 z-50 bg-white shadow-md border border-gray-200">
            <Menu className="w-4 h-4" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-64 p-0">
          <SheetTitle className="sr-only">Menu de Conversas</SheetTitle>
          {SidebarContent}
        </SheetContent>
      </Sheet>
    </>
  )
}
