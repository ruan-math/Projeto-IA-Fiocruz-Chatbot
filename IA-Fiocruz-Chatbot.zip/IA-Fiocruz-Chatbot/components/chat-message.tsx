"use client"

import { useState } from "react"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Sparkles, User, Clock, ChevronDown, ChevronUp, ThumbsUp, ThumbsDown } from "lucide-react"
import { ReferencesPanel } from "@/components/references-panel"
import { FeedbackModal } from "@/components/feedback-modal"
import { FeedbackMutation } from "@/interface/models/feedbackModels"
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import { t } from "../i18n"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
  startTime?: string
  endTime?: string
  references?: Reference[]
  confidence?: number
  model?: {
    id: string
    responseId?: string
    usage?: {
      promptTokens: number
      completionTokens: number
      totalTokens: number
    }
    finishReason?: string
  }
  processingTime?: number
}

interface Reference {
  id: string
  title: string
  summary: string
  fullContent: string
  source: string
  documentType: string
  score: number
  rerankScore?: number
  language?: string
}

interface ChatMessageProps {
  message: Message
  conversationId?: string
  userId?: string
}

export function ChatMessage({ message, conversationId, userId }: ChatMessageProps) {
  const [showReferences, setShowReferences] = useState(false)
  const [feedbackSubmitted, setFeedbackSubmitted] = useState<'like' | 'dislike' | null>(null)
  const isUser = message.role === "user"

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    })
  }

  const handlePositiveFeedback = async () => {
    if (!conversationId || !userId) return
    
    try {
      const feedbackData: FeedbackMutation = {
        type: 'like',
        chatId: conversationId,
        messageId: message.id,
        userId: userId,
      }
      
      const response = await fetch('/api/feedback', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(feedbackData),
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const result = await response.json()
      console.log('Positive feedback saved:', result)
      setFeedbackSubmitted('like')
    } catch (error) {
      console.error('Error submitting positive feedback:', error)
    }
  }

  const handleNegativeFeedback = async (data: FeedbackMutation) => {
    if (!conversationId || !userId) return
    
    try {
      const feedbackData: FeedbackMutation = {
        ...data,
        chatId: conversationId,
        messageId: message.id,
        userId: userId,
      }
      
      const response = await fetch('/api/feedback', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(feedbackData),
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const result = await response.json()
      console.log('Negative feedback saved:', result)
      setFeedbackSubmitted('dislike')
    } catch (error) {
      console.error('Error submitting negative feedback:', error)
    }
  }

  return (
    <div className={`flex gap-2 sm:gap-4 ${isUser ? "flex-row-reverse" : "flex-row"} mb-2`}>
      {/* Avatar */}
      <Avatar className={`w-8 h-8 sm:w-10 sm:h-10 flex-shrink-0 shadow-md ${isUser ? "bg-gradient-to-br from-slate-500 to-slate-600" : "bg-gradient-to-br from-[#0093d0] via-[#0077b3] to-[#004d7a]"}`}>
        <AvatarFallback className="text-white text-xs sm:text-sm">
          {isUser ? <User className="w-4 h-4 sm:w-5 sm:h-5" /> : <Sparkles className="w-4 h-4 sm:w-5 sm:h-5" />}
        </AvatarFallback>
      </Avatar>

      {/* Message Content */}
      <div className={`flex-1 max-w-[90%] sm:max-w-[85%] ${isUser ? "text-right" : "text-left"}`}>
        {/* Message Bubble */}
        <div
          className={`inline-block p-3 sm:p-5 rounded-xl sm:rounded-2xl shadow-sm ${
            isUser
              ? "bg-gradient-to-r from-slate-100 to-slate-50 text-slate-700 rounded-br-md border border-slate-200"
              : "bg-white text-gray-900 rounded-bl-md border border-gray-200/60 backdrop-blur-sm"
          }`}
        >
          <div className="chat-message text-sm sm:text-base leading-6 sm:leading-7 font-normal tracking-wide">
            <ReactMarkdown 
              remarkPlugins={[remarkGfm]}
              components={{
                h1: ({children}) => <h1 className="text-xl font-bold text-gray-900 mb-3">{children}</h1>,
                h2: ({children}) => <h2 className="text-lg font-bold text-gray-900 mb-2 mt-4">{children}</h2>,
                h3: ({children}) => <h3 className="text-base font-bold text-gray-900 mb-2 mt-3">{children}</h3>,
                h4: ({children}) => <h4 className="text-sm font-bold text-gray-900 mb-1 mt-2">{children}</h4>,
                p: ({children}) => <p className="mb-2">{children}</p>,
                ul: ({children}) => <ul className="list-disc list-inside mb-2 space-y-1">{children}</ul>,
                ol: ({children}) => <ol className="list-decimal list-inside mb-2 space-y-1">{children}</ol>,
                li: ({children}) => <li className="text-gray-700">{children}</li>,
                strong: ({children}) => <strong className="font-semibold text-gray-900">{children}</strong>,
                em: ({children}) => <em className="italic text-gray-700">{children}</em>,
                code: ({children}) => <code className="bg-gray-100 px-1 py-0.5 rounded text-sm font-mono">{children}</code>,
                pre: ({children}) => <pre className="bg-gray-50 p-3 rounded-lg overflow-x-auto text-sm">{children}</pre>,
                blockquote: ({children}) => <blockquote className="border-l-4 border-gray-300 pl-4 italic text-gray-600">{children}</blockquote>,
              }}
            >
              {message.content}
            </ReactMarkdown>
          </div>
        </div>

        {/* Message Metadata */}
        <div
          className={`flex items-center gap-1 sm:gap-2 mt-2 sm:mt-3 text-xs text-gray-500 ${isUser ? "justify-end" : "justify-start"} flex-wrap`}
        >
          <Clock className="w-3 h-3 flex-shrink-0" />
          <span className="flex-shrink-0">{formatTime(message.timestamp)}</span>

          {!isUser && message.model && (
            <>
              <span className="hidden sm:inline">•</span>
              <Badge variant="outline" className="text-xs px-1.5 sm:px-2 py-0.5 bg-gradient-to-r from-[#e6f7ff] to-[#f0f9ff] border-[#0093d0] text-[#0093d0] flex-shrink-0">
                <Sparkles className="w-2.5 h-2.5 mr-1" />
                <span className="hidden sm:inline">{message.model?.id || 'Unknown Model'}</span>
                <span className="sm:hidden">AI</span>
              </Badge>
            </>
          )}
          {!isUser && message.startTime && message.endTime && (
            <>
              <span className="hidden sm:inline">•</span>
              <span className="text-green-600 font-medium flex-shrink-0">
                {((new Date(message.endTime).getTime() - new Date(message.startTime).getTime()) / 1000).toFixed(1)}s
              </span>
            </>
          )}

          {/* Feedback Buttons - Only for assistant messages */}
          {!isUser && (
            <>
              <span className="hidden sm:inline">•</span>
              {/* Positive Feedback Button */}
              <Button
                variant="ghost"
                size="sm"
                onClick={handlePositiveFeedback}
                disabled={feedbackSubmitted !== null}
                className={`h-5 sm:h-6 px-1.5 sm:px-2 text-xs ${
                  feedbackSubmitted === 'like' 
                    ? 'text-green-600 bg-green-50' 
                    : 'text-gray-500 hover:text-green-600 hover:bg-green-50'
                }`}
              >
                <ThumbsUp className="w-3 h-3 sm:mr-1" />
                <span className="hidden sm:inline">{feedbackSubmitted === 'like' ? t('thanks') : t('useful')}</span>
              </Button>

              {/* Negative Feedback Button */}
              {feedbackSubmitted !== 'dislike' ? (
                <FeedbackModal onSend={handleNegativeFeedback}>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-5 sm:h-6 px-1.5 sm:px-2 text-xs text-gray-500 hover:text-red-600 hover:bg-red-50"
                  >
                    <ThumbsDown className="w-3 h-3 sm:mr-1" />
                    <span className="hidden sm:inline">{t('not_useful')}</span>
                  </Button>
                </FeedbackModal>
              ) : (
                <span className="text-xs text-red-600 bg-red-50 px-1.5 sm:px-2 py-1 rounded">
                  {t('feedback_sent')}
                </span>
              )}
            </>
          )}
        </div>

        {/* References Section - Discrete */}
        {!isUser && message.references && message.references.length > 0 && (
          <div className="mt-2 sm:mt-3">
            <Button
              variant="ghost"
              onClick={() => setShowReferences(!showReferences)}
              className="h-auto p-1.5 sm:p-2 text-left justify-start hover:bg-gray-50 transition-colors duration-150"
            >
              <div className="flex items-center gap-1.5 sm:gap-2 text-xs text-gray-500">
                <span className="text-sm">📎</span>
                <span className="hidden sm:inline">{message.references.length} {message.references.length === 1 ? t('reference') : t('references')}</span>
                <span className="sm:hidden">{message.references.length}</span>
                {showReferences ? (
                  <ChevronUp className="w-3 h-3 ml-1" />
                ) : (
                  <ChevronDown className="w-3 h-3 ml-1" />
                )}
              </div>
            </Button>

            {showReferences && (
              <div className="mt-2 animate-in slide-in-from-top-1 duration-150">
                <ReferencesPanel references={message.references} onToggle={() => setShowReferences(!showReferences)} />
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
