"use client"

import { useState } from "react"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

import { ChevronDown, ChevronUp } from "lucide-react"

import { t } from "../i18n"

interface Reference {
  id?: string
  title?: string
  summary?: string
  fullContent?: string
  source?: string
  documentType?: string
  score?: number
  rerankScore?: number
  language?: string
  metadata?: { source?: string; documentType?: string }
  content?: string
}

interface ReferencesPanelProps {
  references: Reference[]
  onToggle: () => void
}

export function ReferencesPanel({ references, onToggle }: ReferencesPanelProps) {
  const [expandedCards, setExpandedCards] = useState<Set<string>>(new Set())
  const [expandAll, setExpandAll] = useState(false)
  const [expandedContentCards, setExpandedContentCards] = useState<Set<string>>(new Set())


  const getDocumentTypeColor = (type: string) => {
    switch (type) {
      case "MANUAL":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "POLICY":
        return "bg-green-100 text-green-800 border-green-200"
      case "PROCEDURE":
        return "bg-purple-100 text-purple-800 border-purple-200"
      case "REPORT":
        return "bg-orange-100 text-orange-800 border-orange-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  const getDocumentTypeBorder = (type: string) => {
    switch (type) {
      case "MANUAL":
        return "border-l-blue-500"
      case "POLICY":
        return "border-l-green-500"
      case "PROCEDURE":
        return "border-l-purple-500"
      case "REPORT":
        return "border-l-orange-500"
      default:
        return "border-l-gray-500"
    }
  }

  const toggleCard = (id: string) => {
    const newExpanded = new Set(expandedCards)
    if (newExpanded.has(id)) {
      newExpanded.delete(id)
    } else {
      newExpanded.add(id)
    }
    setExpandedCards(newExpanded)
  }

  const toggleExpandAll = () => {
    if (expandAll) {
      setExpandedCards(new Set())
    } else {
      setExpandedCards(new Set(references.map((ref) => ref.id).filter((id): id is string => !!id)))
    }
    setExpandAll(!expandAll)
  }

  const toggleContentHeight = (id: string) => {
    setExpandedContentCards(prev => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
  }



  const truncateSource = (source: string, maxLength = 50) => {
    if (source.length <= maxLength) return source
    return "..." + source.slice(-(maxLength - 3))
  }

  // Early return if no references
  if (!references || references.length === 0) {
    return null;
  }

  return (
    <div className="mt-2 space-y-1 animate-in slide-in-from-top-1 duration-200">
      {/* Minimal Header */}
      <div className="flex justify-between items-center px-1">
        <div className="text-xs text-gray-400">
          <span className="hidden sm:inline">{references.length} {references.length === 1 ? t('document') : t('documents')}</span>
          <span className="sm:hidden">{references.length} docs</span>
        </div>
        <Button variant="ghost" size="sm" onClick={toggleExpandAll} className="text-xs h-4 sm:h-5 px-1 text-gray-400 hover:text-gray-600">
          {expandAll ? "−" : "+"}
        </Button>
      </div>

      {/* Minimal Reference List */}
      <div className="space-y-1">
        {references.map((reference, idx) => {
          const refId = reference.id || `${idx}`
          const isExpanded = expandedCards.has(refId)
          const isContentExpanded = expandedContentCards.has(refId)
          const src = reference.source || reference.metadata?.source || ""
          const docType = reference.documentType || reference.metadata?.documentType || ""
          const docCode = src.match(/(MANUAL|POLICY|PROCEDURE|REPORT)-[^\/\s]+/)?.[0] || docType
          const rawSummary = reference.summary || reference.fullContent || reference.content || ""
          const isSummaryTruncated = rawSummary.length > 60
          const displaySummary = isSummaryTruncated ? rawSummary.substring(0, 60) + "..." : rawSummary
          const displayFullContent = reference.fullContent || reference.content || ""

          return (
            <div
              key={refId}
              className={`border-l-2 ${getDocumentTypeBorder(docType)} bg-gray-50/50 rounded-r`}
            >
              {/* Minimal Header */}
              <div className="flex items-center justify-between px-1.5 sm:px-2 py-1 hover:bg-gray-100/50 transition-colors duration-150 cursor-pointer" onClick={() => toggleCard(refId)}>
                <div className="flex items-center gap-1.5 sm:gap-2 flex-1 min-w-0">
                  <Badge variant="secondary" className={`text-xs px-1 py-0 font-normal ${getDocumentTypeColor(docType)}`}>
                    <span className="hidden sm:inline">{docCode}</span>
                    <span className="sm:hidden">{docCode.split('-')[0]}</span>
                  </Badge>
                  <div className="text-xs text-gray-600 truncate flex-1">
                    <span className="hidden sm:inline">{displaySummary}</span>
                    <span className="sm:hidden">{displaySummary.substring(0, 30)}...</span>
                  </div>
                </div>
                
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-4 w-4 sm:h-5 sm:w-5 p-0 shrink-0"
                >
                  {isExpanded ? <ChevronUp className="w-3 h-3 text-gray-400" /> : <ChevronDown className="w-3 h-3 text-gray-400" />}
                </Button>
              </div>

              {/* Expanded Content - Minimal */}
              {isExpanded && (
                <div className="px-1.5 sm:px-2 pb-2 animate-in slide-in-from-top-1 duration-150">
                  <div className="bg-white/80 rounded p-1.5 sm:p-2 text-xs border border-gray-200/60 relative group">
                    <div
                      className={`text-gray-700 leading-relaxed whitespace-pre-wrap ${isContentExpanded ? 'max-h-none' : 'max-h-32 sm:max-h-48'} overflow-y-auto cursor-pointer pr-1`}
                      onClick={() => toggleContentHeight(refId)}
                      title={isContentExpanded ? t('click_to_collapse') ?? 'Recolher' : t('click_to_expand') ?? 'Expandir'}
                    >
                      {displayFullContent}
                    </div>
                    {!isContentExpanded && displayFullContent.length > 400 && (
                      <div className="absolute bottom-7 sm:bottom-9 left-0 right-0 h-8 sm:h-10 bg-gradient-to-t from-white to-transparent pointer-events-none" />
                    )}
                    <div className="mt-1.5 sm:mt-2 flex items-center justify-between gap-1 sm:gap-2 pt-1.5 sm:pt-2 border-t border-gray-100 text-xs text-gray-400">
                      <span className="truncate flex-1" title={src}>
                        <span className="hidden sm:inline">{truncateSource(src, 80)}</span>
                        <span className="sm:hidden">{truncateSource(src, 40)}</span>
                      </span>
                      <button
                        type="button"
                        onClick={() => toggleContentHeight(refId)}
                        className="text-[10px] uppercase tracking-wide font-medium text-blue-600 hover:text-blue-700 flex-shrink-0"
                      >
                        {isContentExpanded ? t('collapse') ?? 'Menos' : t('expand') ?? 'Mais'}
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
