"use client"

import { Badge } from "@/components/ui/badge"
import { Database, Brain, Clock } from "lucide-react"

export function StatusBar() {
  return (
    <div className="border-t border-gray-200 bg-gray-50 px-6 py-2">
      <div className="flex items-center justify-between text-xs text-gray-600">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Database className="w-3 h-3" />
            <span>Azure Cosmos DB Connected</span>
            <Badge variant="secondary" className="bg-green-100 text-green-800 text-xs">
              <div className="w-1.5 h-1.5 bg-green-500 rounded-full mr-1" />
              Active
            </Badge>
          </div>

          <div className="flex items-center gap-2">
            <Brain className="w-3 h-3" />
            <span>Documentos institucionais da Fiocruz indexados</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Clock className="w-3 h-3" />
          <span>Last updated: 2 hours ago</span>
        </div>
      </div>
    </div>
  )
}
