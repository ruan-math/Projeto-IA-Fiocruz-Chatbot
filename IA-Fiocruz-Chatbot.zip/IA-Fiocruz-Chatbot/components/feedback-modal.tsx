"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Textarea } from "@/components/ui/textarea"
import { Separator } from "@/components/ui/separator"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { 
  FeedbackMutation,
  harmfulContentReasonMap,
  negativeFeedbackReasonMap,
  NegativeFeedbackReason,
  HarmfulContentReason
} from "@/interface/models/feedbackModels"
import { useAuth } from "@/hooks/use-auth"
import { t } from "@/i18n"

interface FeedbackModalProps {
  children: React.ReactNode
  onSend?: (data: FeedbackMutation) => Promise<void> | void
}

export function FeedbackModal({ children, onSend }: FeedbackModalProps) {
  const { userId } = useAuth()
  const [isOpen, setIsOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [showHarmfulContent, setShowHarmfulContent] = useState(false)
  
  // Form state
  const [formData, setFormData] = useState<FeedbackMutation>({
    type: 'dislike',
    chatId: '',
    messageId: '',
    userId: userId || 'anonymous',
  })

  // Update userId when auth changes
  useEffect(() => {
    setFormData(prev => ({
      ...prev,
      userId: userId || 'anonymous'
    }))
  }, [userId])

  const handleNegativeReasonChange = (reason: NegativeFeedbackReason, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      negativeFeedbackReasons: {
        ...prev.negativeFeedbackReasons,
        [reason]: checked
      }
    }))
  }

  const handleHarmfulReasonChange = (reason: HarmfulContentReason, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      harmfulContentReasons: {
        ...prev.harmfulContentReasons,
        [reason]: checked
      }
    }))
  }

  const handleDescriptionChange = (value: string) => {
    setFormData(prev => ({
      ...prev,
      description: value
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!onSend) return

    setIsLoading(true)
    try {
      await onSend(formData)
      setIsOpen(false)
      // Reset form
      setFormData({
        type: 'dislike',
        chatId: '',
        messageId: '',
        userId: '',
      })
      setShowHarmfulContent(false)
    } catch (error) {
      console.error('Error sending feedback:', error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <div onClick={() => setIsOpen(true)}>
          {children}
        </div>
      </DialogTrigger>

      <DialogContent className="sm:max-w-[550px]">
        <DialogHeader>
          <DialogTitle>Feedback</DialogTitle>
          <DialogDescription>
            {t('text_popup')}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          <div className="space-y-6 py-4">
            {/* Razões de feedback negativo */}
            <div className="space-y-3">
              <Label className="text-sm font-semibold">{t('question_feedback')}</Label>
              <div className="space-y-2">
                {Object.entries(negativeFeedbackReasonMap).map(([value, label]) => (
                  <div key={value} className="flex items-center space-x-2">
                    <Checkbox
                      id={`negative-${value}`}
                      checked={formData.negativeFeedbackReasons?.[value as NegativeFeedbackReason] || false}
                      onCheckedChange={(checked) => 
                        handleNegativeReasonChange(value as NegativeFeedbackReason, checked as boolean)
                      }
                    />
                    <Label htmlFor={`negative-${value}`} className="text-sm font-normal cursor-pointer">
                      {label}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            {showHarmfulContent && <Separator />}

            {/* Razões de conteúdo prejudicial */}
            {showHarmfulContent && (
              <div className="space-y-3">
                <Label className="text-sm font-semibold">{t('question_feedback_report')}</Label>
                <div className="space-y-2">
                  {Object.entries(harmfulContentReasonMap).map(([value, label]) => (
                    <div key={value} className="flex items-center space-x-2">
                      <Checkbox
                        id={`harmful-${value}`}
                        checked={formData.harmfulContentReasons?.[value as HarmfulContentReason] || false}
                        onCheckedChange={(checked) => 
                          handleHarmfulReasonChange(value as HarmfulContentReason, checked as boolean)
                        }
                      />
                      <Label htmlFor={`harmful-${value}`} className="text-sm font-normal cursor-pointer">
                        {label}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Campo de descrição */}
            {!showHarmfulContent && (
              <div className="space-y-2">
                <Label htmlFor="description" className="text-sm font-semibold">
                  {t('comments')}
                </Label>
                <Textarea
                  id="description"
                  placeholder={t('add_comment')}
                  value={formData.description || ''}
                  onChange={(e) => handleDescriptionChange(e.target.value)}
                  className="min-h-[80px]"
                />
              </div>
            )}

            {/* Botão para reportar conteúdo inadequado */}
            {!showHarmfulContent && (
              <button
                type="button"
                onClick={() => setShowHarmfulContent(true)}
                className="text-sm text-red-600 hover:text-red-700 underline"
              >
                {t('report_content')}
              </button>
            )}
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setIsOpen(false)}
              disabled={isLoading}
            >
              {t('cancel')}
            </Button>
            <Button 
              type="submit" 
              disabled={isLoading}
              className="bg-[#003366] hover:bg-[#002244] text-white"
            >
              {isLoading ? t('sending') : t('send')+' Feedback'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
