"use client"

import { useEffect, useState } from "react"
import "./globals.css"
import { msalInstance, initializeMsal } from "./config/msalConfig"
import { env } from "./config/env"
import { getCookie, setCookie } from 'codekit';
import { t } from "@/i18n";


export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  const [error, setError] = useState<{
    title: string;
    message: string;
  } | null>(null);
  const [authToken, setAuthToken] = useState<string | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [msalInitialized, setMsalInitialized] = useState(false);

  useEffect(() => {
    const initializeApp = async () => {
      // Se MSAL está desabilitado, pular autenticação
      if (env.NEXT_PUBLIC_DISABLE_MSAL) {
        console.log('Modo de desenvolvimento sem autenticação - MSAL desabilitado');
        setIsAuthenticated(true);
        setIsLoading(false);
        setMsalInitialized(true);
        
        // Definir dados de usuário fictícios para desenvolvimento
        sessionStorage.setItem("azure-account-name", "Usuário Desenvolvimento");
        setCookie('azure-account-username', 'dev@fiocruz.br', {
          path: '/',
          sameSite: 'None',
          secure: true,
          expires: new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 horas
        });
        setCookie('azure-account-id', 'dev-user-id', {
          path: '/',
          sameSite: 'None',
          secure: true,
          expires: new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 horas
        });
        return;
      }

      const isInsideIframe = window.self !== window.top;
      
      if (!isInsideIframe) {
        // Modo Standalone - usar MSAL
        const handleStandaloneAuth = async () => {
          try {
            // PRIMEIRO: Inicializar o MSAL apenas uma vez usando a função controlada
            await initializeMsal();
            setMsalInitialized(true);

            // Verificar se já há uma conta ativa
            const accounts = msalInstance.getAllAccounts();
            if (accounts.length > 0) {
              const account = accounts[0];
              try {
                const silentResponse = await msalInstance.acquireTokenSilent({
                  scopes: ['User.Read'],
                  account,
                });
                setAuthToken(silentResponse.accessToken);
                setIsAuthenticated(true);
                setIsLoading(false);

                // Buscar dados do usuário após autenticação silenciosa
                try {
                  await fetchUserDetails(silentResponse.accessToken);
                  await fetchGroupsUser(silentResponse.accessToken);
                  await fetchProfileImage(silentResponse.accessToken);
                } catch (fetchError) {
                  console.warn('Erro ao buscar dados do usuário:', fetchError);
                  // Não falha a autenticação se houver erro ao buscar dados adicionais
                }
                return;
              } catch (silentError) {
                // Token expirado, precisa de interação
                console.log('Token expirado, redirecionando para login...');
              }
            }

            // Lidar com redirect response
            const response = await msalInstance.handleRedirectPromise();
            if (response) {
              // Login bem-sucedido
              setAuthToken(response.accessToken);
              setIsAuthenticated(true);
              setIsLoading(false);

              // Buscar dados do usuário após login bem-sucedido
              try {
                await fetchUserDetails(response.accessToken);
                await fetchGroupsUser(response.accessToken);
                await fetchProfileImage(response.accessToken);
              } catch (fetchError) {
                console.warn('Erro ao buscar dados do usuário:', fetchError);
                // Não falha a autenticação se houver erro ao buscar dados adicionais
              }
              return;
            }

            // Se chegou aqui, precisa fazer login
            await msalInstance.loginRedirect({
              scopes: ['User.Read'],
              redirectUri: env.NEXT_PUBLIC_APP_URL || window.location.origin
            });

          } catch (err: unknown) {
            console.error('Erro na autenticação:', err);
            if (err instanceof Error) {
              if (
                err.name === 'InteractionRequiredAuthError' ||
                err.name === 'BrowserAuthError'
              ) {
                await msalInstance.loginRedirect({
                  scopes: ['User.Read'],
                  redirectUri: env.NEXT_PUBLIC_APP_URL || window.location.origin
                });
              } else {
                setError({
                  title: 'Authentication Error',
                  message: err.message,
                });
                setIsLoading(false);
              }
            } else {
              setError({
                title: 'Authentication Error',
                message: 'An unknown error occurred.',
              });
              setIsLoading(false);
            }
          }
        };
        
        await handleStandaloneAuth();
      } else {
        // Modo SharePoint - aguardar token via postMessage
        console.info("Executando dentro do SharePoint")

        // No SharePoint, definir loading como false imediatamente
        setIsLoading(false)

        const handleMessage = async (event: MessageEvent) => {
          if (
            event.origin.toLowerCase().endsWith('.sharepoint.com') &&
            event.data?.type === 'token'
          ) {
            const ssoFlow = async () => {
              try {
                // Inicializar MSAL antes de usar
                await initializeMsal();
                
                const silentResponse = await msalInstance.ssoSilent(
                  {
                    scopes: [
                      'User.Read',
                      'email',
                      'profile',
                      'openid',
                    ],
                  },
                );
                msalInstance.setActiveAccount(
                  silentResponse.account,
                );
                const accessToken = event.data.token
                await fetchUserDetails(accessToken)
                await fetchGroupsUser(accessToken)
                await fetchProfileImage(accessToken)
              } catch (err) {
                if (err instanceof Error) {
                  setError({
                    title: 'SSO Authentication Failed',
                    message: `Could not sign in silently. Please ensure pop-ups are not blocked. Error: ${err.message}`,
                  });
                } else {
                  setError({
                    title: 'Unknown Error',
                    message:
                      'An unknown error occurred during SSO.',
                  });
                }
              }
            };
            ssoFlow();
          }
        }

        window.addEventListener("message", handleMessage)
        return () => window.removeEventListener("message", handleMessage)
      }
    };

    initializeApp();
  }, [])

  // =============================
  // Funções auxiliares (MS Graph)
  // =============================

  const fetchUserDetails = async (token: string) => {
    try {
      const response = await fetch("https://graph.microsoft.com/v1.0/me", {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!response.ok) throw new Error("Erro ao obter dados do usuário.");

      const userData = await response.json();

      // Sempre em sessionStorage
      sessionStorage.setItem("azure-account-name", userData.displayName || "");
      setCookie('azure-account-username', userData.userPrincipalName, {
        path: '/',
        sameSite: 'None',
        secure: true,
      });

      setCookie('azure-account-id', userData.id, {
        path: '/',
        sameSite: 'None',
        secure: true,
      });

      try {
        window.dispatchEvent(new Event("azure-account-name-updated"));
        window.dispatchEvent(new Event("azure-account-username-updated"));
      } catch {
        /* ignore */
      }

      // Antes usava cookies, agora grava só no sessionStorage
      // sessionStorage.setItem("azure-unique-id", userData.id);
      // sessionStorage.setItem("azure-account-username", userData.userPrincipalName);
      // sessionStorage.setItem("azure-account-id", userData.id);
      setCookie('azure-unique-id', userData.id, {
        path: '/',
        sameSite: 'None',
        secure: true,
      });

      setCookie('azure-account-username', userData.userPrincipalName, {
        path: '/',
        sameSite: 'None',
        secure: true,
      });

      setCookie('azure-account-id', userData.id, {
        path: '/',
        sameSite: 'None',
        secure: true,
      });

    } catch (error) {
      console.error("Erro no fetchUserDetails:", error);
    }
  };


  const fetchGroupsUser = async (token: string) => {
    // Buscar o userId do sessionStorage
    let userId = getCookie('azure-account-id');

    // Se não encontrar, buscar do token ou usar 'me'
    if (!userId) {
      try {
        const response = await fetch("https://graph.microsoft.com/v1.0/me", {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (response.ok) {
          const userData = await response.json();
          userId = userData.id;
          setCookie('azure-account-id', userData.id, {
            path: '/',
            sameSite: 'None',
            secure: true,
          });
        }
      } catch (error) {
        console.warn("Não foi possível obter userId para buscar grupos:", error);
        return;
      }
    }

    if (!userId) return;

    try {
      const response = await fetch(
        `https://graph.microsoft.com/v1.0/users/${userId}/memberOf`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      if (!response.ok) return;

      const data = await response.json();
      const baseGroupNames = data.value
        .filter((entry: any) => entry["@odata.type"] === "#microsoft.graph.group")
        .map((group: any) => group.displayName?.trim())
        .filter((name?: string): name is string => !!name);

      const suffixes = ["Visitors", "Members", "Owners"];
      const fullGroupNames = baseGroupNames.flatMap((base: any) =>
        suffixes.map((suffix) => `${base} ${suffix}`)
      );

      const userGroupsFilter = Array.from(new Set(fullGroupNames))
        .map((name) => `security_group/any(g: g eq '${name}')`)
        .join(" or ");

      // Agora salva só no sessionStorage
      setCookie('azure-groups-of-user', userGroupsFilter);
    } catch (error) {
      console.error("Erro no fetchGroupsUser:", error);
    }
  };


  const fetchProfileImage = async (token: string) => {
    // Se já buscou a imagem nesta sessão, não tenta de novo
    if (getCookie('azure-profile-image-fetched')) return;

    try {
      const response = await fetch(
        "https://graph.microsoft.com/v1.0/me/photo/$value",
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      if (response.ok) {
        const blob = await response.blob();
        const reader = new FileReader();

        reader.onloadend = () => {
          // Salva a imagem em base64 (mantém em localStorage pois é mais persistente)
          localStorage.setItem(
            "azure-account-profile-image",
            reader.result as string
          );

          try {
            window.dispatchEvent(new Event("azure-profile-image-updated"));
          } catch {
            /* ignore */
          }

          // Marca que já buscou a foto nesta sessão
          setCookie('azure-profile-image-fetched', 'true', {
            path: '/',
            sameSite: 'None',
            secure: true,
          });
        };

        reader.readAsDataURL(blob);
      } else {
        console.error("Erro ao buscar imagem:", response.statusText);
      }
    } catch (error) {
      console.error("Erro no fetchProfileImage:", error);
    }
  };


  // Renderização condicional para evitar loops
  if (error) {
    return (
      <html lang="en">
        <head>
          <title>Erro de Autenticação - Assistente Fiocruz</title>
        </head>
        <body>
          <div style={{ padding: '20px', textAlign: 'center' }}>
            <h1>{error.title}</h1>
            <p>{error.message}</p>
            <button onClick={() => window.location.reload()}>
              Tentar Novamente
            </button>
          </div>
        </body>
      </html>
    )
  }

  if (isLoading) {
    return (
      <html lang="en">
        <head>
          <title>Carregando - Assistente Fiocruz</title>
        </head>
        <body suppressHydrationWarning={true}>
          <div className="min-h-screen bg-white flex items-center justify-center">
            <div className="flex items-center gap-3 text-gray-500">
              <div className="w-5 h-5 border-2 border-gray-300 border-t-[#003366] rounded-full animate-spin"></div>
              <span className="text-sm">{t('loading')}</span>
            </div>
          </div>
        </body>
      </html>
    )
  }

  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap"
          rel="stylesheet"
        />
        <style>{`
          html {
            font-family: 'Roboto', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
          }
        `}</style>
      </head>
      <body suppressHydrationWarning={true}>
        {children}
      </body>
    </html>
  )
}
