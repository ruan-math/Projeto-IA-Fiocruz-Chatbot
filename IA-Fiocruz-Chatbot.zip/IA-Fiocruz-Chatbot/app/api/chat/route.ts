import { NextRequest, NextResponse } from 'next/server';
import { RAGService } from '@/lib/rag/services/ragService';

// Initialize RAG service
let ragService: RAGService | null = null;

async function initializeRAG() {
  if (!ragService) {
    ragService = new RAGService();
    await ragService.initialize();
  }
  return ragService;
}

export async function POST(req: NextRequest) {
  try {
    const { message, conversationId, userId = 'anonymous', userEmail, options } = await req.json();

    if (!message || typeof message !== 'string') {
      return NextResponse.json({ error: 'Message is required' }, { status: 400 });
    }

    // Initialize RAG service
    const rag = await initializeRAG();

    // Process the query
    const result = await rag.query(message, conversationId, userId, userEmail, {
      topK: options?.topK || 20,
      rerankTopK: options?.rerankTopK || 2,
      includeReferences: options?.includeReferences !== false,
      useReranking: options?.useReranking !== false,
    });

    // Format response for the frontend
    const response = {
      answer: result.response.answer,
      conversationId: result.conversationId,
      references: result.formattedReferences.map(ref => ({
        id: ref.id,
        title: ref.title,
        summary: ref.summary,
        fullContent: ref.fullContent,
        source: ref.source,
        documentType: ref.documentType,
        score: ref.score,
        rerankScore: ref.rerankScore,
        language: ref.language,
      })),
      metadata: {
        model: result.response.model,
        confidence: result.response.confidence,
        processingTime: result.response.processingTime,
        referenceCount: result.formattedReferences.length,
        startTime: (result.response as any).startTime,
        endTime: (result.response as any).endTime,
      },
    };

    return NextResponse.json(response);
  } catch (error) {
    console.error('Chat API error:', error);
    return NextResponse.json(
      { error: 'Internal server error', message: (error as Error).message },
      { status: 500 }
    );
  }
}

export async function GET(req: NextRequest) {
  try {
    const rag = await initializeRAG();
    const stats = await rag.getStats();
    const health = await rag.healthCheck();

    return NextResponse.json({
      status: 'ok',
      health: health.status,
      stats: {
        documents: 'N/A',
        conversations: stats.conversations.totalConversations,
        models: stats.models.filter(m => m.isAvailable).length,
        services: health.services,
      },
    });
  } catch (error) {
    console.error('Health check error:', error);
    return NextResponse.json(
      { error: 'Service unavailable', message: (error as Error).message },
      { status: 503 }
    );
  }
}