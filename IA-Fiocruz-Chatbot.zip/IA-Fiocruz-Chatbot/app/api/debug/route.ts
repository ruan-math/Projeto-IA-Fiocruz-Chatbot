import { NextResponse } from 'next/server';
import { RAGService } from '../../../lib/rag/services/ragService';

let ragService: RAGService | null = null;

async function initializeRAG() {
  if (!ragService) {
    ragService = new RAGService();
    await ragService.initialize();
  }
  return ragService;
}

export async function GET() {
  try {

    const rag = await initializeRAG();
    
    const stats = await rag.getStats();
    const healthCheck = await rag.healthCheck();
    
    return NextResponse.json({
      stats,
      healthCheck,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Debug API error:', error);
    return NextResponse.json(
      { error: 'Failed to get debug stats', details: error instanceof Error ? error.message : String(error) },
      { status: 500 }
    );
  }
}