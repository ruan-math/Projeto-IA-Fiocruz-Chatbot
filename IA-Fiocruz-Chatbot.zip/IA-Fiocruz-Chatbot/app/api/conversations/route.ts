// app/api/conversations/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { Conversation } from '@/interface/models/conversationModels';
import { ChatService } from '@/lib/rag/services/chatService';
import { createContainerIfNotExists, initializeAllContainers } from '@/lib/rag/cosmos/initCosmos';

export async function GET(req: NextRequest) {
  try {
    await initializeAllContainers();
    
    // Get userId from query parameters
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get('userId') || 'anonymous';
    
    const chatService = new ChatService();
    const chats = await chatService.listChats(userId);

    return NextResponse.json({
      conversations: await Promise.all(chats.map(async (chat) => {
        const { messageCount, lastMessage } = await chatService.getChatSummary(chat.id);
        
        return {
          id: chat.id,
          title: chat.title || 'Untitled Conversation',
          messageCount,
          lastMessage,
          createdAt: chat.createdAt,
          updatedAt: chat.updatedAt,
        };
      })),
    });
  } catch (error) {
    console.error('Conversations API error:', error);
    return NextResponse.json(
      { error: 'Internal server error', message: (error as Error).message },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  try {
    await initializeAllContainers();
    const { searchParams } = new URL(req.url);
    const conversationId = searchParams.get('id');

    if (!conversationId) {
      return NextResponse.json({ error: 'Conversation ID is required' }, { status: 400 });
    }

    const chatService = new ChatService();
    await chatService.deleteChat(conversationId);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete conversation error:', error);
    return NextResponse.json(
      { error: 'Internal server error', message: (error as Error).message },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    await initializeAllContainers();
    const body = await req.json();
    const { title, userId } = body;

    if (!title || !userId) {
      return NextResponse.json(
        { error: 'Missing required fields: title and userId' },
        { status: 400 }
      );
    }

    const chatService = new ChatService();
    const chatId = await chatService.createChat(userId, title);
    const chat = await chatService.getChat(chatId);

    return NextResponse.json({
      id: chat?.id,
      title: chat?.title,
      createdAt: chat?.createdAt,
      updatedAt: chat?.updatedAt,
      messages: [],
    }, { status: 201 });
  } catch (error) {
    console.error('Create conversation error:', error);
    return NextResponse.json(
      { error: 'Internal server error', message: (error as Error).message },
      { status: 500 }
    );
  }
}


