// app/api/conversations/[id]/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { ChatService } from '@/lib/rag/services/chatService';
import { CitationService } from '@/lib/rag/services/citationService';
import { createContainerIfNotExists, initializeAllContainers } from '@/lib/rag/cosmos/initCosmos';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    await initializeAllContainers();
    const { id } = await params;
    
    const chatService = new ChatService();
    const citationService = new CitationService();
    const chat = await chatService.getChat(id);

    if (!chat) {
      return NextResponse.json({ error: 'Conversation not found' }, { status: 404 });
    }

    const messages = await chatService.getMessagesByChatId(id);

    // Get citations for each message
    const messagesWithCitations = await Promise.all(
      messages.map(async (msg) => {
        const citations = await citationService.getCitationsByMessageId(msg.id);
        return {
          id: msg.id,
          role: msg.role,
          content: msg.content,
          timestamp: msg.createdAt,
          startTime: msg.startTime,
          endTime: msg.endTime,
          references: citations.map(citation => ({
            id: citation.id,
            title: citation.title,
            summary: citation.content?.substring(0, 200) + (citation.content?.length > 200 ? '...' : ''),
            fullContent: citation.content,
            content: citation.content,
            source: citation.filepath || citation.title || 'Unknown Document',
            documentType: citation.title?.match(/(IMAM|IMSA|IMCP)-[^\/\s]+/)?.[0] || 'UNKNOWN',
            metadata: {
              source: citation.filepath || citation.title || 'Unknown Document',
              documentType: citation.title?.match(/(IMAM|IMSA|IMCP)-[^\/\s]+/)?.[0] || 'UNKNOWN'
            },
            reference: citation.reference,
            url: citation.url,
            filepath: citation.filepath,
            chunk_id: citation.chunk_id,
            citationIndex: citation.citationIndex
          })),
          model: msg.model ? {
            id: msg.model.id,
            responseId: msg.model.responseId,
            usage: msg.model.usage,
            finishReason: msg.model.finishReason
          } : undefined,
          processingTime: msg.model?.usage?.totalTokens ? msg.model.usage.totalTokens / 1000 : undefined,
        };
      })
    );

    return NextResponse.json({
      id: chat.id,
      title: chat.title || 'Untitled Conversation',
      userId: chat.userId || 'anonymous',
      messages: messagesWithCitations,
      createdAt: chat.createdAt,
      updatedAt: chat.updatedAt,
    });
  } catch (error) {
    console.error('Get conversation error:', error);
    return NextResponse.json(
      { error: 'Internal server error', message: (error as Error).message },
      { status: 500 }
    );
  }
}

