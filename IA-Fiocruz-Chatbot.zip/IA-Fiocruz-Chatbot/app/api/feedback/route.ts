// app/api/feedback/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { feedbackController } from '@/lib/rag/controllers/feedbackController';
import { createContainerIfNotExists, initializeAllContainers } from '@/lib/rag/cosmos/initCosmos';
import { Feedback, FeedbackMutation } from '@/interface/models/feedbackModels';
import { v4 as uuidv4 } from 'uuid';

export async function POST(req: NextRequest) {
  try {
    await initializeAllContainers();
    const feedbackData: FeedbackMutation = await req.json();

    // Validate required fields
    if (!feedbackData.chatId || !feedbackData.messageId || !feedbackData.userId) {
      return NextResponse.json(
        { error: 'Missing required fields: chatId, messageId, userId' },
        { status: 400 }
      );
    }

    // Create feedback object
    const feedback: Feedback = {
      id: `fbdk_${uuidv4().replace(/-/g, '')}`,
      chatId: feedbackData.chatId,
      messageId: feedbackData.messageId,
      userId: feedbackData.userId,
      type: feedbackData.type,
      negativeFeedbackReasons: feedbackData.negativeFeedbackReasons,
      harmfulContentReasons: feedbackData.harmfulContentReasons,
      description: feedbackData.description,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    // Save to CosmosDB
    const savedFeedback = await feedbackController.create(feedback);

    return NextResponse.json({
      success: true,
      feedback: savedFeedback,
    });
  } catch (error) {
    console.error('Feedback API error:', error);
    return NextResponse.json(
      { error: 'Internal server error', message: (error as Error).message },
      { status: 500 }
    );
  }
}

export async function GET(req: NextRequest) {
  try {
    await initializeAllContainers();
    const { searchParams } = new URL(req.url);
    const chatId = searchParams.get('chatId');
    const messageId = searchParams.get('messageId');
    const userId = searchParams.get('userId');

    let query;
    if (chatId && messageId && userId) {
      // Get specific feedback
      query = {
        query: 'SELECT * FROM c WHERE c.chatId = @chatId AND c.messageId = @messageId AND c.userId = @userId',
        parameters: [
          { name: '@chatId', value: chatId },
          { name: '@messageId', value: messageId },
          { name: '@userId', value: userId }
        ]
      };
    } else if (chatId) {
      // Get all feedback for a chat
      query = {
        query: 'SELECT * FROM c WHERE c.chatId = @chatId',
        parameters: [{ name: '@chatId', value: chatId }]
      };
    } else {
      // Get all feedback (limit for safety)
      query = {
        query: 'SELECT * FROM c ORDER BY c.createdAt DESC OFFSET 0 LIMIT 100',
        parameters: []
      };
    }

    const feedbacks = await feedbackController.list(query);

    return NextResponse.json({
      feedbacks: feedbacks.map(feedback => ({
        id: feedback.id,
        chatId: feedback.chatId,
        messageId: feedback.messageId,
        userId: feedback.userId,
        type: feedback.type,
        negativeFeedbackReasons: feedback.negativeFeedbackReasons,
        harmfulContentReasons: feedback.harmfulContentReasons,
        description: feedback.description,
        createdAt: feedback.createdAt,
        updatedAt: feedback.updatedAt,
      })),
    });
  } catch (error) {
    console.error('Feedback API error:', error);
    return NextResponse.json(
      { error: 'Internal server error', message: (error as Error).message },
      { status: 500 }
    );
  }
}
