"use client"

import { useState, useRef, useCallback } from "react"
import { ChatSidebar } from "@/components/chat-sidebar"
import { ChatInterface } from "@/components/chat-interface"
import { StatusBar } from "@/components/status-bar"
import { useAuth } from "@/hooks/use-auth"

export default function AgentAssistant() {
  const { userId, isLoading } = useAuth()
  const [currentConversationId, setCurrentConversationId] = useState<string | null>(null)
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const reloadSidebarRef = useRef<null | (() => Promise<void>)>(null)

  // Memoize the history update handler to prevent unnecessary re-renders
  const handleHistoryUpdated = useCallback(async () => {
    if (reloadSidebarRef.current) {
      await reloadSidebarRef.current()
    }
  }, [])

  // Memoize the reload ref setter
  const handleReloadRef = useCallback((fn: () => Promise<void>) => {
    reloadSidebarRef.current = fn
  }, [])

  // Tela de loading
  if (isLoading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando Assistente Fiocruz...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="flex h-screen overflow-hidden">
        <ChatSidebar 
          currentConversationId={currentConversationId} 
          onConversationSelect={setCurrentConversationId}
          isCollapsed={sidebarCollapsed}
          onToggleCollapse={setSidebarCollapsed}
          onReloadRef={handleReloadRef}
          userId={userId}
        />
        <div className="flex-1 flex flex-col min-w-0 relative md:ml-0">
          <ChatInterface 
            conversationId={currentConversationId}
            onConversationIdChange={setCurrentConversationId}
            onHistoryUpdated={handleHistoryUpdated}
          />
          {/* <StatusBar /> */}
        </div>
      </div>
    </div>
  )
}
