import {
	Configuration,
	LogLevel,
	PublicClientApplication,
	EventType,
} from '@azure/msal-browser';

import { env } from './env';

// Validação de variáveis de ambiente necessárias para o MSAL
const validateEnv = () => {
	// Se MSAL está desabilitado, não validar as variáveis
	if (env.NEXT_PUBLIC_DISABLE_MSAL) {
		console.log('MSAL desabilitado - modo de desenvolvimento sem autenticação');
		return;
	}

	if (
		!env.NEXT_PUBLIC_AZURE_CLIENT_ID ||
		!env.NEXT_PUBLIC_AZURE_TENANT_ID ||
		!env.NEXT_PUBLIC_APP_URL
	) {
		throw new Error(
			'Variáveis de ambiente necessárias para MSAL não estão configuradas corretamente.'
		);
	}
};

// Chamada da validação antes de configurar o MSAL
validateEnv();

const msalConfig: Configuration = {
	auth: {
		clientId: env.NEXT_PUBLIC_DISABLE_MSAL ? 'dev-mode' : (env.NEXT_PUBLIC_AZURE_CLIENT_ID ?? ''),
		authority: env.NEXT_PUBLIC_DISABLE_MSAL ? 'https://login.microsoftonline.com/dev' : `https://login.microsoftonline.com/${env.NEXT_PUBLIC_AZURE_TENANT_ID}`,
		redirectUri: env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000',
		knownAuthorities: [`login.microsoftonline.com`], // Adicionando domínio conhecido
		postLogoutRedirectUri: `${env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/logout`,
		navigateToLoginRequestUrl: false,
	},
	cache: {
		cacheLocation: 'sessionStorage',
		storeAuthStateInCookie: false,
	},
	system: {
		loggerOptions: {
			loggerCallback: (
				level: LogLevel,
				message: string,
				containsPii: boolean,
			): void => {
				if (containsPii) {
					return;
				}
				switch (level) {
					case LogLevel.Error:
						console.error(message);
						return;
					case LogLevel.Info:
						console.info(message);
						return;
					case LogLevel.Verbose:
						console.debug(message);
						return;
					case LogLevel.Warning:
						console.warn(message);
				}
			},
			piiLoggingEnabled: false,
		},
		windowHashTimeout: 60000, // Timeout para hash na janela
		iframeHashTimeout: 6000, // Timeout para hash no iframe
		loadFrameTimeout: 0, // Timeout para carregamento de frame
	},
};

export const msalInstance = new PublicClientApplication(msalConfig);

// Variável para garantir que a inicialização ocorra apenas uma vez
let isInitialized = false;

// Exportamos uma função para controlar a inicialização
export const initializeMsal = async () => {
	// Se MSAL está desabilitado, retornar imediatamente
	if (env.NEXT_PUBLIC_DISABLE_MSAL) {
		console.log('MSAL desabilitado - pulando inicialização');
		return;
	}

	try {
		if (!isInitialized) {
			await msalInstance.initialize();
			isInitialized = true;
		}
		
		// Verify accounts after initialization
		const accounts = msalInstance.getAllAccounts();
		
	} catch (error) {
		console.error('MSAL Config - Error during initialization:', error);
		throw error;
	}
};

// Monitoramento de eventos do MSAL
msalInstance.addEventCallback((event) => {
	if (event.eventType === EventType.LOGIN_SUCCESS) {
		// Login successful
	} else if (event.eventType === EventType.LOGIN_FAILURE) {
		console.error('Falha no login:', event.error);
	} else if (event.eventType === EventType.INITIALIZE_START) {
		// Initialization started
	} else if (event.eventType === EventType.INITIALIZE_END) {
		// Initialization completed
	} else if (event.eventType === EventType.ACQUIRE_TOKEN_START) {
		// Token acquisition started
	} else if (event.eventType === EventType.ACQUIRE_TOKEN_SUCCESS) {
		// Token acquisition successful
	} else if (event.eventType === EventType.ACQUIRE_TOKEN_FAILURE) {
		console.error('MSAL acquire token failed:', event.error);
	}
});
