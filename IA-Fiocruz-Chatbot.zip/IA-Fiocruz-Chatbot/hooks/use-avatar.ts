import { useEffect, useMemo, useState, useRef } from 'react'
import { getCookie, setCookie } from 'codekit'
import { msalInstance } from '@/app/config/msalConfig'

// Simplified azure-focused avatar hook
// Retrieves profile image from localStorage (set in layout) and derives name + initials.
export function useAvatar() {
  const [profileImage, setProfileImage] = useState<string | null>(null)
  const fetchingRef = useRef(false)
  const username = getCookie('azure-account-username') || ''
  function deriveNameFromEmail(email: string): string {
    if (!email) return 'User'
    const local = email.split('@')[0]
    // Split on common separators and capitalize
    const parts = local.split(/[._-]+/).filter(Boolean)
    if (!parts.length) return local
    return parts
      .map(p => p.length ? p[0].toUpperCase() + p.slice(1).toLowerCase() : p)
      .join(' ')
  }

  const [displayName, setDisplayName] = useState<string>(() => {
    if (typeof window === 'undefined') return 'User'
    const stored = sessionStorage.getItem('azure-account-name')
    if (stored && stored.trim().length) return stored
    if (username) return deriveNameFromEmail(username)
    return 'User'
  })

  useEffect(() => {
    try {
      const stored = localStorage.getItem('azure-account-profile-image')
      if (stored) setProfileImage(stored)
    } catch {/* ignore */}

    const handler = () => {
      try {
        const updated = localStorage.getItem('azure-account-profile-image')
        if (updated) setProfileImage(updated)
      } catch {/* ignore */}
    }
    window.addEventListener('azure-profile-image-updated', handler)
    return () => window.removeEventListener('azure-profile-image-updated', handler)
  }, [])

  // If no image yet and cookie not marked fetched, attempt direct fetch via Graph (best effort)
  useEffect(() => {
    const alreadyFetched = getCookie('azure-profile-image-fetched')
    if (profileImage || alreadyFetched || fetchingRef.current) return

    const fetchImage = async () => {
      try {
        fetchingRef.current = true
        const accounts = msalInstance.getAllAccounts()
        if (!accounts.length) return
        const account = accounts[0]
        const resp = await msalInstance.acquireTokenSilent({
          account,
          scopes: ['User.Read']
        })
        const token = resp.accessToken
        const r = await fetch('https://graph.microsoft.com/v1.0/me/photo/$value', {
          headers: { Authorization: `Bearer ${token}` }
        })
        if (r.ok) {
          const blob = await r.blob()
            const reader = new FileReader()
            reader.onloadend = () => {
              if (reader.result) {
                localStorage.setItem('azure-account-profile-image', reader.result as string)
                try {
                  // Set cookie to mark that profile image was fetched
                  setCookie('azure-profile-image-fetched', 'true', {
                    path: '/',
                    sameSite: 'None',
                    secure: true,
                  })
                } catch {/* ignore */}
                setProfileImage(reader.result as string)
                try { window.dispatchEvent(new Event('azure-profile-image-updated')) } catch {/* ignore */}
              }
            }
            reader.readAsDataURL(blob)
        }
      } catch {/* ignore */} finally {
        fetchingRef.current = false
      }
    }
    fetchImage()
  }, [profileImage])

  // Try to enrich display name from MSAL if sessionStorage didn't have it
  useEffect(() => {
    if (displayName !== 'User') return
    try {
      const accounts = msalInstance.getAllAccounts()
      if (accounts.length) {
        const acc: any = accounts[0]
        const claims: any = acc.idTokenClaims || {}
        const possible = acc.name || claims.name || [claims.given_name, claims.family_name].filter(Boolean).join(' ').trim()
          || claims.preferred_username || acc.username
        if (possible && typeof possible === 'string') {
          const clean = possible.trim()
          if (clean.length) {
            setDisplayName(clean)
            try { sessionStorage.setItem('azure-account-name', clean) } catch {/* ignore */}
            return
          }
        }
        // fallback: format from email
        if (acc.username && acc.username.includes('@')) {
          const derived = deriveNameFromEmail(acc.username)
          setDisplayName(derived)
          try { sessionStorage.setItem('azure-account-name', derived) } catch {/* ignore */}
        }
      } else if (username) {
        const derived = deriveNameFromEmail(username)
        setDisplayName(derived)
      }
    } catch {/* ignore */}
  }, [displayName, username])

  const nameParts = useMemo(() => {
    const clean = displayName.trim()
    const parts = clean.split(/\s+/).filter(Boolean)
    return parts
  }, [displayName])

  const firstName = useMemo(() => nameParts[0] || 'User', [nameParts])

  const shortName = useMemo(() => {
    if (!nameParts.length) return 'User'
    if (nameParts.length === 1) return nameParts[0]
    const last = nameParts[nameParts.length - 1]
    return `${nameParts[0]} ${last}`
  }, [nameParts])

  const initials = useMemo(() => {
    if (nameParts.length === 0) return 'US'
    if (nameParts.length === 1) return nameParts[0].slice(0,2).toUpperCase()
    return (nameParts[0][0] + nameParts[nameParts.length-1][0]).toUpperCase()
  }, [nameParts])

  // React to name updates via events (set in layout)
  useEffect(() => {
    const handler = () => {
      try {
        const stored = sessionStorage.getItem('azure-account-name')
        if (stored && stored.trim().length) setDisplayName(stored)
      } catch {/* ignore */}
    }
    window.addEventListener('azure-account-name-updated', handler)
    return () => window.removeEventListener('azure-account-name-updated', handler)
  }, [])

  return {
    profileImage,
    initials,
    fullName: displayName,
    firstName,
    shortName,
    username,
  }
}
