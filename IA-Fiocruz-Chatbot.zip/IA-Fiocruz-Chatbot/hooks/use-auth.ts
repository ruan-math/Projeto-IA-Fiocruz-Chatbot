import { useState, useEffect } from 'react';
import { msalInstance, initializeMsal } from '@/app/config/msalConfig';

export function useAuth() {
  const [userId, setUserId] = useState<string | null>(null);
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [userName, setUserName] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const getCurrentUser = async () => {
      try {
        // Wait for MSAL to be ready (using centralized initialization)
        await initializeMsal();
        
        // Handle any pending redirect
        const response = await msalInstance.handleRedirectPromise();
        if (response) {
          // Login successful, account should be available
        }
        
        const accounts = msalInstance.getAllAccounts();
        
        
        if (accounts.length > 0) {
          const account = accounts[0];
          
          // Try multiple ID sources in order of preference
          const extractedUserId = account.localAccountId || 
                                 account.username || 
                                 account.homeAccountId || 
                                 account.name || 
                                 account.idTokenClaims?.oid ||
                                 account.idTokenClaims?.sub;
          // Extract email and display name where possible
          const extractedEmail = account?.username ||
                                 account?.idTokenClaims?.preferred_username ||
                                 account?.idTokenClaims?.email ||
                                 (account?.idTokenClaims?.emails?.[0] ?? null);
          const extractedName = account?.name ||
                                account?.idTokenClaims?.name ||
                                null;
          
          if (extractedUserId) {
            setUserId(extractedUserId);
          } else {
            setUserId('anonymous');
          }

          setUserEmail((extractedEmail as string) ?? null);
          setUserName(extractedName ?? null);
        } else {
          setUserId('anonymous');
          setUserEmail(null);
          setUserName(null);
        }
      } catch (error) {
        console.error('useAuth - Error getting current user:', error);
        setUserId('anonymous');
        setUserEmail(null);
        setUserName(null);
      } finally {
        setIsLoading(false);
      }
    };

    getCurrentUser();
  }, []);

  
  return { userId, userEmail, userName, isLoading };
}
