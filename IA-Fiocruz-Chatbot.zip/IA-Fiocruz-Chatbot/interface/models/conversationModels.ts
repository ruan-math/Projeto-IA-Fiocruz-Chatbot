// interface/models/conversationModel.ts

import { BaseModel } from './baseModel';

export interface ChatModel {
  id: string; // UUID
  title?: string;
  userId?: string;
  createdAt: string; // ISO date
  updatedAt: string; // ISO date
}

export class Chat implements BaseModel, ChatModel {
  id: string = '';
  title?: string;
  userId?: string;
  createdAt: string = '';
  updatedAt: string = '';
}

// Keep Conversation for backward compatibility, but it should only contain chat metadata
export interface ConversationModel {
  id: string; // UUID
  title?: string;
  userId?: string;
  createdAt: string; // ISO date
  updatedAt: string; // ISO date
}

export class Conversation implements BaseModel, ConversationModel {
  id: string = '';
  title?: string;
  userId?: string;
  createdAt: string = '';
  updatedAt: string = '';
}
