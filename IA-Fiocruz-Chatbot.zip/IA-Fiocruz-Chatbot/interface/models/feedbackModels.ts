// interface/models/feedbackModels.ts

import { t } from '@/i18n';
import { BaseModel } from './baseModel';

export type NegativeFeedbackReason =
  | 'missing_citation'
  | 'wrong_citation'
  | 'out_of_scope'
  | 'inaccurate_or_irrelevant'
  | 'other_unhelpful';

export type HarmfulContentReason =
  | 'hate_speech'
  | 'violent'
  | 'sexual'
  | 'manipulative'
  | 'other_harmful';

export interface FeedbackModel {
  id: string;
  type: 'like' | 'dislike';
  negativeFeedbackReasons?: Partial<Record<NegativeFeedbackReason, boolean>>;
  harmfulContentReasons?: Partial<Record<HarmfulContentReason, boolean>>;
  description?: string;
  chatId: string;
  messageId: string;
  userId: string;
  createdAt: string;
  updatedAt: string;
}

export class Feedback implements BaseModel, FeedbackModel {
  id: string = '';
  type: 'like' | 'dislike' = 'dislike';
  negativeFeedbackReasons?: Partial<Record<NegativeFeedbackReason, boolean>>;
  harmfulContentReasons?: Partial<Record<HarmfulContentReason, boolean>>;
  description?: string;
  chatId: string = '';
  messageId: string = '';
  userId: string = '';
  createdAt: string = '';
  updatedAt: string = '';
}

export type FeedbackMutation = Omit<FeedbackModel, 'id' | 'createdAt' | 'updatedAt'> & {
  id?: string;
};

// Mapeamento de razões para textos em português
export const negativeFeedbackReasonMap: Record<NegativeFeedbackReason, string> = {
  missing_citation: t('answer_feedback_1'),
  wrong_citation: t('answer_feedback_2'),
  out_of_scope: t('answer_feedback_3'),
  inaccurate_or_irrelevant: t('answer_feedback_4'),
  other_unhelpful: t('answer_feedback_5'),
};

export const harmfulContentReasonMap: Record<HarmfulContentReason, string> = {
  hate_speech: t('answer_feedback_report_1'),
  violent: t('answer_feedback_report_2'),
  sexual: t('answer_feedback_report_3'),
  manipulative: t('answer_feedback_report_4'),
  other_harmful: t('answer_feedback_report_5'),
};
