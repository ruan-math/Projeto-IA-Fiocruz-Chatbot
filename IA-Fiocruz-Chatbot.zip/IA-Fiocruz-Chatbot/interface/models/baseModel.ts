// interface/models/baseModel.ts
export interface BaseModel {
  id: string
  createdAt?: string
  updatedAt?: string
  [key: string]: any
}
