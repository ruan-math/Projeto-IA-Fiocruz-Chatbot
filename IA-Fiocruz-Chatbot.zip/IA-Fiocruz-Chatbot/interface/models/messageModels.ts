// interface/models/messageModels.ts

import { BaseModel } from './baseModel';

export interface ModelUsage {
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
}

export interface ModelInfo {
  id: string;
  responseId?: string;
  usage?: ModelUsage;
  finishReason?: string;
}

export interface MessageModel {
  id: string; // UUID
  role: 'user' | 'assistant';
  content: string;
  chatId: string; // Reference to chat
  userId: string;
  startTime: string; // ISO date
  endTime: string; // ISO date
  userEmail?: string;
  model?: ModelInfo; // Only for assistant messages
  createdAt: string; // ISO date
  updatedAt: string; // ISO date
}

export class Message implements BaseModel, MessageModel {
  id: string = '';
  role: 'user' | 'assistant' = 'user';
  content: string = '';
  chatId: string = '';
  userId: string = '';
  startTime: string = '';
  endTime: string = '';
  userEmail?: string;
  model?: ModelInfo;
  createdAt: string = '';
  updatedAt: string = '';
}
