import { BaseModel } from './baseModel';

export interface CitationModel {
  id: string; // UUID
  messageId: string; // ID da mensagem que gerou a citação
  chatId: string; // ID do chat
  userId: string; // ID do usuário
  citationIndex: number; // Índice da citação na mensagem (1, 2, 3, etc.)
  filepath?: string; // Caminho do arquivo
  chunk_id: string; // ID do chunk
  content: string; // Conteúdo da citação
  title: string; // Título do documento
  url?: string; // URL do documento
  reference: string; // Referência formatada (ex: "[1]", "[2]")
  createdAt: string; // ISO date
  updatedAt: string; // ISO date
}

export class Citation implements BaseModel, CitationModel {
  id: string = '';
  messageId: string = '';
  chatId: string = '';
  userId: string = '';
  citationIndex: number = 0;
  filepath?: string;
  chunk_id: string = '';
  content: string = '';
  title: string = '';
  url?: string;
  reference: string = '';
  createdAt: string = '';
  updatedAt: string = '';
}
