// interface/controller.ts
export type QueryParameter = {
  name: string
  value: string
}

export type QueryExpression = {
  query: string
  parameters: QueryParameter[]
}

export interface GenericController<T> {
  get(id: string): Promise<T | null>
  list(query?: QueryExpression): Promise<T[]>
  create(data: T): Promise<T>
  update(id: string, data: Partial<T>): Promise<T>
  delete(id: string): Promise<void>
}
