import { RAGService } from './services/ragService';
import { config } from './config';



export class AgentChatbot {
  private ragService: RAGService;
  private isInitialized = false;

  constructor() {
    this.ragService = new RAGService();
  }

  /**
   * Initialize the chatbot system
   */
  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    console.log(`Initializing Agent Assistant ...`);
    console.log(`Environment: ${config.nodeEnv}`);
    
    try {
      await this.ragService.initialize();
      this.isInitialized = true;
      console.log('Chatbot initialized successfully! ✅');
    } catch (error) {
      console.error('Failed to initialize chatbot:', error);
      throw error;
    }
  }

  /**
   * Process a user query and return a comprehensive response
   */
  async ask(
    question: string,
    conversationId?: string,
    options?: {
      topK?: number;
      rerankTopK?: number;
      includeReferences?: boolean;
      useReranking?: boolean;
    }
  ) {
    await this.ensureInitialized();

    if (!question || question.trim().length === 0) {
      throw new Error('Question cannot be empty');
    }

    console.log(`Processing question: "${question.substring(0, 100)}..."`);
    
    try {
  // Pass default userId 'anonymous' (adapt if auth integrated) then options
  const result = await this.ragService.query(question, conversationId, 'anonymous', undefined, options);
      
      return {
        answer: result.response.answer,
        conversationId: result.conversationId,
        references: result.formattedReferences,
        metadata: {
          model: result.response.model,
          confidence: result.response.confidence,
          processingTime: result.response.processingTime,
          referenceCount: result.response.references.length,
        },
        // For UI integration
        referencesHTML: this.ragService.generateReferencesHTML(result.formattedReferences),
      };
    } catch (error) {
      console.error('Error processing question:', error);
      throw new Error(`Failed to process question: ${error}`);
    }
  }


  /**
   * List all conversations
   */
  listConversations(userId: string = 'anonymous') {
    return this.ragService.listConversations(userId);
  }

  /**
   * Delete a conversation
   */
  deleteConversation(conversationId: string) {
    return this.ragService.deleteConversation(conversationId);
  }

  /**
   * Get system statistics
   */
  async getStats() {
    await this.ensureInitialized();
    return await this.ragService.getStats();
  }

  /**
   * Health check
   */
  async healthCheck() {
    return await this.ragService.healthCheck();
  }

  /**
   * Get assets for UI integration (CSS and JS for collapsible references)
   */
  getUIAssets() {
    return this.ragService.getReferencesAssets();
  }


  /**
   * Ensure the chatbot is initialized
   */
  private async ensureInitialized(): Promise<void> {
    if (!this.isInitialized) {
      await this.initialize();
    }
  }
}

// Export main class and types for external use
export * from './types';
export * from './config';

// Default export for convenience
export default AgentChatbot;

// Example usage for testing
async function example() {
  if (require.main === module) {

    try {
      const chatbot = new AgentChatbot();
      await chatbot.initialize();

      // Health check
      const health = await chatbot.healthCheck();
      console.log('Health Status:', health.status);
      console.log('Services:', health.services);

      // Get system stats
      const stats = await chatbot.getStats();
      console.log('\\nSystem Statistics:');
      console.log(`- Documents (Azure Search): N/A (count disabled)`);
      console.log(`- Conversations: ${stats.conversations.totalConversations}`);
      console.log(`- Available Models: ${stats.models.filter(m => m.isAvailable).length}`);

      // Example query
      console.log('\\n--- Example Query ---');
      const result = await chatbot.ask(
        'What are the main requirements for revenue recognition according to IMAM-0001?'
      );

      result.references.forEach((ref, index) => {
        if (ref.rerankScore) {
          console.log(`Rerank Score: ${ref.rerankScore.toFixed(3)}`);
        }
      });

    } catch (error) {
      console.error('Example failed:', error);
    }
  }
}

// Run example if this file is executed directly
example();