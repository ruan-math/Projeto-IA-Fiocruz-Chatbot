import dotenv from 'dotenv';
import { RAGConfig } from '../types';

export const config = {
  // API Keys
  openaiApiKey: process.env.OPENAI_API_KEY || '',
  cohereApiKey: process.env.COHERE_API_KEY || '',
  
  // Azure OpenAI (chat/completions)
  azureOpenAIApiKey: process.env.AZURE_OPENAI_API_KEY || '',
  azureOpenAIApiInstanceName: process.env.AZURE_OPENAI_API_INSTANCE_NAME || '',
  azureOpenAIApiBaseEndpoint: process.env.AZURE_OPENAI_BASE_ENDPOINT || '',
  azureOpenAIApiVersion: process.env.AZURE_OPENAI_API_VERSION || '',
  
  // Azure OpenAI (embeddings)
  azureOpenAIEmbeddingEndpoint: process.env.AZURE_OPENAI_EMBEDDING_ENDPOINT || '',
  azureOpenAIEmbeddingsDeployment: process.env.AZURE_OPENAI_EMBEDDINGS_DEPLOYMENT || '',

  //  Azure Cohere Rerank
  azureRerankKey: process.env.AZURE_RERANK_API_KEY || '',
  azureRerankUrl: process.env.AZURE_RERANK_URL || '',
  azureRerankModel: process.env.AZURE_RERANK_MODEL || '',

  // Azure AI Search
  azureSearchEndpoint: process.env.AZURE_SEARCH_ENDPOINT || '',
  azureSearchIndex: process.env.AZURE_SEARCH_INDEX || '',
  azureSearchApiKey: process.env.AZURE_SEARCH_API_KEY || '',
  
  // (Legacy Chroma vector store removed)
  
  // App Config
  nodeEnv: process.env.NODE_ENV || 'development',
  logLevel: process.env.LOG_LEVEL || 'info',
  // Feature flags (public)
  appUseAiSearchFilter: (process.env.NEXT_PUBLIC_APP_USE_AI_SEARCH_FILTER || 'false') === 'true',
};

export const ragConfig: RAGConfig = {
  chunkSize: 1000,
  chunkOverlap: 200,
  topK: 40,                    // Aumentado para capturar mais documentos relevantes
  rerankTopK: 10,              // Aumentado para melhor cobertura de respostas
  similarityThreshold: 0.5,     // Reduzido para incluir mais documentos técnicos
  models: [
    {
      name: 'gpt-4o',
      provider: 'azure',
      priority: 1,
      maxTokens: 4000,
      temperature: 0.0,
      isAvailable: true
    },
    {
      name: 'gpt-4o-mini',
      provider: 'openai',
      priority: 2,
      maxTokens: 4000,
      temperature: 0.0,
      isAvailable: !!config.openaiApiKey,
    },
    {
      name: 'gpt-3.5-turbo',
      provider: 'openai',
      priority: 3,
      maxTokens: 4000,
      temperature: 0.0,
      isAvailable: !!config.openaiApiKey,
    },
    {
      name: 'gpt-4o-mini',
      provider: 'openai',
      priority: 1,
      maxTokens: 4000,
      temperature: 0.0,
      isAvailable: !!config.openaiApiKey,
    },
    {
      name: 'gpt-4o-mini',
      provider: 'openai',
      priority: 2,
      maxTokens: 4000,
      temperature: 0.0,
      isAvailable: !!config.openaiApiKey,
    },
    {
      name: 'gpt-3.5-turbo',
      provider: 'openai',
      priority: 3,
      maxTokens: 4000,
      temperature: 0.0,
      isAvailable: !!config.openaiApiKey,
    },
  ],
  retryConfig: {
    maxRetries: 3,
    initialDelay: 1000,
    backoffMultiplier: 2,
    maxDelay: 10000,
  },
};
