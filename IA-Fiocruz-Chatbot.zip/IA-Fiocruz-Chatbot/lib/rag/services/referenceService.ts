import { DocumentReference } from '../types';

export interface FormattedReference {
  id: string;
  title: string;
  summary: string;
  fullContent: string;
  source: string;
  documentType: string;
  category: string;
  language?: string;
  version?: string;
  pageNumber?: number;
  score: number;
  rerankScore?: number;
  isCollapsed: boolean;
}

export class ReferenceService {
  /**
   * Format references for display with collapsible content
   */
  formatReferences(references: DocumentReference[]): FormattedReference[] {
    return references.map((ref, index) => ({
      id: this.generateReferenceId(ref, index),
      title: this.generateTitle(ref),
      summary: this.generateSummary(ref.content),
      fullContent: ref.content,
      source: this.formatSource(ref.metadata.source || ref.metadata.filepath || ref.metadata.title || 'unknown'),
      documentType: ref.metadata.documentType || ref.metadata.code || 'UNKNOWN',
      category: ref.metadata.category || 'N/A',
      language: undefined,
      version: ref.metadata.version,
      pageNumber: ref.metadata.pageNumber,
      score: ref.score,
      rerankScore: ref.rerankScore,
      isCollapsed: true,
    }));
  }

  /**
   * Generate a unique ID for each reference
   */
  private generateReferenceId(ref: DocumentReference, index: number): string {
    const sourceBase = ref.metadata.source || ref.metadata.filepath || ref.metadata.title || 'src';
    const sourceHash = this.hashString(sourceBase);
    const docType = ref.metadata.documentType || ref.metadata.code || 'DOC';
    const chunkIndex = ref.metadata.chunkIndex ?? 0;
    return `ref_${docType}_${sourceHash}_${chunkIndex}_${index}`;
  }

  /**
   * Generate a descriptive title for the reference
   */
  private generateTitle(ref: DocumentReference): string {
    const documentType = ref.metadata.documentType || ref.metadata.code || 'Documento';
    const category = ref.metadata.category || '';
    const version = ref.metadata.version;
    const language = undefined; // removed from metadata schema
    const pageNumber = ref.metadata.pageNumber;

    const titleParts: string[] = [];

    if (documentType) titleParts.push(`${documentType}`);
    
    // Add version if available
    if (version) {
      titleParts.push(`${version}`);
    }
    
  // Add category
  if (category) titleParts.push(`- ${this.truncateText(category, 50)}`);
    
    // Add language if specified
    if (language) {
      titleParts.push(`(${language})`);
    }
    
    // Add page number if available
    if (pageNumber) {
      titleParts.push(`[Page ${pageNumber}]`);
    }
    
    return titleParts.join(' ');
  }

  /**
   * Generate a summary of the content (first few sentences)
   */
  private generateSummary(content: string, maxLength: number = 200): string {
    const sentences = content.split(/[.!?]+/).filter(s => s.trim().length > 0);
    
    if (sentences.length === 0) {
      return this.truncateText(content, maxLength);
    }

    let summary = sentences[0].trim();
    
    // Add more sentences if they fit within the limit
    for (let i = 1; i < sentences.length && summary.length < maxLength - 100; i++) {
      const nextSentence = sentences[i].trim();
      if (summary.length + nextSentence.length + 2 <= maxLength) {
        summary += '. ' + nextSentence;
      } else {
        break;
      }
    }
    
    // Ensure it ends with proper punctuation
    if (!summary.match(/[.!?]$/)) {
      summary += '...';
    }
    
    return summary;
  }

  /**
   * Format source path for better readability - extract only filename
   */
  private formatSource(source: string): string {
    if (!source) return 'Unknown Document';
    
    // If it's already just a filename (no path separators), return as is
    if (!source.includes('/') && !source.includes('\\')) {
      return source;
    }
    
    // Handle Windows paths (C:\Users\...)
    if (source.includes(':\\')) {
      const fileName = source.split('\\').pop();
      return fileName || 'Unknown Document';
    }
    
    // Handle Unix paths and URLs
    const fileName = source.split('/').pop() || source.split('\\').pop() || source;
    
    // Remove any query parameters or fragments from URL-like strings
    const cleanFileName = fileName.split('?')[0].split('#')[0];
    
    // Decode URL encoding if present
    try {
      return decodeURIComponent(cleanFileName) || 'Unknown Document';
    } catch {
      return cleanFileName || 'Unknown Document';
    }
  }

  /**
   * Create HTML structure for collapsible references
   */
  generateCollapsibleHTML(formattedRefs: FormattedReference[]): string {
    if (formattedRefs.length === 0) {
      return '<div class="references-empty">No references available</div>';
    }

    const referencesHTML = formattedRefs.map(ref => {
      const scoreDisplay = ref.rerankScore !== undefined 
        ? `Rerank: ${ref.rerankScore.toFixed(3)} | Similarity: ${ref.score.toFixed(3)}`
        : `Similarity: ${ref.score.toFixed(3)}`;

      return `
        <div class="reference-item" data-ref-id="${ref.id}">
          <div class="reference-header" onclick="toggleReference('${ref.id}')">
            <div class="reference-title">
              <span class="reference-icon">📄</span>
              <span class="title-text">${this.escapeHtml(ref.title)}</span>
              <span class="reference-toggle ${ref.isCollapsed ? 'collapsed' : 'expanded'}">
                ${ref.isCollapsed ? '▶' : '▼'}
              </span>
            </div>
            <div class="reference-metadata">
              <span class="source">${this.escapeHtml(ref.source)}</span>
              <span class="score">${scoreDisplay}</span>
            </div>
          </div>
          
          <div class="reference-summary">
            ${this.escapeHtml(ref.summary)}
          </div>
          
          <div class="reference-content ${ref.isCollapsed ? 'collapsed' : 'expanded'}">
            <div class="content-header">
              <strong>Full Content:</strong>
            </div>
            <div class="content-text">
              ${this.formatContentForDisplay(ref.fullContent)}
            </div>
            <div class="content-footer">
              <div class="metadata-details">
                <span>Type: ${ref.documentType}</span>
                <span>Category: ${this.escapeHtml(ref.category)}</span>
                ${ref.language ? `<span>Language: ${ref.language}</span>` : ''}
                ${ref.version ? `<span>Version: ${ref.version}</span>` : ''}
                ${ref.pageNumber ? `<span>Page: ${ref.pageNumber}</span>` : ''}
              </div>
            </div>
          </div>
        </div>
      `;
    }).join('');

    return `
      <div class="references-container">
        <div class="references-header">
          <h3>References (${formattedRefs.length})</h3>
          <div class="references-controls">
            <button onclick="toggleAllReferences(true)">Expand All</button>
            <button onclick="toggleAllReferences(false)">Collapse All</button>
          </div>
        </div>
        <div class="references-list">
          ${referencesHTML}
        </div>
      </div>
    `;
  }

  /**
   * Generate CSS for collapsible references
   */
  generateReferenceCSS(): string {
    return `
      .references-container {
        margin-top: 20px;
        border: 1px solid #e0e0e0;
        border-radius: 8px;
        background: #fafafa;
      }

      .references-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 15px 20px;
        background: #f5f5f5;
        border-bottom: 1px solid #e0e0e0;
        border-radius: 8px 8px 0 0;
      }

      .references-header h3 {
        margin: 0;
        color: #333;
        font-size: 16px;
      }

      .references-controls button {
        margin-left: 10px;
        padding: 5px 12px;
        border: 1px solid #ccc;
        background: white;
        border-radius: 4px;
        cursor: pointer;
        font-size: 12px;
      }

      .references-controls button:hover {
        background: #f0f0f0;
      }

      .references-list {
        max-height: 400px;
        overflow-y: auto;
      }

      .reference-item {
        border-bottom: 1px solid #e0e0e0;
      }

      .reference-item:last-child {
        border-bottom: none;
      }

      .reference-header {
        padding: 12px 20px;
        cursor: pointer;
        transition: background-color 0.2s;
      }

      .reference-header:hover {
        background: #f0f0f0;
      }

      .reference-title {
        display: flex;
        align-items: center;
        font-weight: 500;
        color: #333;
        margin-bottom: 5px;
      }

      .reference-icon {
        margin-right: 8px;
        font-size: 14px;
      }

      .title-text {
        flex: 1;
        font-size: 14px;
      }

      .reference-toggle {
        margin-left: 10px;
        font-size: 12px;
        color: #666;
        transition: transform 0.2s;
      }

      .reference-toggle.expanded {
        transform: rotate(90deg);
      }

      .reference-metadata {
        display: flex;
        justify-content: space-between;
        font-size: 12px;
        color: #666;
      }

      .reference-summary {
        padding: 8px 20px 12px;
        font-size: 13px;
        color: #555;
        background: #f9f9f9;
        border-left: 3px solid #ddd;
        margin: 0 20px;
      }

      .reference-content {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.3s ease-out;
      }

      .reference-content.expanded {
        max-height: 500px;
        overflow-y: auto;
      }

      .content-header {
        padding: 15px 20px 10px;
        font-size: 13px;
        color: #333;
      }

      .content-text {
        padding: 0 20px;
        font-size: 13px;
        line-height: 1.5;
        color: #444;
        white-space: pre-wrap;
        max-height: 300px;
        overflow-y: auto;
        background: white;
        border: 1px solid #eee;
        border-radius: 4px;
        margin: 0 20px;
      }

      .content-footer {
        padding: 10px 20px 15px;
      }

      .metadata-details {
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
        font-size: 11px;
        color: #666;
      }

      .metadata-details span {
        background: #e9e9e9;
        padding: 2px 6px;
        border-radius: 3px;
      }

      .references-empty {
        padding: 20px;
        text-align: center;
        color: #666;
        font-style: italic;
      }
    `;
  }

  /**
   * Generate JavaScript for collapsible functionality
   */
  generateReferenceJS(): string {
    return `
      function toggleReference(refId) {
        const item = document.querySelector('[data-ref-id="' + refId + '"]');
        if (!item) return;
        
        const content = item.querySelector('.reference-content');
        const toggle = item.querySelector('.reference-toggle');
        
        if (content.classList.contains('expanded')) {
          content.classList.remove('expanded');
          toggle.classList.add('collapsed');
          toggle.classList.remove('expanded');
          toggle.textContent = '▶';
        } else {
          content.classList.add('expanded');
          toggle.classList.remove('collapsed');
          toggle.classList.add('expanded');
          toggle.textContent = '▼';
        }
      }

      function toggleAllReferences(expand) {
        const items = document.querySelectorAll('.reference-item');
        items.forEach(item => {
          const content = item.querySelector('.reference-content');
          const toggle = item.querySelector('.reference-toggle');
          
          if (expand) {
            content.classList.add('expanded');
            toggle.classList.remove('collapsed');
            toggle.classList.add('expanded');
            toggle.textContent = '▼';
          } else {
            content.classList.remove('expanded');
            toggle.classList.add('collapsed');
            toggle.classList.remove('expanded');
            toggle.textContent = '▶';
          }
        });
      }
    `;
  }

  /**
   * Utility functions
   */
  private truncateText(text: string, maxLength: number): string {
    if (!text || typeof text !== 'string') return '';
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength - 3) + '...';
  }

  private escapeHtml(text: string): string {
    if (!text || typeof text !== 'string') return '';
    return text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  private formatContentForDisplay(content: string): string {
    return this.escapeHtml(content)
      .replace(/\\n/g, '<br>')
      .replace(/\\t/g, '&nbsp;&nbsp;&nbsp;&nbsp;');
  }

  private hashString(str: string): string {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return Math.abs(hash).toString(36);
  }
}