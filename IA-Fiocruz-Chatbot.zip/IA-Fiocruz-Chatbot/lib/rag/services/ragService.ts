
import { RerankService } from './rerankServiceV2';
import { LLMService } from './llmService';
import { ReferenceService, FormattedReference } from './referenceService';
import { DocumentReference, RAGResponse, ChatMessage, ConversationHistory } from '../types';
import { ragConfig } from '../config';
import AzureSearchService from './azureSearchService';
import { v4 as uuidv4 } from 'uuid';
import { CosmosConversationController } from '../cosmos/cosmosController';
import { createContainerIfNotExists, initializeAllContainers } from '../cosmos/initCosmos';
import { Conversation } from '@/interface/models/conversationModels';
import { ChatService } from './chatService';
import { getCookie } from 'codekit';

export class RAGService {
  private rerankService: RerankService;
  private llmService: LLMService;
  private chatService: ChatService;
  private referenceService: ReferenceService;
  private isInitialized = false;
  private azureSearchService: AzureSearchService; // Azure AI Search retriever

  constructor() {
    this.rerankService = new RerankService();
    this.llmService = new LLMService();
    this.chatService = new ChatService();
    this.referenceService = new ReferenceService();
    this.azureSearchService = new AzureSearchService();
  }

  /**
   * Initialize the RAG service
   */
  async initialize(): Promise<void> {
    if (this.isInitialized) return;

    console.log('Initializing RAG service...');

    try {
      // Ensure all Cosmos containers exist
      await initializeAllContainers();

      // Initialize vector store
      // await this.vectorStore.initialize();

      // Check if rerank service is available
      const rerankAvailable = await this.rerankService.isAvailable();
      console.log(`Cohere rerank service: ${rerankAvailable ? 'Available' : 'Not available'}`);

      // Test LLM models
      const modelStatus = await this.llmService.testModels();
      console.log('Model availability:', Object.fromEntries(modelStatus));

      this.isInitialized = true;
      console.log('RAG service initialized successfully');
    } catch (error) {
      console.error('Error initializing RAG service:', error);
      console.log(error);
      throw new Error('Failed to initialize RAG service');
    }
  }

  /**
   * Process a query and generate a response with references
   */
  async query(
    userQuery: string,
    conversationId?: string,
    userId: string = 'anonymous',
    userEmail?: string,
    options: {
      topK?: number;
      rerankTopK?: number;
      includeReferences?: boolean;
      useReranking?: boolean;
    } = {}
  ): Promise<{
    response: RAGResponse;
    conversationId: string;
    formattedReferences: FormattedReference[];
  }> {
    await this.ensureInitialized();

    const startTime = Date.now();
    const {
      topK = ragConfig.topK,
      rerankTopK = ragConfig.rerankTopK,
      includeReferences = true,
      useReranking = true,
    } = options;

    try {
      // Create or get chat
      const chatId = conversationId || await this.chatService.createChat(userId);

      // Add user message to chat
      await this.chatService.addMessage(chatId, userId, 'user', userQuery, userEmail);

      // Get conversation history for context
      const messages = await this.chatService.getMessagesByChatId(chatId);
      const conversationHistory = messages.map(msg => ({
        id: msg.id,
        role: msg.role,
        content: msg.content,
        timestamp: msg.createdAt,
        model: msg.model ? {
          id: msg.model.id,
          responseId: msg.model.responseId,
          usage: msg.model.usage,
          finishReason: msg.model.finishReason
        } : undefined,
        processingTime: msg.model?.usage?.totalTokens ? msg.model.usage.totalTokens / 1000 : undefined
      }));

      // Add context from recent conversation for better retrieval
      let searchQuery = userQuery;

      // Enhance query with semantic terms for better retrieval
      const enhancedQuery = this.enhanceQueryForVectorSearch(userQuery);
      if (enhancedQuery !== userQuery) {
        searchQuery = enhancedQuery;
      }

      // Check if this is a vague follow-up question that needs strong context
      const isVagueFollowUp = this.isVagueFollowUpQuestion(userQuery);

      // For vague follow-up questions, try to reuse documents from previous context
      if (isVagueFollowUp && conversationHistory.length > 1) {
        const previousDocuments = this.getPreviousContextDocuments(conversationHistory);

        if (previousDocuments.length > 0) {
          // Generate response using previous context documents
          const llmResponse = await this.llmService.generateResponse(
            userQuery,
            previousDocuments,
            conversationHistory.slice(0, -1) // Exclude current user message
          );

          const response: RAGResponse = {
            answer: llmResponse.content,
            references: previousDocuments,
            model: llmResponse.model,
            confidence: this.calculateConfidence(previousDocuments),
            processingTime: Date.now() - startTime,
          };

          // Add assistant message to chat (with metadata)
          console.log('RAG Service - Passing times to addMessage:', {
            startTime: llmResponse.startTime,
            endTime: llmResponse.endTime
          });
          
          await this.chatService.addMessage(
            chatId,
            userId,
            'assistant',
            response.answer,
            userEmail,
            response.model,
            llmResponse.startTime,
            llmResponse.endTime,
            previousDocuments
          );

          return {
            response,
            conversationId: chatId,
            formattedReferences: this.referenceService.formatReferences(previousDocuments),
          };
        }
      }

      if (conversationHistory.length > 1) {
        const recentContext = this.extractRecentContext(conversationHistory);
        if (recentContext) {
          if (isVagueFollowUp) {
            // For vague questions, heavily weight the context
            searchQuery = `${recentContext} ${recentContext} ${userQuery} ${recentContext}`;
          } else {
            searchQuery = `${userQuery} ${recentContext}`;
          }
        }
      }

      // Use Azure AI Search (temporary hardcoded creds) instead of local vector store
      const similarDocuments = await this.azureSearchService.searchSimilar(searchQuery, topK);

      if (similarDocuments.length === 0) {
      const response: RAGResponse = {
        answer: "Não encontrei informações relevantes nos documentos para responder à sua pergunta. Tente reformular com termos específicos (ex.: código, seção, assunto) ou consultar outro tema presente no acervo.",
          references: [],
          model: {
            id: 'No model used',
            responseId: crypto.randomUUID(),
            finishReason: 'no_model'
          },
          confidence: 0,
          processingTime: Date.now() - startTime,
        };

        // Add assistant message to chat (with metadata)
        // For this case, we don't have LLM response, so use current time
        const currentTime = new Date().toISOString();
        await this.chatService.addMessage(
          chatId,
          userId,
          'assistant',
          response.answer,
          userEmail,
          response.model,
          currentTime,
          currentTime,
          [] // No references for this case
        );

        return {
          response,
          conversationId: chatId,
          formattedReferences: [],
        };
      }

      // Step 2: Rerank documents for better relevance (if enabled)
      let rankedDocuments = similarDocuments;
      if (useReranking && similarDocuments.length > 1) {
        try {
          // Usa reranking contextual específico para Fiocruz
          rankedDocuments = await this.rerankService.rerankDocumentsWithContext(
            searchQuery,
            similarDocuments,
            rerankTopK
          );
        } catch (error) {
          console.warn('Contextual reranking failed, trying standard reranking:', error);
          try {
            // Fallback para reranking padrão
            rankedDocuments = await this.rerankService.rerankDocuments(
              searchQuery,
              similarDocuments,
              rerankTopK
            );
          } catch (fallbackError) {
            console.warn('Standard reranking also failed, using original similarity ranking:', fallbackError);
            rankedDocuments = similarDocuments.slice(0, rerankTopK);
          }
        }
      } else {
        rankedDocuments = similarDocuments.slice(0, rerankTopK);
      }

      // No relevance threshold - proceed with all retrieved documents for multilingual support
      // Step 3: Generate response using LLM with context
      const llmResponse = await this.llmService.generateResponse(
        userQuery,
        rankedDocuments,
        conversationHistory.slice(0, -1) // Exclude current user message (last message)
      );

      // Step 4: Build final response
      const response: RAGResponse = {
        answer: llmResponse.content,
        references: includeReferences ? rankedDocuments : [],
        model: llmResponse.model,
        confidence: this.calculateConfidence(rankedDocuments),
        processingTime: Date.now() - startTime,
      };

      // Step 5: Add assistant message to chat with references and metadata
      await this.chatService.addMessage(
        chatId,
        userId,
        'assistant',
        response.answer,
        userEmail,
        response.model,
        llmResponse.startTime,
        llmResponse.endTime,
        rankedDocuments
      );

      // Step 6: Format references for display
      const formattedReferences = includeReferences
        ? this.referenceService.formatReferences(rankedDocuments)
        : [];

      return {
        response: {
          ...response,
          startTime: llmResponse.startTime,
          endTime: llmResponse.endTime,
        },
        conversationId: chatId,
        formattedReferences,
      };

    } catch (error) {

      // Try to add error message to chat if we have a chat ID
      if (conversationId) {
        try {
          const errorStartTime = new Date().toISOString();
          const errorEndTime = new Date().toISOString();
          await this.chatService.addMessage(
            conversationId,
            userId,
            'assistant',
            'I apologize, but I encountered an error while processing your question. Please try again or rephrase your question.',
            userEmail,
            undefined, // model
            errorStartTime,
            errorEndTime,
            [] // No references for error messages
          );
        } catch (convError) {
          console.error('Error adding error message to conversation:', convError);
        }
      }

      throw new Error(`Failed to process query: ${error}`);
    }
  }


  /**
   * List all chats
   */
  async listConversations(userId: string): Promise<Array<{
    id: string;
    messageCount: number;
    lastMessage?: string;
    createdAt: string;
    updatedAt: string;
  }>> {
    const chats = await this.chatService.listChats(userId);

    return Promise.all(chats.map(async (chat) => {
      const messages = await this.chatService.getMessagesByChatId(chat.id);
      const lastMessage = messages.length > 0
        ? messages[messages.length - 1].content?.substring(0, 100)
        : undefined;

      return {
        id: chat.id,
        messageCount: messages.length,
        lastMessage,
        createdAt: chat.createdAt,
        updatedAt: chat.updatedAt,
      };
    }));
  }

  /**
   * Delete a chat
   */
  async deleteConversation(conversationId: string): Promise<boolean> {
    try {
      await this.chatService.deleteChat(conversationId);
      return true;
    } catch (error) {
      console.error(`Error deleting chat ${conversationId}:`, error);
      return false;
    }
  }

  /**
   * Get system statistics
   */
  async getStats(): Promise<{
    vectorStore: { count: number; collections: string[] };
    conversations: {
      totalConversations: number;
      totalMessages: number;
      averageMessagesPerConversation: number;
    };
    models: Array<{
      name: string;
      priority: number;
      isAvailable: boolean;
      maxTokens: number;
    }>;
    reranking: {
      maxDocuments: number;
      defaultTopK: number;
      model: string;
    };
  }> {
    await this.ensureInitialized();

    const autenticatedUserId = getCookie('azure-account-id') || 'anonymous';

    const [conversationStats, modelStats] = await Promise.all([
      (async () => {
        const list = await this.listConversations(autenticatedUserId);
        const totalConversations = list.length;
        const totalMessages = 0;
        const averageMessagesPerConversation = totalConversations > 0 ? totalMessages / totalConversations : 0;
        return { totalConversations, totalMessages, averageMessagesPerConversation };
      })(),
      Promise.resolve(this.llmService.getModelStats()),
    ]);

    return {
  vectorStore: { count: -1, collections: [] }, // -1 indica não aplicável / não contado
      conversations: conversationStats,
      models: modelStats,
      reranking: {
        maxDocuments: ragConfig.rerankTopK,
        defaultTopK: ragConfig.rerankTopK,
        model: require('../config').config.azureRerankModel || 'unknown',
      },
    };
  }

  /**
   * Health check for all services
   */
  async healthCheck(): Promise<{
    status: 'healthy' | 'degraded' | 'unhealthy';
    services: {
      vectorStore: boolean;
      reranking: boolean;
      llm: boolean;
      conversations: boolean;
    };
    details: Record<string, any>;
  }> {
    const results = {
      vectorStore: false,
      reranking: false,
      llm: false,
      conversations: true, // Conversations are always available
    };

    const details: Record<string, any> = {};

    try {
  // Check retrieval (Azure Search) in place of legacy vector store
  // Não contamos mais documentos; apenas marcamos serviço de busca como disponível
  results.vectorStore = true;
  details.vectorStore = { documentCount: 'N/A' };
    } catch (error) {
      details.vectorStore = { error: error };
    }

    try {
      // Check reranking service
      results.reranking = await this.rerankService.isAvailable();
      details.reranking = { available: results.reranking };
    } catch (error) {
      details.reranking = { error: error };
    }

    try {
      // Check LLM models
      const modelStatus = await this.llmService.testModels();
      const availableModels = Array.from(modelStatus.values()).filter(Boolean).length;
      results.llm = availableModels > 0;
      details.llm = { availableModels, modelStatus: Object.fromEntries(modelStatus) };
    } catch (error) {
      details.llm = { error: error };
    }

    // Determine overall status
    const healthyServices = Object.values(results).filter(Boolean).length;
    const totalServices = Object.keys(results).length;

    let status: 'healthy' | 'degraded' | 'unhealthy';
    if (healthyServices === totalServices) {
      status = 'healthy';
    } else if (healthyServices >= totalServices / 2) {
      status = 'degraded';
    } else {
      status = 'unhealthy';
    }

    return { status, services: results, details };
  }


  /**
   * Get formatted references HTML and assets for UI integration
   */
  getReferencesAssets(): {
    css: string;
    js: string;
  } {
    return {
      css: this.referenceService.generateReferenceCSS(),
      js: this.referenceService.generateReferenceJS(),
    };
  }

  /**
   * Generate collapsible HTML for references
   */
  generateReferencesHTML(references: FormattedReference[]): string {
    return this.referenceService.generateCollapsibleHTML(references);
  }

  /**
   * Ensure the service is initialized
   */
  private async ensureInitialized(): Promise<void> {
    if (!this.isInitialized) {
      await this.initialize();
    }
  }

  /**
   * Calculate confidence score based on reference quality
   */
  private calculateConfidence(references: DocumentReference[]): number {
    if (references.length === 0) return 0;

    // Use rerank scores if available, otherwise similarity scores
    const scores = references.map(ref => ref.rerankScore || ref.score);
    const avgScore = scores.reduce((sum, score) => sum + score, 0) / scores.length;

    // Consider number of references and score distribution
    const numReferencesBonus = Math.min(references.length / ragConfig.rerankTopK, 1) * 0.1;
    const scoreVariance = this.calculateVariance(scores);
    const consistencyBonus = (1 - Math.min(scoreVariance, 1)) * 0.1;

    const confidence = Math.min(avgScore + numReferencesBonus + consistencyBonus, 1);
    return Math.round(confidence * 100) / 100; // Round to 2 decimal places
  }

  /**
   * Calculate variance of an array of numbers
   */
  private calculateVariance(numbers: number[]): number {
    if (numbers.length === 0) return 0;

    const mean = numbers.reduce((sum, num) => sum + num, 0) / numbers.length;
    const squaredDiffs = numbers.map(num => Math.pow(num - mean, 2));
    return squaredDiffs.reduce((sum, diff) => sum + diff, 0) / numbers.length;
  }





  /**
   * Extract relevant context from recent conversation for search enhancement
   */
  private extractRecentContext(conversationHistory: ChatMessage[]): string | null {
    // Look at the last few messages for key terms
    const recentMessages = conversationHistory.slice(-6);
    const contextTerms: string[] = [];

    // Look for document codes in assistant responses first (highest priority)
    for (const message of recentMessages) {
      if (message.role === 'assistant') {
        const content = message.content;

        // Extract document codes from citations in assistant responses
        const citationMatches = content.match(/(?:Fonte|Source):\s*[^ (]*\(?(IMSA-PL-\d{4}|IMAM-\d{4}|IMCP-\d{4}|IMSA-PR-\d{4})/gi);
        if (citationMatches) {
          const codes = citationMatches
            .map(match => {
              const codeMatch = match.match(/(IMSA-PL-\d{4}|IMAM-\d{4}|IMCP-\d{4}|IMSA-PR-\d{4})/gi);
              return codeMatch ? codeMatch[0] : null;
            })
            .filter((v): v is string => Boolean(v));
          contextTerms.push(...codes);
        }

        // Also extract from direct document code mentions
        const directCodes = content.match(/IMSA-PL-\d{4}|IMAM-\d{4}|IMCP-\d{4}|IMSA-PR-\d{4}/gi);
        if (directCodes) {
          contextTerms.push(...directCodes);
        }
      }
    }

    // If we found document codes, prioritize them heavily
    if (contextTerms.length > 0) {
      const uniqueCodes = [...new Set(contextTerms)];
      // Add the most recent document code multiple times to boost relevance
      const primaryCode = uniqueCodes[0];
      return `${primaryCode} ${primaryCode} ${uniqueCodes.join(' ')}`;
    }

    // Fallback: look for topic terms in all messages
    for (const message of recentMessages) {
      const content = message.content;
      const lowerContent = content.toLowerCase();

      // Extract specific business terms
      const topicTerms = [
        'presentes', 'gifts', 'brindesias', 'cortesias', 'entretenimento', 'entertainment',
        'receita', 'revenue', 'contabilidade', 'accounting', 'compliance', 'política'
      ];

      for (const term of topicTerms) {
        if (lowerContent.includes(term) && !contextTerms.includes(term)) {
          contextTerms.push(term);
        }
      }
    }

    if (contextTerms.length === 0) {
      return null;
    }

    // Return most relevant terms
    const uniqueTerms = [...new Set(contextTerms)];
    return uniqueTerms.slice(0, 3).join(' ');
  }

  /**
   * Check if this is a vague follow-up question that needs strong context reinforcement
   */
  private isVagueFollowUpQuestion(query: string): boolean {
    const normalizedQuery = query.toLowerCase().trim();

    // Patterns for very vague questions that rely heavily on context
    const vaguePatterns = [
      /^(qual|quais)\s+(valor|valores?|limite|limites?)\s*(máximo|mínimo)?s?\??$/,    // "qual valor máximo", "quais limites"
      /^(what|which)\s+(value|values?|limit|limits?)\s*(maximum|minimum)?s?\??$/,    // "what value maximum", "which limits"
      /^(e\s+)?(qual|quais)\s+(são\s+)?os?\s+(valores?|limites?|critérios?)\??$/,    // "e quais são os valores", "qual são os limites"
      /^(and\s+)?(what|which)\s+(are\s+)?the\s+(values?|limits?|criteria)\??$/,      // "and what are the values"
      /^(valor|value|limite|limit)\s*(máximo|mínimo|maximum|minimum)\??$/,           // "valor máximo", "limit maximum"
      /^(quanto|how\s+much)\s*(máximo|mínimo|maximum|minimum)?\??$/,                 // "quanto máximo"
      /^(limites?|limits?)\??$/,                                                     // just "limites"
      /^(valores?|values?)\??$/,                                                     // just "valores"
      /^(critérios?|criteria)\??$/,                                                  // just "critérios"
      /^(detalhes?|details?)\??$/,                                                   // just "detalhes"
      /^(mais\s+)?(informações?|information|detalhes?|details?)\??$/                 // "mais informações"
    ];

    return vaguePatterns.some(pattern => pattern.test(normalizedQuery));
  }

  /**
   * Get documents from previous assistant messages in the conversation
   */
  private getPreviousContextDocuments(conversationHistory: ChatMessage[]): DocumentReference[] {
    // Look for the most recent assistant message that has references
    const recentMessages = conversationHistory.slice(-6);

    for (let i = recentMessages.length - 1; i >= 0; i--) {
      const message = recentMessages[i];
      if (message.role === 'assistant' && message.references && message.references.length > 0) {
        return message.references;
      }
    }

    return [];
  }

  private enhanceQueryForVectorSearch(query: string): string {
    const queryLower = query.toLowerCase();
    const enhancements: string[] = [query]; // Start with original query

    // Saúde Pública e Vigilância
    if (queryLower.includes('saúde') || queryLower.includes('vigilância') || queryLower.includes('epidemiologia')) {
      enhancements.push('saúde pública', 'vigilância em saúde', 'epidemiologia', 'surveillance', 'public health');
    }

    // Pesquisa Científica e Laboratórios
    if (queryLower.includes('pesquisa') || queryLower.includes('laboratório') || queryLower.includes('científico')) {
      enhancements.push('pesquisa científica', 'laboratório', 'research', 'scientific research', 'laboratory');
    }

    // Biossegurança
    if (queryLower.includes('biossegurança') || queryLower.includes('biosegurança') || queryLower.includes('biosafety')) {
      enhancements.push('biossegurança', 'biosafety', 'biosecurity', 'laboratory safety');
    }

    // Políticas Institucionais
    if (queryLower.includes('política') || queryLower.includes('policy') || queryLower.includes('diretriz')) {
      enhancements.push('política institucional', 'policy', 'diretriz', 'institutional policy');
    }

    // Normas e Procedimentos
    if (queryLower.includes('norma') || queryLower.includes('procedimento') || queryLower.includes('manual')) {
      enhancements.push('norma', 'procedimento operacional', 'manual', 'SOP', 'standard operating procedure');
    }

    // Ética e Compliance
    if (queryLower.includes('ética') || queryLower.includes('compliance') || queryLower.includes('integridade')) {
      enhancements.push('ética', 'integridade', 'compliance', 'governança', 'ethics', 'integrity');
    }

    // Gestão de Pessoas (contexto institucional)
    if (queryLower.includes('recursos humanos') || queryLower.includes('funcionário') || queryLower.includes('colaborador')) {
      enhancements.push('gestão de pessoas', 'recursos humanos', 'human resources', 'pessoal', 'staff');
    }

    // Tecnologia da Informação
    if (queryLower.includes('tecnologia') || queryLower.includes('sistema') || queryLower.includes('informação')) {
      enhancements.push('tecnologia da informação', 'TI', 'sistemas', 'information technology', 'IT systems');
    }

    // Finanças Institucionais
    if (queryLower.includes('finanças') || queryLower.includes('financeiro') || queryLower.includes('orçamento')) {
      enhancements.push('finanças institucionais', 'orçamento', 'financial management', 'budget', 'institutional finance');
    }

    // Proteção de Dados e Privacidade
    if (queryLower.includes('proteção') || queryLower.includes('privacidade') || queryLower.includes('dados')) {
      enhancements.push('proteção de dados', 'privacidade', 'LGPD', 'data protection', 'privacy');
    }

    // Segurança da Informação
    if (queryLower.includes('segurança') || queryLower.includes('security') || queryLower.includes('informação')) {
      enhancements.push('segurança da informação', 'information security', 'cybersecurity', 'data security');
    }

    // Gestão de Projetos
    if (queryLower.includes('projeto') || queryLower.includes('gestão') || queryLower.includes('project')) {
      enhancements.push('gestão de projetos', 'project management', 'projetos institucionais', 'institutional projects');
    }

    // Join enhancements with original query for better semantic matching
    return enhancements.join(' ');
  }
}