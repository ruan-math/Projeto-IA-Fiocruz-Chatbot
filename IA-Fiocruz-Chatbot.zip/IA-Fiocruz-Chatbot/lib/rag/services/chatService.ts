import { CosmosClient } from '@azure/cosmos';
import { v4 as uuidv4 } from 'uuid';
import { env } from '@/app/config/env';
import { CosmosConversationController } from '../cosmos/cosmosController';
import { Chat } from '@/interface/models/conversationModels';
import { Message } from '@/interface/models/messageModels';
import { CitationService } from './citationService';
import { DocumentReference } from '../types';

const client = new CosmosClient({
  endpoint: env.NEXT_PUBLIC_COSMOSDB_ENDPOINT,
  key: env.NEXT_PUBLIC_COSMOSDB_PRIMARY_KEY,
});

if (!env.NEXT_PUBLIC_COSMOSDB_DATABASE) {
  throw new Error('CosmosDB database name is not defined in environment variables');
}

export class ChatService {
  private chatController = CosmosConversationController<Chat>('chats');
  private messageController = CosmosConversationController<Message>('messages');
  private citationService = new CitationService();

  async createChat(userId: string, title?: string): Promise<string> {
    const chatId = `chat_${uuidv4().replace(/-/g, '')}`;
    
    const chat: Chat = {
      id: chatId,
      title: title || 'Nova Conversa',
      userId: userId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await this.chatController.create(chat);
    return chatId;
  }

  async getChat(chatId: string): Promise<Chat | null> {
    return await this.chatController.get(chatId);
  }

  async updateChat(chatId: string, updates: Partial<Chat>): Promise<void> {
    updates.updatedAt = new Date().toISOString();
    await this.chatController.update(chatId, updates);
  }

  async deleteChat(chatId: string): Promise<void> {
    // First delete all citations in this chat
    await this.citationService.deleteCitationsByChatId(chatId);
    
    // Then delete all messages in this chat
    const messages = await this.getMessagesByChatId(chatId);
    for (const message of messages) {
      await this.messageController.delete(message.id);
    }
    
    // Finally delete the chat
    await this.chatController.delete(chatId);
  }

  async listChats(userId: string): Promise<Chat[]> {
    const query = {
      query: 'SELECT * FROM c WHERE c.userId = @userId ORDER BY c.updatedAt DESC',
      parameters: [{ name: '@userId', value: userId }]
    };
    
    return await this.chatController.list(query);
  }

  async addMessage(
    chatId: string,
    userId: string,
    role: 'user' | 'assistant',
    content: string,
    userEmail?: string,
    model?: any,
    startTime?: string,
    endTime?: string,
    references?: DocumentReference[]
  ): Promise<Message> {
    const messageId = `msg_${uuidv4().replace(/-/g, '')}`;
    const now = new Date().toISOString();
    
    // Ensure startTime and endTime are different for assistant messages
    const finalStartTime = startTime || now;
    const finalEndTime = endTime || (role === 'assistant' ? new Date(Date.now() + 1).toISOString() : now);
    
    const message: Message = {
      id: messageId,
      role,
      content,
      chatId,
      userId,
      startTime: finalStartTime,
      endTime: finalEndTime,
      userEmail,
      model,
      createdAt: now,
      updatedAt: now,
    };

    await this.messageController.create(message);
    
    // Save citations if provided (usually for assistant messages)
    if (references && references.length > 0) {
      console.log('Saving citations for message:', messageId, 'Count:', references.length);
      await this.citationService.saveCitations(messageId, chatId, userId, references);
    }
    
    // If this is the first user message, generate a title
    if (role === 'user') {
      const messages = await this.getMessagesByChatId(chatId);
      const userMessages = messages.filter(msg => msg.role === 'user');
      
      if (userMessages.length === 1) {
        // This is the first user message, generate title
        const title = this.generateTitleFromContent(content);
        await this.updateChat(chatId, { 
          title,
          updatedAt: now 
        });
      } else {
        // Just update timestamp
        await this.updateChat(chatId, { updatedAt: now });
      }
    } else {
      // Update chat's updatedAt timestamp
      await this.updateChat(chatId, { updatedAt: now });
    }
    
    return message;
  }

  private generateTitleFromContent(content: string): string {
    // Remove extra whitespace and limit to 50 characters
    const cleanContent = content.trim().replace(/\s+/g, ' ');
    
    if (cleanContent.length <= 50) {
      return cleanContent;
    }
    
    // Find the last complete word within 50 characters
    const truncated = cleanContent.substring(0, 50);
    const lastSpaceIndex = truncated.lastIndexOf(' ');
    
    if (lastSpaceIndex > 20) {
      return truncated.substring(0, lastSpaceIndex) + '...';
    }
    
    return truncated + '...';
  }

  async getMessagesByChatId(chatId: string): Promise<Message[]> {
    const query = {
      query: 'SELECT * FROM c WHERE c.chatId = @chatId ORDER BY c.createdAt ASC',
      parameters: [{ name: '@chatId', value: chatId }]
    };
    
    return await this.messageController.list(query);
  }

  // Optimized method to get only message count and last message
  async getChatSummary(chatId: string): Promise<{ messageCount: number; lastMessage: string }> {
    // Get message count
    const countQuery = {
      query: 'SELECT VALUE COUNT(1) FROM c WHERE c.chatId = @chatId',
      parameters: [{ name: '@chatId', value: chatId }]
    };
    
    // Get last message content
    const lastMessageQuery = {
      query: 'SELECT TOP 1 c.content FROM c WHERE c.chatId = @chatId ORDER BY c.createdAt DESC',
      parameters: [{ name: '@chatId', value: chatId }]
    };
    
    const [countResult, lastMessageResult] = await Promise.all([
      this.messageController.list(countQuery),
      this.messageController.list(lastMessageQuery)
    ]);
    
    const messageCount = countResult.length > 0 ? (countResult[0] as unknown as number) : 0;
    const lastMessage = lastMessageResult.length > 0 ? (lastMessageResult[0] as any).content : '';
    
    return { messageCount, lastMessage };
  }

  async getMessage(messageId: string): Promise<Message | null> {
    return await this.messageController.get(messageId);
  }

  async updateMessage(messageId: string, updates: Partial<Message>): Promise<void> {
    updates.updatedAt = new Date().toISOString();
    await this.messageController.update(messageId, updates);
  }

  async deleteMessage(messageId: string): Promise<void> {
    await this.messageController.delete(messageId);
  }
}
