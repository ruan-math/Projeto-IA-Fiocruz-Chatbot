// src/services/RerankService.ts
import { DocumentReference } from "../types";
import { config } from "../config";

/**
 * Espera em config:
 * - config.azureRerankUrl  -> ex: https://<name>.<region>.models.ai.azure.com/v1/rerank
 * - config.azureRerankKey  -> Key do endpoint (Models as a Service) OU Entra ID Bearer
 */
export class RerankService {
  private readonly MAX_DOCUMENTS = 100; // Azure/Cohere limit
  private readonly DEFAULT_TOP_K = 5;

  constructor(
    private readonly endpoint: string = config.azureRerankUrl,
    private readonly apiKey: string = config.azureRerankKey
  ) {
    if (!this.endpoint) throw new Error("Missing config.azureRerankUrl");
    if (!this.apiKey) throw new Error("Missing config.azureRerankKey");
  }

  /**
   * Rerank documents using Azure AI Foundry (Cohere Rerank v3.5)
   */
  async rerankDocuments(
    query: string,
    documents: DocumentReference[],
    topK: number = this.DEFAULT_TOP_K
  ): Promise<DocumentReference[]> {
    if (!documents?.length) return [];

    // 1) Limita a 100 docs (billing unit)
    const docsToRerank = documents.slice(0, this.MAX_DOCUMENTS);

    // 2) Monta lista de documentos no formato aceito pelo endpoint
    //    Você pode passar strings ou objetos; aqui montamos strings ricas.
    const payloadDocs = docsToRerank.map((doc) => this.buildRerankText(doc));

    // 3) Corpo da requisição (v1/rerank)
    const body = {
      model: config.azureRerankModel,
      query,
      documents: payloadDocs,     // array de strings
      top_n: Math.min(topK, docsToRerank.length),
      return_documents: false     // já temos os docs localmente
      // Se você enviar objetos em vez de strings, pode usar:
      // rank_fields: ["title", "text"]  // conforme a doc do Rerank
    };

    try {
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
        Accept: "application/json",
      };

      // Support both Azure AI Foundry (api-key) and Entra ID Bearer token
      if (this.apiKey.startsWith("Bearer ")) {
        headers.Authorization = this.apiKey;
      } else {
        headers["api-key"] = this.apiKey;
        // Also include Authorization as Bearer for broader compatibility (some gateways accept either)
        headers.Authorization = `Bearer ${this.apiKey}`;
      }

      const res = await fetch(this.endpoint, {
        method: "POST",
        headers,
        body: JSON.stringify(body),
      });

      if (!res.ok) {
        const text = await res.text();
        // Erro comum: 400 "'input' is a required property" -> faltam query/documents válidos
        // ou payload em formato diferente do esperado.
        throw new Error(`HTTP ${res.status}: ${text}`);
      }

      type RerankResult = {
        index: number;               // índice no array original que foi enviado
        relevance_score: number;     // 0..(+) – maior é melhor
      };

      const json: { results: RerankResult[] } = await res.json();

      // 4) Mapeia de volta para DocumentReference e ordena por relevance_score
      const reranked = json.results
        .map((r) => {
          const originalDoc = docsToRerank[r.index];
          if (!originalDoc) return null;
          return {
            ...originalDoc,
            rerankScore: r.relevance_score,
            // mantemos o score original de similaridade (se houver)
            score: originalDoc.score,
          } as DocumentReference;
        })
        .filter(Boolean) as DocumentReference[];

      reranked.sort(
        (a, b) => (b.rerankScore ?? 0) - (a.rerankScore ?? 0)
      );

      return reranked;
    } catch (err) {
      console.error("Rerank error:", err);
      // Fallback: retorna topK pelo score de similaridade original, se existir
      return documents
        .slice(0, topK)
        .sort((a, b) => (b.score ?? 0) - (a.score ?? 0));
    }
  }

  /**
   * String rica com metadados específicos para documentos da Fiocruz.
   * Otimizada para contexto institucional de saúde pública e pesquisa científica.
   */
  private buildRerankText(doc: DocumentReference): string {
    const parts: string[] = [];
    
    // Metadados institucionais específicos da Fiocruz
    if (doc.metadata?.documentType) {
      const docTypeWeight = this.getDocumentTypeWeight(doc.metadata.documentType);
      parts.push(`[${docTypeWeight}] Tipo: ${doc.metadata.documentType}`);
    }
    
    if (doc.metadata?.category) {
      parts.push(`Categoria: ${doc.metadata.category}`);
    }
    
    if (doc.metadata?.organization) {
      parts.push(`Organização: ${doc.metadata.organization}`);
    }
    
    if (doc.metadata?.section) {
      parts.push(`Seção: ${doc.metadata.section}`);
    }
    
    if (doc.metadata?.publishedAt) {
      parts.push(`Data: ${doc.metadata.publishedAt}`);
    }
    
    if (doc.metadata?.code) {
      parts.push(`Código: ${doc.metadata.code}`);
    }
    
    if (doc.metadata?.version) {
      parts.push(`Versão: ${doc.metadata.version}`);
    }
    
    // Contexto específico para saúde pública e pesquisa
    const contextualInfo = this.extractContextualInfo(doc.content);
    if (contextualInfo) {
      parts.push(`Contexto: ${contextualInfo}`);
    }
    
    parts.push("Conteúdo:");
    parts.push(this.truncate(doc.content, 1200)); // Aumentado para documentos técnicos
    
    return parts.join("\n");
  }

  /**
   * Define pesos específicos para tipos de documento da Fiocruz
   */
  private getDocumentTypeWeight(documentType: string): string {
    const weights: Record<string, string> = {
      'POLICY': '[PRIORIDADE ALTA]',      // Políticas institucionais
      'PROCEDURE': '[PRIORIDADE ALTA]',   // Procedimentos operacionais
      'MANUAL': '[PRIORIDADE MÉDIA]',     // Manuais técnicos
      'REPORT': '[PRIORIDADE MÉDIA]',     // Relatórios científicos
      'GUIDELINE': '[PRIORIDADE ALTA]',   // Diretrizes de biossegurança
      'REGULATION': '[PRIORIDADE ALTA]',  // Regulamentações
      'PROTOCOL': '[PRIORIDADE ALTA]',    // Protocolos de pesquisa
      'STANDARD': '[PRIORIDADE MÉDIA]',   // Padrões técnicos
    };
    
    return weights[documentType] || '[PRIORIDADE BAIXA]';
  }

  /**
   * Extrai informações contextuais relevantes para saúde pública
   */
  private extractContextualInfo(content: string): string | null {
    const contextualPatterns = [
      // Biossegurança
      { pattern: /biossegurança|biosegurança|biosafety/i, context: 'Biossegurança' },
      { pattern: /laboratório|laboratory|lab/i, context: 'Laboratório' },
      { pattern: /patógeno|pathogen|agente infeccioso/i, context: 'Agente Infeccioso' },
      
      // Saúde Pública
      { pattern: /vigilância|surveillance|monitoramento/i, context: 'Vigilância em Saúde' },
      { pattern: /epidemiologia|epidemiology|surto|outbreak/i, context: 'Epidemiologia' },
      { pattern: /vacina|vaccine|imunização|immunization/i, context: 'Imunização' },
      
      // Pesquisa Científica
      { pattern: /pesquisa|research|estudo|study/i, context: 'Pesquisa Científica' },
      { pattern: /ensaios clínicos|clinical trials|teste/i, context: 'Ensaios Clínicos' },
      { pattern: /ética|ethics|comitê de ética/i, context: 'Ética em Pesquisa' },
      
      // Gestão Institucional
      { pattern: /governança|governance|gestão|management/i, context: 'Gestão Institucional' },
      { pattern: /compliance|conformidade|auditoria/i, context: 'Compliance' },
      { pattern: /qualidade|quality|acreditação/i, context: 'Qualidade' },
      
      // Tecnologia da Informação
      { pattern: /dados pessoais|personal data|LGPD|privacy/i, context: 'Proteção de Dados' },
      { pattern: /segurança da informação|information security/i, context: 'Segurança da Informação' },
      { pattern: /sistema de informação|information system/i, context: 'Sistemas de Informação' },
    ];

    const foundContexts: string[] = [];
    
    for (const { pattern, context } of contextualPatterns) {
      if (pattern.test(content) && !foundContexts.includes(context)) {
        foundContexts.push(context);
      }
    }
    
    return foundContexts.length > 0 ? foundContexts.join(', ') : null;
  }

  private truncate(text: string, maxLen = 1000): string {
    if (!text || text.length <= maxLen) return text ?? "";
    const cut = text.slice(0, maxLen);
    const lastPunct = Math.max(cut.lastIndexOf("."), cut.lastIndexOf("!"), cut.lastIndexOf("?"));
    if (lastPunct > maxLen * 0.7) return cut.slice(0, lastPunct + 1);
    const lastSpace = cut.lastIndexOf(" ");
    if (lastSpace > maxLen * 0.8) return cut.slice(0, lastSpace) + "...";
    return cut + "...";
  }

  /**
   * Reranking contextual específico para consultas de saúde pública e pesquisa científica
   */
  async rerankDocumentsWithContext(
    query: string,
    documents: DocumentReference[],
    topK: number = this.DEFAULT_TOP_K,
    contextType?: 'biosafety' | 'research' | 'public_health' | 'compliance' | 'general'
  ): Promise<DocumentReference[]> {
    if (!documents?.length) return [];

    // Aplica reranking padrão primeiro
    const rerankedDocs = await this.rerankDocuments(query, documents, topK);
    
    // Se não especificado, detecta automaticamente o contexto
    const detectedContext = contextType || this.detectQueryContext(query);
    
    // Aplica ajustes contextuais específicos
    return this.applyContextualAdjustments(rerankedDocs, detectedContext, query);
  }

  /**
   * Detecta o contexto da consulta baseado em palavras-chave
   */
  private detectQueryContext(query: string): 'biosafety' | 'research' | 'public_health' | 'compliance' | 'general' {
    const lowerQuery = query.toLowerCase();
    
    // Biossegurança
    if (/biossegurança|biosegurança|biosafety|laboratório|patógeno|agente infeccioso|contenção/i.test(lowerQuery)) {
      return 'biosafety';
    }
    
    // Pesquisa Científica
    if (/pesquisa|research|estudo|study|ensaios clínicos|clinical trials|ética|ethics/i.test(lowerQuery)) {
      return 'research';
    }
    
    // Saúde Pública
    if (/vigilância|surveillance|epidemiologia|epidemiology|vacina|vaccine|imunização|surto|outbreak/i.test(lowerQuery)) {
      return 'public_health';
    }
    
    // Compliance e Governança
    if (/compliance|conformidade|auditoria|governança|governance|qualidade|quality|acreditação/i.test(lowerQuery)) {
      return 'compliance';
    }
    
    return 'general';
  }

  /**
   * Aplica ajustes contextuais específicos para diferentes tipos de consulta
   */
  private applyContextualAdjustments(
    documents: DocumentReference[],
    context: 'biosafety' | 'research' | 'public_health' | 'compliance' | 'general',
    query: string
  ): DocumentReference[] {
    const contextWeights: Record<string, Record<string, number>> = {
      biosafety: {
        'PROTOCOL': 1.3,
        'GUIDELINE': 1.2,
        'PROCEDURE': 1.1,
        'POLICY': 1.0,
        'MANUAL': 0.9,
        'REPORT': 0.8,
        'STANDARD': 0.7
      },
      research: {
        'PROTOCOL': 1.2,
        'GUIDELINE': 1.1,
        'POLICY': 1.0,
        'PROCEDURE': 0.9,
        'MANUAL': 0.8,
        'REPORT': 1.1,
        'STANDARD': 0.7
      },
      public_health: {
        'POLICY': 1.2,
        'GUIDELINE': 1.1,
        'PROCEDURE': 1.0,
        'REPORT': 1.1,
        'MANUAL': 0.9,
        'PROTOCOL': 0.8,
        'STANDARD': 0.7
      },
      compliance: {
        'POLICY': 1.3,
        'PROCEDURE': 1.2,
        'GUIDELINE': 1.1,
        'MANUAL': 1.0,
        'STANDARD': 0.9,
        'PROTOCOL': 0.8,
        'REPORT': 0.7
      },
      general: {
        'POLICY': 1.1,
        'PROCEDURE': 1.0,
        'GUIDELINE': 1.0,
        'MANUAL': 1.0,
        'REPORT': 1.0,
        'PROTOCOL': 1.0,
        'STANDARD': 1.0
      }
    };

    const weights = contextWeights[context] || contextWeights.general;
    
    // Aplica pesos contextuais aos scores de reranking
    const adjustedDocs = documents.map(doc => {
      const docType = doc.metadata?.documentType || 'UNKNOWN';
      const weight = weights[docType] || 1.0;
      
      return {
        ...doc,
        rerankScore: (doc.rerankScore || 0) * weight,
        contextualWeight: weight,
        contextType: context
      };
    });

    // Reordena por score ajustado
    return adjustedDocs.sort((a, b) => (b.rerankScore || 0) - (a.rerankScore || 0));
  }

  /**
   * Health check simples: envia 1 doc
   */
  async isAvailable(): Promise<boolean> {
    try {
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
        Accept: "application/json",
      };
      if (this.apiKey.startsWith("Bearer ")) {
        headers.Authorization = this.apiKey;
      } else {
        headers["api-key"] = this.apiKey;
        headers.Authorization = `Bearer ${this.apiKey}`;
      }

      const out = await fetch(this.endpoint, {
        method: "POST",
        headers,
        body: JSON.stringify({
          model: config.azureRerankModel || "Cohere-rerank-v3",
          query: "test",
          documents: ["test document"],
          top_n: 1,
          return_documents: false,
        }),
      });
      return out.ok;
    } catch {
      return false;
    }
  }
}
