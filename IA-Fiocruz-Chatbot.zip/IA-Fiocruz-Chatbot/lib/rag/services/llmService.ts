import { ChatOpenAI } from '@langchain/openai';
import { AzureChatOpenAI } from "@langchain/openai";
import { BaseMessage, HumanMessage, SystemMessage, AIMessage } from '@langchain/core/messages';
import { LLMModelConfig, RetryConfig, ChatMessage, DocumentReference } from '../types';
import { config, ragConfig } from '../config';

interface LLMResponse {
  content: string;
  model: {
    id: string;
    responseId: string;
    usage?: {
      promptTokens: number;
      completionTokens: number;
      totalTokens: number;
    };
    finishReason: string;
  };
  processingTime: number;
  startTime: string;
  endTime: string;
}

export class LLMService {
  private models: Map<string, ChatOpenAI> = new Map();
  private modelConfigs: LLMModelConfig[];
  private retryConfig: RetryConfig;

  constructor() {
    this.modelConfigs = ragConfig.models.filter(model => model.isAvailable);
    this.retryConfig = ragConfig.retryConfig;
    this.initializeModels();
  }

  /**
   * Initialize all available models
   */
  private initializeModels(): void {
    for (const modelConfig of this.modelConfigs) {
      if (modelConfig.provider === 'openai') {
        const model = new ChatOpenAI({
          openAIApiKey: config.openaiApiKey,
          modelName: modelConfig.name,
          temperature: modelConfig.temperature,
          maxTokens: modelConfig.maxTokens,
          timeout: 60000, // 60 second timeout
        });

        this.models.set(modelConfig.name, model);
      } else if (modelConfig.provider === 'azure') {

        // Build a correct base endpoint explicitly to avoid accidental use of a wrong env endpoint
        // const azureBaseEndpoint = config.azureOpenAIApiInstanceName
        //   ? `https://${config.azureOpenAIApiInstanceName}.openai.azure.com/`
        //   : undefined;

        const model = new AzureChatOpenAI({
          azureOpenAIApiKey: config.azureOpenAIApiKey,
          azureOpenAIApiInstanceName: config.azureOpenAIApiInstanceName,
          azureOpenAIApiVersion: config.azureOpenAIApiVersion,
          azureOpenAIApiDeploymentName: modelConfig.name,
          azureOpenAIEndpoint: config.azureOpenAIApiBaseEndpoint,
          temperature: modelConfig.temperature,
          maxTokens: modelConfig.maxTokens,
          timeout: 60000, // 60 second timeout
        });

        console.log(
          `Model ${modelConfig.name} initialized with Azure settings (endpoint: ${config.azureOpenAIApiBaseEndpoint ?? 'from instance name'})`
        );
        this.models.set(modelConfig.name, model);
        console.log(`Initialized model: ${modelConfig.name}`);
      }
    }

    console.log(`Initialized ${this.models.size} models`);
  }

  /**
   * Generate response with fallback models and retry logic
   */
  async generateResponse(
    query: string,
    context: DocumentReference[],
    conversationHistory: ChatMessage[] = []
  ): Promise<LLMResponse> {
    const availableModels = this.modelConfigs
      .sort((a, b) => a.priority - b.priority)
      .filter(config => this.models.has(config.name));

    if (availableModels.length === 0) {
      throw new Error('No available models configured');
    }
    console.log(`conversationHistory in generate response: ${JSON.stringify(conversationHistory)}`);
    let lastError: Error | null = null;

    for (const modelConfig of availableModels) {
      const model = this.models.get(modelConfig.name)!;

      try {
        const response = await this.callModelWithRetry(
          model,
          modelConfig.name,
          query,
          context,
          conversationHistory
        );
        return response;
      } catch (error) {
        console.error(`Model ${modelConfig.name} failed:`, error);
        lastError = error as Error;

        // Mark model temporarily unavailable if it's having issues
        if (this.isRateLimitOrServerError(error)) {
          console.log(`Temporarily marking ${modelConfig.name} as unavailable`);
        }

        continue; // Try next model
      }
    }

    // All models failed
    throw new Error(`All models failed. Last error: ${lastError?.message}`);
  }

  /**
   * Call model with retry logic
   */
  private async callModelWithRetry(
    model: ChatOpenAI | AzureChatOpenAI,
    modelName: string,
    query: string,
    context: DocumentReference[],
    conversationHistory: ChatMessage[]
  ): Promise<LLMResponse> {
    let attempt = 0;
    let delay = this.retryConfig.initialDelay;

    while (attempt < this.retryConfig.maxRetries) {
      try {
        const startTime = new Date().toISOString();
        const startTimeMs = Date.now();

        const messages = this.buildMessages(query, context, conversationHistory);

        const response = await model.invoke(messages);

        const endTime = new Date().toISOString();
        const processingTime = Date.now() - startTimeMs;

        console.log('LLM Service - End time:', endTime);
        console.log('LLM Service - Processing time:', processingTime, 'ms');

        // Extract token usage and response ID from response metadata
        const usage = response.response_metadata?.usage || response.usage_metadata;
        const responseId = response.response_metadata?.id || response.id || crypto.randomUUID();
        
        return {
          content: response.content as string,
          model: {
            id: modelName,
            responseId: responseId,
            usage: usage ? {
              promptTokens: usage.prompt_tokens || 0,
              completionTokens: usage.completion_tokens || 0,
              totalTokens: usage.total_tokens || 0
            } : undefined,
            finishReason: response.response_metadata?.finish_reason || 'stop'
          },
          processingTime,
          startTime,
          endTime,
        };
      } catch (error) {
        attempt++;
        console.error(`Attempt ${attempt}/${this.retryConfig.maxRetries} failed for ${modelName}:`, error);

        if (attempt >= this.retryConfig.maxRetries) {
          throw error;
        }

        // Exponential backoff with jitter
        const jitter = Math.random() * 0.1 * delay;
        await this.sleep(delay + jitter);
        delay = Math.min(
          delay * this.retryConfig.backoffMultiplier,
          this.retryConfig.maxDelay
        );
      }
    }

    throw new Error(`Max retries exceeded for model ${modelName}`);
  }

  /**
   * Build message array for LLM call
   */
  private buildMessages(
    query: string,
    context: DocumentReference[],
    conversationHistory: ChatMessage[]
  ): BaseMessage[] {
    const messages: BaseMessage[] = [];
    console.log(`conversationHistory: ${JSON.stringify(conversationHistory)}`);
    // System message with instructions
    messages.push(new SystemMessage(this.getSystemPrompt()));

    // Add conversation history (last 10 messages to avoid context overflow)
    const recentHistory = conversationHistory.slice(-10);
    for (const message of recentHistory) {
      if (message.role === 'user') {
        messages.push(new HumanMessage(message.content));
      } else {
        messages.push(new AIMessage(message.content));
      }
    }

    // Add current query with context
    const contextText = this.formatContext(context);
    const prompt = this.buildUserPrompt(query, contextText);
    messages.push(new HumanMessage(prompt));

    return messages;
  }

  /**
   * Get system prompt for Fiocruz document assistant
   */
  private getSystemPrompt(): string {
    return `### PROPÓSITO

Você é o **Assistente de Consulta de Documentos da Fiocruz**, operando com **RAG (Retrieval-Augmented Generation)**.
Seu papel é **responder perguntas com base exclusiva nos documentos institucionais** disponibilizados na base, especialmente **DFDs (Documentos de Formalização de Demanda)**, processos administrativos, contratos e especificações técnicas.

Você **NÃO PODE** inventar, inferir ou extrapolar além do que está explicitamente presente nos documentos. Sempre aponte as fontes.

---

### BASE DE CONHECIMENTO

Os documentos podem incluir:
- **DFDs (Documentos de Formalização de Demanda)** e processos com códigos específicos (ex: 25380.XXXXXX/YYYY-NN)
- **Especificações técnicas** (gramatura, tecido, certificações, SLA, frequência de entrega, etc.)
- **Normas e políticas** institucionais
- **Procedimentos e manuais** operacionais
- **Relatórios técnicos e científicos**
- **Diretrizes e regulamentações**
- **Justificativas de necessidade** e requisitos contratuais
- **Metadados** como código do processo, versão, data, seção, título e caminho do arquivo

---

### INSTRUÇÕES ESPECÍFICAS

1. **Fidelidade à fonte**: Responda somente com o que está explicitamente presente nos documentos citados. Não faça inferências sobre o que "provavelmente" está correto.

2. **Identificação de processos**: Quando o usuário mencionar códigos de processo (ex: 25380.003598/2024-78), busque e cite essas informações específicas. Se mencionar "o DFD do processo X", foque apenas naquele documento específico.

3. **Especificações técnicas detalhadas**: Para perguntas sobre especificações (gramatura, tecido, certificações, SLA, frequência, periodicidade, tiragem mínima, tamanhos padronizados, etc.), busque trechos exatos que mencionem esses requisitos. Se não houver menção específica, indique claramente que não foi encontrado.

4. **Comparações entre processos**: Quando o usuário pedir para comparar dois ou mais processos, analise cada um separadamente nos documentos e apresente as diferenças e semelhanças encontradas, sempre citando as fontes específicas.

5. **Perguntas sobre elaboração de DFDs**: Para questões sobre "como redigir um DFD", "etapas de elaboração", "dicas de redação", busque nos documentos guias, manuais ou diretrizes que tratem especificamente desse assunto administrativo.

6. **Citações**: Sempre inclua referências com código do processo (quando aplicável), título/código do documento, seção ou página quando possível, e caminho/arquivo. Se houver código de processo mencionado no documento, sempre cite-o.

7. **Clareza e estrutura**: Estruture respostas objetivas, usando bullets quando adequado. Para especificações técnicas, seja direto e específico sobre o que foi encontrado ou não encontrado.

8. **Informações ausentes**: Se a base não contiver a informação solicitada (mesmo sendo algo comum em DFDs, como SLA, frequência, certificação), diga claramente que não foi encontrado naquele processo/documento específico. Não invente ou assuma valores padrão.

9. **Contexto administrativo**: Entenda que as perguntas frequentemente envolvem processos de contratação, documentação administrativa e requisitos técnicos. Mantenha foco nas informações documentais disponíveis.

---

### FORMATO DA RESPOSTA
- Resposta objetiva em português
- Destaque o código do processo quando relevante
- Seja específico sobre especificações técnicas encontradas (ou não encontradas)
- Lista de referências ao final com: código do processo (quando aplicável), título/código, trecho relevante e fonte (arquivo/caminho)
`;
  }

  /**
   * Build user prompt with query and context
   */
  private buildUserPrompt(query: string, contextText: string): string {
    // Enhanced prompt with semantic search guidance
    const enhancedQuery = this.enhanceQueryForSemanticSearch(query);

    return `**Consulta:** ${query}

**Contexto de Documentos Recuperados:**
${contextText}

**Instruções para Responder:**
1. Utilize apenas trechos presentes nos documentos acima.
2. Seja objetivo e cite as fontes ao final.
3. Se faltar contexto, indique o que não foi encontrado e sugira termos para refinar a busca.
`;
      ;
  }

  /**
   * Enhance query with related terms for better semantic search
   */
  private enhanceQueryForSemanticSearch(query: string): string {
    const queryLower = query.toLowerCase();
    const enhancements: string[] = [];

    // Termos relacionados a DFDs e processos administrativos
    if (queryLower.includes('dfd') || queryLower.includes('formalização de demanda') || queryLower.includes('documento de formalização')) {
      enhancements.push('DFD', 'Documento de Formalização de Demanda', 'processo administrativo', 'contratação');
    }
    if (/\d{5}\.\d{6}\/\d{4}-\d{2}/.test(query)) {
      enhancements.push('código de processo', 'número de processo', 'processo administrativo');
    }
    if (queryLower.includes('processo') && (queryLower.includes('25380') || queryLower.includes('contrat') || queryLower.includes('licit'))) {
      enhancements.push('processo de contratação', 'processo licitatório', 'edital');
    }
    if (queryLower.includes('contrat') || queryLower.includes('licit') || queryLower.includes('fornec')) {
      enhancements.push('contratação', 'contrato', 'fornecedor', 'especificação técnica');
    }
    if (queryLower.includes('gramatura') || queryLower.includes('tecido') || queryLower.includes('certificação') || queryLower.includes('sla') || queryLower.includes('frequência')) {
      enhancements.push('especificação técnica', 'requisito técnico', 'especificação');
    }
    if (queryLower.includes('redigir') || queryLower.includes('elaborar') || queryLower.includes('como fazer') || queryLower.includes('etapas')) {
      enhancements.push('guia', 'manual', 'diretriz', 'procedimento');
    }

    // Termos institucionais comuns em acervos documentais
    if (queryLower.includes('política') || queryLower.includes('policy')) {
      enhancements.push('política institucional', 'policy', 'diretriz');
    }
    if (queryLower.includes('norma') || queryLower.includes('procedimento') || queryLower.includes('manual')) {
      enhancements.push('norma', 'procedimento operacional', 'manual', 'SOP');
    }
    if (queryLower.includes('saúde') || queryLower.includes('vigilância')) {
      enhancements.push('saúde pública', 'vigilância em saúde');
    }
    if (queryLower.includes('pesquisa') || queryLower.includes('laboratório') || queryLower.includes('biossegurança')) {
      enhancements.push('pesquisa científica', 'laboratório', 'biossegurança');
    }
    if (queryLower.includes('ética') || queryLower.includes('compliance')) {
      enhancements.push('ética', 'integridade', 'compliance', 'governança');
    }

    return enhancements.length > 0 ? enhancements.join(', ') : 'documento institucional, norma, manual, diretriz, relatório, DFD';
  }

  /**
   * Format context from document references
   */
  private formatContext(context: DocumentReference[]): string {
    if (context.length === 0) {
      return 'Nenhum documento relevante encontrado.';
    }

    const contextParts: string[] = [];

    context.forEach((ref, index) => {
      const docInfo: string[] = [];
      docInfo.push(`**Documento ${index + 1}:**`);
      
      // Metadados do documento
      const metadata = ref.metadata as any;
      if (metadata.title) docInfo.push(`- Título: ${metadata.title}`);
      if (metadata.code) docInfo.push(`- Código: ${metadata.code}`);
      if (metadata.version) docInfo.push(`- Versão: ${metadata.version}`);
      if (metadata.pageNumber) docInfo.push(`- Página: ${metadata.pageNumber}`);
      if (metadata.documentType) docInfo.push(`- Tipo: ${metadata.documentType}`);
      if (metadata.category) docInfo.push(`- Categoria: ${metadata.category}`);
      if (ref.rerankScore !== undefined) docInfo.push(`- Score de Relevância: ${ref.rerankScore.toFixed(3)}`);
      
      // Fonte do documento
      const src = ref.metadata.filepath || ref.metadata.title || ref.metadata.source || 'unknown';
      docInfo.push(`- Fonte: ${this.getShortSource(src)}`);
      
      docInfo.push(`\n**Trecho do Documento:**\n${ref.content}\n`);
      contextParts.push(docInfo.join('\\n'));
    });

    return contextParts.join('\\n---\\n\\n');
  }

  /**
   * Get shortened source path for display
   */
  private getShortSource(source: string): string {
    const parts = source.split('/');
    if (parts.length > 3) {
      return `.../${parts.slice(-3).join('/')}`;
    }
    return source;
  }

  /**
   * Check if error is rate limit or server error (retriable)
   */
  private isRateLimitOrServerError(error: any): boolean {
    const errorMessage = error?.message?.toLowerCase() || '';
    const errorCode = error?.status || error?.code;

    return (
      errorCode === 429 || // Rate limit
      errorCode === 500 || // Server error
      errorCode === 502 || // Bad gateway
      errorCode === 503 || // Service unavailable
      errorMessage.includes('rate limit') ||
      errorMessage.includes('timeout') ||
      errorMessage.includes('server error')
    );
  }

  /**
   * Get model status and statistics
   */
  getModelStats(): Array<{
    name: string;
    priority: number;
    isAvailable: boolean;
    maxTokens: number;
  }> {
    return this.modelConfigs.map(config => ({
      name: config.name,
      priority: config.priority,
      isAvailable: this.models.has(config.name),
      maxTokens: config.maxTokens,
    }));
  }

  /**
   * Test model availability
   */
  async testModels(): Promise<Map<string, boolean>> {
    const results = new Map<string, boolean>();

    for (const [modelName, model] of this.models) {
      try {
        console.log(`Testing model: ${modelName}, Model: ${model}`);
        await model.invoke([new HumanMessage('Test message')]);
        results.set(modelName, true);
      } catch (error) {
        console.error(`Model ${modelName} test failed:`, error);
        results.set(modelName, false);
      }
    }

    return results;
  }

  /**
   * Utility function to sleep
   */
  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}