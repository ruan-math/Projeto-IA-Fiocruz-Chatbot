import { v4 as uuidv4 } from 'uuid';
import { citationController } from '../controllers/citationController';
import { Citation } from '@/interface/models/citationModels';
import { DocumentReference } from '../types';

export class CitationService {
  /**
   * Save citations for a message
   */
  async saveCitations(
    messageId: string,
    chatId: string,
    userId: string,
    references: DocumentReference[]
  ): Promise<Citation[]> {
    const citations: Citation[] = [];
    const now = new Date().toISOString();

    for (let i = 0; i < references.length; i++) {
      const ref = references[i];
      const citationId = uuidv4();
      
      const citation: Citation = {
        id: citationId,
        messageId,
        chatId,
        userId,
        citationIndex: i + 1, // Start from 1
        filepath: ref.metadata?.filepath || undefined,
        chunk_id: ref.metadata?.chunk_id || '0',
        content: ref.content,
        title: this.extractFileName(ref.metadata?.filepath || ref.metadata?.title || ref.metadata?.source || 'Unknown Document'),
        url: ref.metadata?.url || undefined,
        reference: `[${i + 1}]`,
        createdAt: now,
        updatedAt: now,
      };

      await citationController.create(citation);
      citations.push(citation);
    }

    return citations;
  }

  /**
   * Get citations for a specific message
   */
  async getCitationsByMessageId(messageId: string): Promise<Citation[]> {
    const query = {
      query: 'SELECT * FROM c WHERE c.messageId = @messageId ORDER BY c.citationIndex ASC',
      parameters: [{ name: '@messageId', value: messageId }]
    };
    
    return await citationController.list(query);
  }

  /**
   * Get citations for a specific chat
   */
  async getCitationsByChatId(chatId: string): Promise<Citation[]> {
    const query = {
      query: 'SELECT * FROM c WHERE c.chatId = @chatId ORDER BY c.createdAt ASC',
      parameters: [{ name: '@chatId', value: chatId }]
    };
    
    return await citationController.list(query);
  }

  /**
   * Delete citations for a specific message
   */
  async deleteCitationsByMessageId(messageId: string): Promise<void> {
    const citations = await this.getCitationsByMessageId(messageId);
    
    for (const citation of citations) {
      await citationController.delete(citation.id);
    }
  }

  /**
   * Delete citations for a specific chat
   */
  async deleteCitationsByChatId(chatId: string): Promise<void> {
    const citations = await this.getCitationsByChatId(chatId);
    
    for (const citation of citations) {
      await citationController.delete(citation.id);
    }
  }

  /**
   * Extract filename from full path
   */
  private extractFileName(title: string): string {
    if (!title) return 'Unknown Document';
    
    // If it's already just a filename (no path separators), return as is
    if (!title.includes('/') && !title.includes('\\')) {
      return title;
    }
    
    // Handle Windows paths (C:\Users\...)
    if (title.includes(':\\')) {
      const fileName = title.split('\\').pop();
      return fileName || 'Unknown Document';
    }
    
    // Handle Unix paths and URLs
    const fileName = title.split('/').pop() || title.split('\\').pop() || title;
    
    // Remove any query parameters or fragments from URL-like strings
    const cleanFileName = fileName.split('?')[0].split('#')[0];
    
    // Decode URL encoding if present
    try {
      return decodeURIComponent(cleanFileName) || 'Unknown Document';
    } catch {
      return cleanFileName || 'Unknown Document';
    }
  }
}
