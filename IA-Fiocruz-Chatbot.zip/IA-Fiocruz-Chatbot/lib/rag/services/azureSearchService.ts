import { SearchClient, AzureKeyCredential } from "@azure/search-documents";
import { AzureOpenAI } from "openai";
import { cookies } from "next/headers";
import type { DocumentReference, DocumentMetadata } from "../types";
import { config } from "../config";

/**
 * Azure AI Search powered retriever using Azure OpenAI embeddings.
 * Config values are read from environment variables via config.
 */
export class AzureSearchService {
  private client: SearchClient<any>;

  constructor() {
    this.assertConfig();
    this.client = new SearchClient(
      config.azureSearchEndpoint!,
      config.azureSearchIndex!,
      new AzureKeyCredential(config.azureSearchApiKey!)
    );
  }

  private assertConfig() {
    const missing: string[] = [];
    if (!config.azureSearchEndpoint) missing.push("AZURE_SEARCH_ENDPOINT");
    if (!config.azureSearchIndex) missing.push("AZURE_SEARCH_INDEX");
    if (!config.azureSearchApiKey) missing.push("AZURE_SEARCH_API_KEY");
    if (!config.azureOpenAIEmbeddingEndpoint) missing.push("AZURE_OPENAI_EMBEDDING_ENDPOINT");
    if (!config.azureOpenAIApiKey) missing.push("AZURE_OPENAI_API_KEY");
    if (!config.azureOpenAIApiVersion) missing.push("AZURE_OPENAI_API_VERSION");
    if (!config.azureOpenAIEmbeddingsDeployment) missing.push("AZURE_OPENAI_EMBEDDINGS_DEPLOYMENT");

    if (missing.length) {
      throw new Error(
        `Missing Azure configuration: ${missing.join(", ")}. Please set them in .env.local`
      );
    }
  }

  private getAzureOpenAIEmbeddingsClient() {
    return new AzureOpenAI({
      endpoint: config.azureOpenAIEmbeddingEndpoint!,
      apiKey: config.azureOpenAIApiKey!,
      deployment: config.azureOpenAIEmbeddingsDeployment!,
      apiVersion: config.azureOpenAIApiVersion!,
    });
  }

  private async getQueryEmbedding(query: string): Promise<number[]> {
    const aoai = this.getAzureOpenAIEmbeddingsClient();
    const res = await aoai.embeddings.create({
      model: config.azureOpenAIEmbeddingsDeployment!,
      input: query,
    });
    return res.data[0].embedding as number[];
  }
  /**
   * Return total number of indexed documents (chunks) in Azure AI Search
   * Used to replace legacy vector store stats.
   */
  // getDocumentCount removido conforme requisito (não contar documentos)
  async searchSimilar(query: string, topK: number = 10): Promise<DocumentReference[]> {
    const vector = await this.getQueryEmbedding(query);

    // Tentar diferentes nomes de campos vetoriais comuns
    const possibleVectorFields = ["contentVector", "embedding", "vector", "content_vector", "textVector"];
    let searchResults;
    let lastError: any;
    
    for (const fieldName of possibleVectorFields) {
      try {
        const vectorQuery: any = {
          vector,
          kNearestNeighborsCount: Math.max(1, topK),
          fields: [fieldName],
          kind: "vector",
          exhaustive: true,
        };
   
        let securityGroup: string | undefined;
        if (config.appUseAiSearchFilter) {
          try {
            const ck: any = await (cookies() as any);
            if (ck && typeof ck.get === 'function') {
              securityGroup = ck.get("azure-groups-of-user")?.value;
            }
          } catch {}
        }

        const selectableFields = [
          "file",
          "content",
          "chunk_content",
          "source_page_range",
          "source_file",
          "chunk_id",
          "parent_id",
          "title",
          "url",
          "filepath"
        ];

        const searchOptions: any = {
          top: Math.max(1, topK),
          select: selectableFields,
          includeTotalCount: true,
          vectorSearchOptions: {
            queries: [vectorQuery],
            filterMode: "postFilter",
          },
          ...(securityGroup && { filter: securityGroup }),
        };

        try {
          searchResults = await this.client.search("*", searchOptions);
          console.log(`Azure AI Search successful using field: ${fieldName}`);
          break; // Sucesso, sair do loop
        } catch (err: any) {
          // Fallback: retry without $select if schema mismatch
          const msg = err?.message || '';
          if (/Invalid expression/i.test(msg) || /Could not find a property/i.test(msg)) {
            const fallbackOpts = { ...searchOptions };
            delete fallbackOpts.select;
            searchResults = await this.client.search("*", fallbackOpts);
            console.log(`Azure AI Search successful using field: ${fieldName} (fallback)`);
            break; // Sucesso com fallback, sair do loop
          } else {
            lastError = err;
            console.log(`Failed with field ${fieldName}: ${err.message}`);
            continue; // Tentar próximo campo
          }
        }
      } catch (error: any) {
        lastError = error;
        console.log(`Failed with field ${fieldName}: ${error.message}`);
        continue; // Tentar próximo campo
      }
    }
    
    // Se nenhum campo funcionou, lançar erro
    if (!searchResults) {
      throw new Error(`No valid vector field found in Azure AI Search index. Last error: ${lastError?.message || 'Unknown error'}`);
    }

    const refs: DocumentReference[] = [];
    for await (const r of (searchResults as any).results) {
      const d: any = r.document ?? {};

      const sourceFile = String(d.source_file ?? d.file ?? d.id ?? d.filepath ?? 'azure-search');

      const codeRegex = /(MANUAL-\d{4}|POLICY-[A-Z]{2}-\d{4}|PROCEDURE-\d{4})/i;
      const versionRegex = /[_-](R\.\d{2})/i;
      const codeMatch = sourceFile.match(codeRegex);
      const versionMatch = sourceFile.match(versionRegex);

  // Detecta o tipo de documento pela ocorrência (não apenas início) do padrão no nome do arquivo
  const rawCode = codeMatch ? codeMatch[1].toUpperCase() : undefined;
  const upperSource = sourceFile.toUpperCase();

      // Category: higher level grouping for UI/LLM context
      let category: string = 'AzureSearch';
      let documentType: string = 'PDF';

      // Simplifica lógica de chunk_id removendo montagem baseada em código
      const chunk_id = typeof d.chunk_id === 'string'
        ? d.chunk_id
        : (typeof d.id === 'string'
          ? d.id
          : (typeof d.chunk_index === 'number' ? `CHUNK_${d.chunk_index}` : 'CHUNK_UNKNOWN'));

      const metadata: DocumentMetadata = {
        chunk_id,
        parent_id: typeof d.parent_id === 'string' ? d.parent_id : undefined,
        title: typeof d.title === 'string' ? d.title : sourceFile,
        url: typeof d.url === 'string' ? d.url : undefined,
        filepath: typeof d.filepath === 'string' ? d.filepath : sourceFile,
        source: sourceFile,
        documentType,
        code: codeMatch ? codeMatch[1].toUpperCase() : undefined,
        category,
        version: versionMatch ? versionMatch[1].toUpperCase() : undefined,
        pageNumber: typeof d.chapter === "number" ? d.chapter : undefined,
        chunkIndex: typeof d.chunk_index === "number" ? d.chunk_index : undefined,
      };

      const rawContent = d.content ?? d.chunk_content;
      refs.push({
        source: metadata.filepath || metadata.source || sourceFile,
        content: typeof rawContent === 'string' ? rawContent : String(rawContent ?? ''),
        metadata,
        score: typeof r.score === "number" ? r.score : 0,
        rerankScore: typeof r.rerankerScore === "number" ? r.rerankerScore : undefined,
      });
    }

    // Highest score first
    return refs.sort((a, b) => b.score - a.score);
  }
}

export default AzureSearchService;
