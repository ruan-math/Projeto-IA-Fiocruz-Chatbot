// lib/rag/controllers/feedbackController.ts
import { CosmosConversationController } from '@/lib/rag/cosmos/cosmosController';
import { Feedback } from '@/interface/models/feedbackModels';

export const feedbackController = CosmosConversationController<Feedback>('feedbacks');
