// lib/rag/controllers/messageController.ts

import { CosmosConversationController } from '../cosmos/cosmosController';
import { Message } from '@/interface/models/messageModels';

export const messageController = CosmosConversationController<Message>('messages');
