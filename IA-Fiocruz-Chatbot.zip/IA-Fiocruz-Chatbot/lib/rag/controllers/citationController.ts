import { CosmosConversationController } from '../cosmos/cosmosController';
import { Citation } from '@/interface/models/citationModels';

export const citationController = CosmosConversationController<Citation>('citations');
