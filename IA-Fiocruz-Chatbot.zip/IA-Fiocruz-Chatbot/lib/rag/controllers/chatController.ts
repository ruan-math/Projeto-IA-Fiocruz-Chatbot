// lib/rag/controllers/chatController.ts

import { CosmosConversationController } from '../cosmos/cosmosController';
import { Chat } from '@/interface/models/conversationModels';

export const chatController = CosmosConversationController<Chat>('chats');
