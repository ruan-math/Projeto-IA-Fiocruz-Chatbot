// lib/rag/db/initCosmos.ts
import { CosmosClient } from "@azure/cosmos"
import { env } from "@/app/config/env"

const endpoint = env.NEXT_PUBLIC_COSMOSDB_ENDPOINT!
const key = env.NEXT_PUBLIC_COSMOSDB_PRIMARY_KEY!
const databaseId = env.NEXT_PUBLIC_COSMOSDB_DATABASE!
const prefix = env.NEXT_PUBLIC_COSMOSDB_CONTAINER_PREFIX!

const client = new CosmosClient({ endpoint, key })
const database = client.database(databaseId)

export async function createContainerIfNotExists(containerId: string) {
  // Define partition key based on container type
  let partitionKeyPath = "/userId" // default
  
  if (containerId === "attachments") {
    partitionKeyPath = "/chatId"
  } else if (containerId === "messages") {
    partitionKeyPath = "/conversationId"
  } else if (containerId === "citations") {
    partitionKeyPath = "/conversationId"
  }

  await database.containers.createIfNotExists({
    id: `${prefix}_${containerId}`,
    partitionKey: {
      paths: [partitionKeyPath]
    }
  })
}

// Cache to avoid re-initializing containers
let containersInitialized = false;

// Initialize all required containers
export async function initializeAllContainers() {
  if (containersInitialized) {
    return; // Skip if already initialized
  }
  
  const containers = ['chats', 'messages', 'citations', 'feedbacks', 'attachments']
  
  for (const containerId of containers) {
    await createContainerIfNotExists(containerId)
  }
  
  containersInitialized = true;
  console.log('All Cosmos DB containers initialized successfully')
}
