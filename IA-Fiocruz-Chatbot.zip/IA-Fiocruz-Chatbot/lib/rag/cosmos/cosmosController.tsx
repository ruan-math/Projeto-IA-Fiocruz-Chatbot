// lib/rag/db/cosmosController.ts
import { Container, CosmosClient } from "@azure/cosmos"
import { env } from "@/app/config/env"
import { GenericController, QueryExpression } from "@/interface/controller"
import { BaseModel } from "@/interface/models/baseModel"

const endpoint = env.NEXT_PUBLIC_COSMOSDB_ENDPOINT!
const key = env.NEXT_PUBLIC_COSMOSDB_PRIMARY_KEY!
const databaseId = env.NEXT_PUBLIC_COSMOSDB_DATABASE!
const prefix = env.NEXT_PUBLIC_COSMOSDB_CONTAINER_PREFIX!

const client = new CosmosClient({ endpoint, key })
const database = client.database(databaseId)

export function CosmosConversationController<T extends BaseModel>(containerId: string): GenericController<T> {
  const container: Container = database.container(`${prefix}_${containerId}`)

  return {
    async get(id: string) {
      const query: QueryExpression = {
        query: "SELECT * FROM c WHERE c.id = @id",
        parameters: [{ name: "@id", value: id }]
      }

      const { resources } = await container.items.query(query).fetchAll()
      const result = resources.length > 0 ? resources[0] as T : null
    
      
      return result
    },

    async list(query?: QueryExpression) {
      const response = query
        ? await container.items.query(query).fetchAll()
        : await container.items.readAll().fetchAll()

      return response.resources as T[]
    },

    async create(data: T): Promise<T> {
      // Only set timestamps if they don't exist
      if (!data.createdAt) {
        data.createdAt = new Date().toISOString()
      }
      if (!data.updatedAt) {
        data.updatedAt = new Date().toISOString()
      }
      
      const { resource } = await container.items.create(data)
      
      return resource as T
    },

    async update(id: string, data: Partial<T>) {
      const query = {
        query: "SELECT * FROM c WHERE c.id = @id",
        parameters: [{ name: "@id", value: id }]
      }

      const { resources } = await container.items.query(query).fetchAll()
      if (!resources.length) throw new Error(`Item with id ${id} not found`)

      const resource = resources[0]
      const partitionKey = resource.userId ?? 'anonymous'

      data.updatedAt = new Date().toISOString()
      const updated = { ...resource, ...data }

      await container.item(resource.id, partitionKey).replace(updated)
      return updated
    },

    async delete(id: string) {
      const query = {
        query: "SELECT * FROM c WHERE c.id = @id",
        parameters: [{ name: "@id", value: id }]
      }

      const { resources } = await container.items.query(query).fetchAll()
      if (!resources.length) throw new Error(`Item with id ${id} not found`)

      const resource = resources[0]
      const partitionKey = resource.userId ?? 'anonymous'

      await container.item(id, partitionKey).delete()
    }
  }
}
