export interface DocumentMetadata {
  // Alinhado ao formato requerido do Azure AI Search (mantendo apenas campos necessários)
  chunk_id: string;              // Identificador único do chunk
  parent_id?: string;            // ID do documento pai
  title?: string;                // Título / nome do arquivo
  url?: string;                  // URL de acesso
  filepath?: string;             // Nome do arquivo
  documentType?: string;         // IMAM / IMSA inferido (opcional)
  code?: string;                 // Código (IMAM-0003 etc.)
  pageNumber?: number;           // Página (se disponível)
  chunkIndex?: number;           // Índice sequencial (fallback caso chunk_id não baste)
  source?: string;               // Compatibilidade antiga (igual a filepath)
  category?: string;             // Categoria inferida
  version?: string;              // Versão (R.04) se detectada
  
  // Metadados adicionais de documentos institucionais
  section?: string;              // Seção/capítulo
  publishedAt?: string;          // Data de publicação (ISO)
  organization?: string;         // Ex.: Fiocruz/Unidades
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string; // ISO date string
  references?: DocumentReference[];
  model?: {
    id: string;
    responseId?: string;
    usage?: {
      promptTokens: number;
      completionTokens: number;
      totalTokens: number;
    };
    finishReason?: string;
  };
  processingTime?: number;
}

export interface DocumentReference {
  id?: string;
  source: string;
  content: string;
  metadata: DocumentMetadata;
  score: number;
  rerankScore?: number;
}

export interface ConversationHistory {
  id: string;
  messages: ChatMessage[];
  createdAt: string; // ISO date string
  updatedAt: string; // ISO date string
}

export interface ChunkData {
  content: string;
  metadata: DocumentMetadata;
  embedding?: number[];
}

export interface RAGResponse {
  answer: string;
  references: DocumentReference[];
  model: {
    id: string;
    responseId: string;
    usage?: {
      promptTokens: number;
      completionTokens: number;
      totalTokens: number;
    };
    finishReason: string;
  };
  confidence: number;
  processingTime: number;
  startTime?: string;
  endTime?: string;
}

export interface RetryConfig {
  maxRetries: number;
  initialDelay: number;
  backoffMultiplier: number;
  maxDelay: number;
}

export interface LLMModelConfig {
  name: string;
  provider: 'openai' | 'anthropic' | 'cohere' | 'azure';
  priority: number;
  maxTokens: number;
  temperature: number;
  isAvailable: boolean;
}

export interface RAGConfig {
  chunkSize: number;
  chunkOverlap: number;
  topK: number;
  rerankTopK: number;
  similarityThreshold: number;
  models: LLMModelConfig[];
  retryConfig: RetryConfig;
}