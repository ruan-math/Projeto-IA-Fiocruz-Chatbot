// Global type declarations for the Agent Chatbot

declare module 'pdf-parse' {
  interface PDFParseResult {
    numpages: number;
    numrender: number;
    info: any;
    metadata: any;
    text: string;
    version: string;
  }

  function pdfParse(buffer: Buffer): Promise<PDFParseResult>;
  export = pdfParse;
}

declare module 'cohere-ai' {
  export interface RerankRequest {
    model: string;
    query: string;
    documents: Array<{ text: string; id: string }>;
    topN?: number;
    returnDocuments?: boolean;
  }

  export interface RerankResult {
    index: number;
    relevanceScore: number;
    document?: { text: string; id: string };
  }

  export interface RerankResponse {
    results: RerankResult[];
  }

  export class CohereClient {
    constructor(options: { token: string });
    rerank(request: RerankRequest): Promise<RerankResponse>;
  }
}

// Extended console type for Node.js environment
declare global {
  namespace NodeJS {
    interface Global {
      console: Console;
    }
  }
}