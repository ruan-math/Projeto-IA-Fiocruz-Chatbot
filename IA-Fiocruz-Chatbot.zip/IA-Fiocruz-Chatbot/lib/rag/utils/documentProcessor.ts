import fs from 'fs';
import path from 'path';
import pdf from 'pdf-parse';
import { DocumentMetadata, ChunkData } from '../types';

export class DocumentProcessor {
  private static readonly CHUNK_SIZE = 1000;
  private static readonly CHUNK_OVERLAP = 200;

  /**
   * Process all PDF documents in the Fiocruz documents directory
   */
  async processAllDocuments(fiocruzDocsDir: string): Promise<ChunkData[]> {
    const allChunks: ChunkData[] = [];
    
    // Process Institutional Manuals
    const manualsDir = path.join(fiocruzDocsDir, 'Manuais Institucionais');
    if (fs.existsSync(manualsDir)) {
      const manualChunks = await this.processInstitutionalManuals(manualsDir);
      allChunks.push(...manualChunks);
    }

    // Process Institutional Policies and Procedures
    const policiesDir = path.join(fiocruzDocsDir, 'Políticas e Procedimentos Institucionais');
    if (fs.existsSync(policiesDir)) {
      const policyChunks = await this.processInstitutionalPolicies(policiesDir);
      allChunks.push(...policyChunks);
    }

    return allChunks;
  }

  /**
   * Process institutional manuals with intelligent chunking
   */
  private async processInstitutionalManuals(manualsDir: string): Promise<ChunkData[]> {
    const chunks: ChunkData[] = [];
    const manualDirs = fs.readdirSync(manualsDir, { withFileTypes: true })
      .filter(dirent => dirent.isDirectory())
      .map(dirent => dirent.name);

    for (const manualDir of manualDirs) {
      const manualPath = path.join(manualsDir, manualDir);
      const manualNumber = this.extractManualNumber(manualDir);
      const category = this.extractManualCategory(manualDir);

      // Check for language-specific folders
      const languageDirs = ['English', 'Español', 'Português'];
      let hasLanguageFolders = false;

      for (const lang of languageDirs) {
        const langPath = path.join(manualPath, lang);
        if (fs.existsSync(langPath)) {
          hasLanguageFolders = true;
          const langChunks = await this.processPDFsInDirectory(langPath, {
            documentType: 'MANUAL',
            category,
            version: manualNumber,
          });
          chunks.push(...langChunks);
        }
      }

      // If no language folders, process PDFs directly in manual folder
      if (!hasLanguageFolders) {
        const directChunks = await this.processPDFsInDirectory(manualPath, {
          documentType: 'MANUAL',
          category,
          version: manualNumber,
        });
        chunks.push(...directChunks);
      }
    }

    return chunks;
  }

  /**
   * Process Institutional Policies with hierarchical structure awareness
   */
  private async processInstitutionalPolicies(policiesDir: string): Promise<ChunkData[]> {
    const chunks: ChunkData[] = [];
    
    const processDirectory = async (dirPath: string, category: string) => {
      const items = fs.readdirSync(dirPath, { withFileTypes: true });
      
      for (const item of items) {
        const itemPath = path.join(dirPath, item.name);
        
        if (item.isDirectory()) {
          // Determine document type from folder name
          const docType = this.determineDocumentType(item.name);
          if (docType) {
            const docChunks = await this.processPDFsInDirectory(itemPath, {
              documentType: docType,
              category,
            });
            chunks.push(...docChunks);
          } else {
            // Recurse into subcategory
            await processDirectory(itemPath, `${category}/${item.name}`);
          }
        } else if (item.name.toLowerCase().endsWith('.pdf')) {
          // Process PDF directly
          const pdfChunks = await this.processPDF(itemPath, {
            documentType: 'POLICY', // Default for top-level PDFs
            category,
          });
          chunks.push(...pdfChunks);
        }
      }
    };

    const categories = fs.readdirSync(policiesDir, { withFileTypes: true })
      .filter(dirent => dirent.isDirectory())
      .map(dirent => dirent.name);

    for (const category of categories) {
      const categoryPath = path.join(policiesDir, category);
      await processDirectory(categoryPath, category);
    }

    return chunks;
  }

  /**
   * Process all PDFs in a directory
   */
  private async processPDFsInDirectory(dirPath: string, baseMetadata: Partial<DocumentMetadata>): Promise<ChunkData[]> {
    const chunks: ChunkData[] = [];
    
    try {
      const files = fs.readdirSync(dirPath);
      const pdfFiles = files.filter(file => file.toLowerCase().endsWith('.pdf'));

      for (const pdfFile of pdfFiles) {
        const pdfPath = path.join(dirPath, pdfFile);
        try {
          const pdfChunks = await this.processPDF(pdfPath, baseMetadata);
          chunks.push(...pdfChunks);
        } catch (error) {
          console.error(`Error processing PDF ${pdfPath}:`, error);
        }
      }
    } catch (error) {
      console.error(`Error reading directory ${dirPath}:`, error);
    }

    return chunks;
  }

  /**
   * Process a single PDF file with intelligent chunking
   */
  private async processPDF(filePath: string, baseMetadata: Partial<DocumentMetadata>): Promise<ChunkData[]> {
    try {
      const dataBuffer = fs.readFileSync(filePath);
      const pdfData = await pdf(dataBuffer);
      
      const metadata: DocumentMetadata = {
        chunk_id: `${path.basename(filePath)}_${Date.now()}`,
        source: filePath,
        filepath: path.basename(filePath),
        documentType: baseMetadata.documentType!,
        category: baseMetadata.category!,
        version: baseMetadata.version,
        publishedAt: new Date().toISOString(),
        organization: 'Fiocruz',
      };

      // Extract text and apply intelligent chunking
      const text = pdfData.text;
      const chunks = this.performIntelligentChunking(text, metadata, pdfData.numpages);

      return chunks;
    } catch (error) {
      console.error(`Error processing PDF ${filePath}:`, error);
      return [];
    }
  }

  /**
   * Intelligent chunking based on document structure
   */
  private performIntelligentChunking(text: string, baseMetadata: DocumentMetadata, totalPages: number): ChunkData[] {
    const chunks: ChunkData[] = [];
    
    // Clean and normalize text
    const cleanText = this.cleanText(text);
    
    // Try to identify document sections
    const sections = this.identifyDocumentSections(cleanText);
    
    if (sections.length > 1) {
      // Chunk by sections for better semantic coherence
      let chunkIndex = 0;
      
      for (const section of sections) {
        const sectionChunks = this.chunkTextBySentences(section.content, DocumentProcessor.CHUNK_SIZE, DocumentProcessor.CHUNK_OVERLAP);
        
        for (const chunk of sectionChunks) {
          chunks.push({
            content: `${section.title ? section.title + '\\n\\n' : ''}${chunk}`,
            metadata: {
              ...baseMetadata,
              chunkIndex: chunkIndex++,
              pageNumber: section.estimatedPage,
            },
          });
        }
      }
    } else {
      // Fallback to standard chunking with sentence boundaries
      const textChunks = this.chunkTextBySentences(cleanText, DocumentProcessor.CHUNK_SIZE, DocumentProcessor.CHUNK_OVERLAP);
      
      textChunks.forEach((chunk, index) => {
        chunks.push({
          content: chunk,
          metadata: {
            ...baseMetadata,
            chunkIndex: index,
            pageNumber: Math.ceil((index / textChunks.length) * totalPages),
          },
        });
      });
    }

    return chunks;
  }

  /**
   * Clean and normalize extracted text
   */
  private cleanText(text: string): string {
    return text
      .replace(/\\s+/g, ' ')  // Multiple spaces to single space
      .replace(/\\n{3,}/g, '\\n\\n')  // Multiple newlines to double newline
      .replace(/[\\x00-\\x1F\\x7F]/g, '')  // Remove control characters
      .trim();
  }

  /**
   * Identify document sections based on common patterns
   */
  private identifyDocumentSections(text: string): Array<{ title?: string; content: string; estimatedPage?: number }> {
    const sections: Array<{ title?: string; content: string; estimatedPage?: number }> = [];
    
    // Common section patterns for governance documents
    const sectionPatterns = [
      /^\\d+\\.\\s+[A-Z][^\\n]{10,100}$/gm,  // Numbered sections
      /^[A-Z][A-Z\\s]{5,50}:?$/gm,  // All caps headers
      /^[IVX]+\\.\\s+[A-Z][^\\n]{10,100}$/gm,  // Roman numeral sections
      /^(Purpose|Scope|Definitions|Procedures|Responsibilities|Policy|Overview|Background|Application|Implementation|Controls|Requirements)\\b[^\\n]*$/gm,
    ];

    let matches: RegExpExecArray[] = [];
    
    for (const pattern of sectionPatterns) {
      let match;
      while ((match = pattern.exec(text)) !== null) {
        matches.push(match);
      }
    }

    // Sort matches by position
    matches.sort((a, b) => a.index! - b.index!);

    if (matches.length === 0) {
      // No clear sections found, return entire text
      return [{ content: text }];
    }

    // Split text by section headers
    let lastIndex = 0;
    
    for (let i = 0; i < matches.length; i++) {
      const match = matches[i];
      const nextMatch = matches[i + 1];
      
      const title = match[0].trim();
      const startIndex = match.index!;
      const endIndex = nextMatch ? nextMatch.index! : text.length;
      
      // Add previous content without header if exists
      if (startIndex > lastIndex) {
        const beforeContent = text.slice(lastIndex, startIndex).trim();
        if (beforeContent.length > 100) {  // Only add substantial content
          sections.push({ content: beforeContent });
        }
      }
      
      // Add section with header
      const sectionContent = text.slice(startIndex, endIndex).trim();
      if (sectionContent.length > 50) {
        sections.push({ 
          title, 
          content: sectionContent,
          estimatedPage: Math.floor((startIndex / text.length) * 100) // Rough page estimation
        });
      }
      
      lastIndex = endIndex;
    }

    return sections.length > 0 ? sections : [{ content: text }];
  }

  /**
   * Chunk text by sentences to preserve semantic coherence
   */
  private chunkTextBySentences(text: string, maxChunkSize: number, overlap: number): string[] {
    const sentences = this.splitIntoSentences(text);
    const chunks: string[] = [];
    
    let currentChunk = '';
    let currentSize = 0;
    
    for (let i = 0; i < sentences.length; i++) {
      const sentence = sentences[i];
      const sentenceSize = sentence.length;
      
      if (currentSize + sentenceSize > maxChunkSize && currentChunk.length > 0) {
        // Save current chunk
        chunks.push(currentChunk.trim());
        
        // Start new chunk with overlap
        const overlapText = this.getOverlapText(currentChunk, overlap);
        currentChunk = overlapText + sentence;
        currentSize = currentChunk.length;
      } else {
        currentChunk += (currentChunk ? ' ' : '') + sentence;
        currentSize += sentenceSize + (currentChunk ? 1 : 0);
      }
    }
    
    // Add final chunk
    if (currentChunk.trim().length > 0) {
      chunks.push(currentChunk.trim());
    }
    
    return chunks;
  }

  /**
   * Split text into sentences
   */
  private splitIntoSentences(text: string): string[] {
    // Enhanced sentence splitting for technical documents
    return text
      .split(/(?<=[.!?])\\s+(?=[A-Z])|(?<=\\n\\n)/)
      .filter(sentence => sentence.trim().length > 0)
      .map(sentence => sentence.trim());
  }

  /**
   * Get overlap text from the end of current chunk
   */
  private getOverlapText(chunk: string, overlapSize: number): string {
    if (chunk.length <= overlapSize) return chunk + ' ';
    
    const overlapText = chunk.slice(-overlapSize);
    const lastSentenceStart = overlapText.lastIndexOf('. ');
    
    if (lastSentenceStart > overlapSize / 2) {
      return overlapText.slice(lastSentenceStart + 2) + ' ';
    }
    
    return overlapText + ' ';
  }

  /**
   * Extract manual number from directory name
   */
  private extractManualNumber(dirName: string): string {
    const match = dirName.match(/MANUAL-(\d+)/);
    return match ? match[1] : '';
  }

  /**
   * Extract category from manual directory name
   */
  private extractManualCategory(dirName: string): string {
    const match = dirName.match(/MANUAL-\d+\s+(.+)/);
    return match ? match[1] : dirName;
  }

  /**
   * Determine document type from folder name
   */
  private determineDocumentType(folderName: string): 'POLICY' | 'PROCEDURE' | null {
    if (folderName.includes('POLICY-')) return 'POLICY';
    if (folderName.includes('PROCEDURE-')) return 'PROCEDURE';
    return null;
  }
}