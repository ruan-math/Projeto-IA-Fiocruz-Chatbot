import { add } from "date-fns";

const pt = {
	// Globais
	send: 'Enviar',
	cancel: 'Cancelar',
	loading: 'Carregando...',
	sending: 'Enviando...',
	stateGetDocuments: 'Processando com modelo de IA...',
	stateAnalyzingQuestion: 'Analisando sua pergunta...',
	stateProcessingModel: 'Processando com modelo de IA...',
	massage_welcome: 'Olá! Sou o Assistente de Documentos da Fiocruz. Posso ajudar você a consultar normas, políticas, manuais e relatórios.',
	disclaimer: 'As respostas são geradas com base nos documentos disponíveis e podem conter imprecisões. Sempre valide pelas referências listadas. Quanto mais específica a pergunta (código, seção, assunto), mais precisa a resposta.',
	// Sidebar/Chat
	search: 'Buscar',
	search_in_chats: 'Buscar em chats...',
	no_chat_found: 'Nenhuma conversa encontrada. Tente outros termos.',
	chat_history: 'Histórico de conversas',
	new_chat: 'Novo chat',
	delete_chat: 'Apagar conversa',
	rename: 'Renomear',
	documents: 'documentos',
	document: 'documento',
	// Chat input
	send_a_question_or_drop_file: 'Envie uma pergunta.',
	// Feedback/Message
	reference: 'fonte',
	references: 'fontes',
	useful: 'Útil',
	not_useful: 'Não útil',
	thanks: 'Obrigado!',
	feedback_sent: 'Feedback enviado',
	text_popup: "Ajude-nos a melhorar fornecendo feedback sobre esta resposta.",
	question_feedback: "Por que esta resposta não foi útil?",
	answer_feedback_1: "Citação ausente",
	answer_feedback_2: "Citação incorreta",
	answer_feedback_3: "Fora do escopo",
	answer_feedback_4: "Impreciso ou irrelevante",
	answer_feedback_5: "Outro motivo não útil",
	question_feedback_report: "Por que este conteúdo é inadequado?",
	answer_feedback_report_1: "Discurso de ódio",
	answer_feedback_report_2: "Conteúdo violento",
	answer_feedback_report_3: "Conteúdo sexual",
	answer_feedback_report_4: "Conteúdo manipulativo",
	answer_feedback_report_5: "Outro conteúdo prejudicial",
	comments: "Comentários adicionais (opcional)",
	add_comment: "Descreva como podemos melhorar...",
	report_content: "Reportar conteúdo inadequado"

};

export default pt;
