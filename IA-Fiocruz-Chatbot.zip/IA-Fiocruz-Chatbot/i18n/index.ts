import en from './en-us';
import pt from './pt-br';

const lang = process.env.NEXT_PUBLIC_APP_LANG || 'pt-br';

const dictionaries: Record<string, Record<string, string>> = {
	'pt-br': pt,
	'en-us': en,
};

export const t = (key: string) => dictionaries[lang][key] || key;
