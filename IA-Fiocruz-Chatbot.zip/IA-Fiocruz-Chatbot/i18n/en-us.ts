const en = {
	// Globals
	send: 'Send',
	cancel: 'Cancel',
	loading: 'Loading...',
	sending: 'Sending...',
	stateGetDocuments: 'Getting documents...',
	stateAnalyzingQuestion: 'Analyzing your question...',
	stateProcessingModel: 'Processing with AI model...',
	massage_welcome: 'Hello! I am the Fiocruz Document Assistant. I can help you consult institutional documents, policies, manuals and reports.',
	disclaimer: 'Responses are generated based on available documents and may contain inaccuracies. Always validate using the listed references. The more specific your question (code, section, topic), the more accurate the response.',
	// Sidebar/Chat
	search: 'Search',
	search_in_chats: 'Search in chats...',
	no_chat_found: 'No conversations found. Try other terms.',
	chat_history: 'Chat history',
	new_chat: 'New chat',
	delete_chat: 'Delete chat',
	rename: 'Rename',
	documents: 'documents',
	document: 'document',
	// Chat input
	send_a_question_or_drop_file: 'Send a question.',
	// Feedback/Message
	reference: 'source',
	references: 'sources',
	useful: 'Useful',
	not_useful: 'Not useful',
	thanks: 'Thanks!',
	feedback_sent: 'Feedback sent',
	text_popup: "Help us improve by providing feedback on this answer.",
	question_feedback: "Why was this answer not helpful?",
	answer_feedback_1: "Missing citation",
	answer_feedback_2: "Incorrect citation",
	answer_feedback_3: "Out of scope",
	answer_feedback_4: "Inaccurate or irrelevant",
	answer_feedback_5: "Other unhelpful reason",
	question_feedback_report: "Why is this content inappropriate?",
	answer_feedback_report_1: "Hate speech",
	answer_feedback_report_2: "Violent content",
	answer_feedback_report_3: "Sexual content",
	answer_feedback_report_4: "Manipulative content",
	answer_feedback_report_5: "Other harmful content",
	comments: "Additional comments (optional)",
	add_comment: "Describe how we can improve...",
	report_content: "Report inappropriate content"
};

export default en;
